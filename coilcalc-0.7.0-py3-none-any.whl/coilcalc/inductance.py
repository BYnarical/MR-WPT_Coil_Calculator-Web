"""Self-inductance L — analytical closed-form formulae.

References:
- Mohan et al., "Simple accurate expressions for planar spiral inductances,"
  IEEE JSSC 1999. Current-sheet expression:
      L = (μ₀·N²·d_avg·c1/2) · [ln(c2/ρ) + c3·ρ + c4·ρ²]
  with shape constants (c1..c4) for circular / square / hex / octagonal.
- Wheeler 1928/1942: short solenoid  L = μ₀·N²·π·r² / (ℓ + 0.9·r)
- Nagaoka 1909: exact solenoid form
      L = μ₀·N²·k_L(x)·π·r² / ℓ ,  x = D/ℓ
  k_L is implemented here as log-x interpolation over Nagaoka's published table,
  with the analytic asymptote k_L ≈ (4/(3πx))·(ln(4x) − 1/2) for x ≥ 50.
"""
from __future__ import annotations

import math

import numpy as np

from .constants import MU_0
from .geometry.solenoid import Solenoid
from .geometry.spiral import CircularSpiral, PolygonalSpiral, _SpiralBase
from .geometry.conical import ConicalHelix, MultiLayerSpiral
from .geometry.rectangular import RectangularSpiral
from .geometry.ev_pads import BipolarPad, DDPad, DDQPad

# Mohan current-sheet coefficients (c1, c2, c3, c4) by polygon shape.
# Source: Mohan et al., JSSC 1999, Table I.
_MOHAN = {
    "square":     (1.27, 2.07, 0.18, 0.13),
    "hexagonal":  (1.09, 2.23, 0.00, 0.17),
    "octagonal":  (1.07, 2.29, 0.00, 0.19),
    "circular":   (1.00, 2.46, 0.00, 0.20),
}


def planar_spiral_L(geom: _SpiralBase) -> float:
    """Mohan modified-Wheeler / current-sheet self-inductance for a planar spiral."""
    c1, c2, c3, c4 = _MOHAN[geom.shape]
    rho = geom.rho
    if rho <= 0.0:
        raise ValueError("Fill ratio rho must be > 0; check Do > Di.")
    # Guard against very small ρ where ln(c2/ρ) dominates (Di very close to Do):
    bracket = math.log(c2 / rho) + c3 * rho + c4 * rho * rho
    return 0.5 * MU_0 * (geom.N ** 2) * geom.d_avg * c1 * bracket


def solenoid_L_wheeler(geom: Solenoid) -> float:
    """Wheeler short-solenoid formula. ~1 % accurate for ℓ/D ≥ 0.4."""
    r = geom.radius
    return MU_0 * (geom.N ** 2) * math.pi * r * r / (geom.length + 0.9 * r)


# Nagaoka coefficient table (D/ℓ → k_L) — Nagaoka 1909, also reproduced in
# Terman "Radio Engineers' Handbook" Tbl. 18 and Grover Ch. 13.  Better than
# 0.1 % accurate; for very-flat coils (x > 50) we use the analytic asymptote.
_NAGAOKA_X = np.array([
    0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80,
    0.90, 1.00, 1.20, 1.40, 1.60, 1.80, 2.00, 2.50, 3.00, 4.00, 5.00, 7.00,
    10.0, 15.0, 20.0, 30.0, 50.0,
])
_NAGAOKA_K = np.array([
    1.0000, 0.9791, 0.9588, 0.9391, 0.9201, 0.9016, 0.8838, 0.8499, 0.8181,
    0.7885, 0.7609, 0.7351, 0.7110, 0.6884, 0.6480, 0.6131, 0.5826, 0.5558,
    0.5321, 0.4830, 0.4429, 0.3797, 0.3197, 0.2509, 0.2031, 0.1502, 0.1219,
    0.0867, 0.0581,
])


def nagaoka_coefficient(form_factor: float) -> float:
    """Nagaoka coefficient k_L as a function of x = D/ℓ.

    Implementation: log-linear interpolation over Nagaoka's published table,
    with analytic asymptote for x > 50:
        k_L ≈ (4/(3π·x))·(ln(4x) − 1/2)
    """
    x = float(form_factor)
    if x <= 0.0:
        return 1.0
    if x >= _NAGAOKA_X[-1]:
        return (4.0 / (3.0 * math.pi * x)) * (math.log(4.0 * x) - 0.5)
    # Interpolate against log(1+x) for smoother behaviour at small x.
    return float(np.interp(math.log1p(x), np.log1p(_NAGAOKA_X), _NAGAOKA_K))


def solenoid_L_nagaoka(geom: Solenoid) -> float:
    """Exact Nagaoka-Lundin solenoid inductance."""
    r = geom.radius
    x = geom.form_factor      # D/ℓ
    k_L = nagaoka_coefficient(x)
    return MU_0 * (geom.N ** 2) * k_L * math.pi * r * r / geom.length


def rectangular_spiral_L(geom: RectangularSpiral) -> float:
    """Modified-Wheeler rectangle (Mohan, with square coefficients)."""
    c1, c2, c3, c4 = _MOHAN["square"]
    rho = geom.rho
    if rho <= 0.0:
        raise ValueError("Fill ratio rho must be > 0; check outer > inner.")
    bracket = math.log(c2 / rho) + c3 * rho + c4 * rho * rho
    return 0.5 * MU_0 * (geom.N ** 2) * geom.d_avg * c1 * bracket


def neumann_self_inductance(geom, n_points_per_turn: int = 90,
                            wire_d: float | None = None) -> float:
    """Compute self-L by self-applying the Neumann integrator with the
    geometric-mean-radius (GMR) regularisation.

    The conductor's GMR (≈ 0.7788 · radius for a solid round wire) sets the
    self-distance ε so the Neumann integral converges. ``wire_d`` defaults
    to the geometry's ``w`` (planar) or ``wire_d`` (3-D) attribute.
    """
    # Defer to avoid a circular import at module load time.
    from .mutual import neumann_filaments
    if wire_d is None:
        wire_d = (getattr(geom, "wire_d", None)
                  or getattr(geom, "w", None)
                  or 1.0e-3)
    gmr = 0.7788 * 0.5 * wire_d           # round-wire GMR
    path = geom.filament_curve(n_points_per_turn)
    return float(neumann_filaments(path, path, gmr=gmr))


def multilayer_L_zhao(stack: MultiLayerSpiral) -> float:
    """Zhao closed-form for N identical stacked planar spirals series-aided.

        L_total = N_layers · L_single  +  2 · Σ_{i<j} M_ij
        M_ij  = k_C(p_ij) · L_single

    For small inter-layer spacing p_ij ≪ d_avg, k_C → 1 (perfect coupling),
    so the stack of N identical layers has L ≈ N² · L_single. For typical
    PCB stack-ups (1.6 mm prepreg, ~50 mm coils) k_C ≈ 0.6–0.85.

    Empirical fit (Zhao 2010):  k_C(p) = 1 / (1 + 1.05·(p/d_avg)^0.85)
    """
    layer = stack.layer_geom
    L1 = self_inductance(layer)
    d_avg = stack.d_avg
    N = stack.n_layers
    total = N * L1
    for i in range(N):
        for j in range(i + 1, N):
            p = (j - i) * stack.layer_spacing
            k_C = 1.0 / (1.0 + 1.05 * (p / d_avg) ** 0.85)
            total += 2.0 * k_C * L1
    return total


def self_inductance(geom) -> float:
    """Dispatch to the appropriate analytical formula.

    Closed-form coverage: CircularSpiral, PolygonalSpiral, RectangularSpiral,
    Solenoid, MultiLayerSpiral.

    Fallback: universal Neumann numerical (handles DD pads, conical helices,
    bipolar pads, etc.).
    """
    if isinstance(geom, (CircularSpiral, PolygonalSpiral)):
        return planar_spiral_L(geom)
    if isinstance(geom, RectangularSpiral):
        return rectangular_spiral_L(geom)
    if isinstance(geom, Solenoid):
        return solenoid_L_nagaoka(geom)
    if isinstance(geom, MultiLayerSpiral):
        return multilayer_L_zhao(geom)
    if isinstance(geom, (ConicalHelix, DDPad, DDQPad, BipolarPad)):
        return neumann_self_inductance(geom)
    raise TypeError(f"Unsupported geometry: {type(geom).__name__}")
