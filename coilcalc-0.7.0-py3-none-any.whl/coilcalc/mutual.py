"""Mutual inductance between two coils.

Two engines are provided:

1. ``maxwell_coaxial_loops`` — closed-form Maxwell formula in terms of
   complete elliptic integrals K, E for two coaxial circular filaments:

       M = μ₀ √(r₁ r₂) · [(2/k − k) K(k²) − (2/k) E(k²)]
       k² = 4 r₁ r₂ / ((r₁+r₂)² + d²)

2. ``neumann_filaments`` — universal Neumann double-line-integral evaluated
   numerically along two arbitrary 3-D filament paths. Handles lateral and
   angular misalignment; this is what the high-level API uses for spirals.
"""
from __future__ import annotations

import math

import numpy as np
from scipy import special

from .constants import MU_0
from .geometry.spiral import CircularSpiral, PolygonalSpiral
from .geometry.solenoid import Solenoid


# --------------------------------------------------------------------- 1. Maxwell
def maxwell_coaxial_loops(r1: float, r2: float, d: float) -> float:
    """Mutual inductance between two coaxial circular filaments.

    Args:
        r1, r2: filament radii, m.
        d:      axial separation, m.
    """
    k2 = 4.0 * r1 * r2 / ((r1 + r2) ** 2 + d * d)
    k2 = min(max(k2, 0.0), 1.0 - 1e-15)
    k = math.sqrt(k2)
    K = special.ellipk(k2)
    E = special.ellipe(k2)
    return MU_0 * math.sqrt(r1 * r2) * ((2.0 / k - k) * K - (2.0 / k) * E)


def maxwell_spiral_pair(
    r_in_1: float, r_out_1: float, n1: int,
    r_in_2: float, r_out_2: float, n2: int,
    d: float,
) -> float:
    """Discretise two coaxial planar spirals into concentric loops and superpose."""
    r1 = np.linspace(r_in_1, r_out_1, n1)
    r2 = np.linspace(r_in_2, r_out_2, n2)
    M = 0.0
    for a in r1:
        for b in r2:
            M += maxwell_coaxial_loops(a, b, d)
    return M


# --------------------------------------------------------------------- 2. Neumann
def neumann_filaments(path1: np.ndarray, path2: np.ndarray,
                      *, gmr: float | None = None) -> float:
    """Neumann double-integral mutual inductance between two filament paths.

    Each ``path`` is an (M, 3) array of points; segments are taken between
    successive rows. When ``path1`` and ``path2`` are the same filament (self-L
    case), the singularity at zero separation is regularised by the geometric
    mean radius (GMR) of the conductor cross-section:

        ε = gmr ≈ 0.7788 · radius   (round wire)

    If ``gmr`` is None, a default of 0.5 × (mean segment length) is used —
    which is reasonable for *mutual* M between distinct filaments but
    *over-estimates* self-L. Always pass an explicit ``gmr`` for self-L.
    """
    if path1.shape[1] != 3 or path2.shape[1] != 3:
        raise ValueError("paths must be (M, 3) arrays of 3-D points")

    # Midpoints and tangent vectors of each segment.
    p1m = 0.5 * (path1[:-1] + path1[1:])
    p2m = 0.5 * (path2[:-1] + path2[1:])
    d1 = np.diff(path1, axis=0)        # (M1-1, 3)
    d2 = np.diff(path2, axis=0)        # (M2-1, 3)

    if gmr is None:
        eps = 0.5 * (np.linalg.norm(d1, axis=1).mean()
                     + np.linalg.norm(d2, axis=1).mean()) / 2.0
    else:
        eps = float(gmr)
    eps2 = eps * eps

    # Pairwise inter-midpoint distance using broadcasting (memory ∝ M1·M2).
    diff = p1m[:, None, :] - p2m[None, :, :]                # (M1-1, M2-1, 3)
    r = np.sqrt(np.einsum("ijk,ijk->ij", diff, diff) + eps2)
    dot = np.einsum("ik,jk->ij", d1, d2)                    # (M1-1, M2-1)
    return float(MU_0 / (4.0 * math.pi) * np.sum(dot / r))


# --------------------------------------------------------------------- 3. Dispatcher
def mutual_inductance(
    geom1, geom2,
    *,
    gap: float = 0.0,
    lateral: float = 0.0,
    tilt_deg: float = 0.0,
    n_points_per_turn: int = 90,
) -> float:
    """Compute M between two coil geometries with optional misalignment.

    For two coaxial circular planar spirals with zero misalignment, the
    superposed-Maxwell formula is used (analytic K/E). Otherwise the universal
    Neumann integrator is invoked.
    """
    is_circular_pair = (isinstance(geom1, CircularSpiral)
                        and isinstance(geom2, CircularSpiral))
    if is_circular_pair and lateral == 0.0 and tilt_deg == 0.0:
        n1, n2 = int(round(geom1.N)), int(round(geom2.N))
        return maxwell_spiral_pair(
            0.5 * geom1.Di, 0.5 * geom1.Do, n1,
            0.5 * geom2.Di, 0.5 * geom2.Do, n2,
            d=gap,
        )

    # Build filament paths in 3-D with the requested alignment.
    p1 = geom1.filament_curve(n_points_per_turn)
    p2 = geom2.filament_curve(n_points_per_turn)

    # Place geom2 above geom1 by `gap`, offset laterally, and tilt about y-axis.
    p2 = p2.copy()
    p2[:, 2] += gap
    p2[:, 0] += lateral
    if tilt_deg != 0.0:
        a = math.radians(tilt_deg)
        cos_a, sin_a = math.cos(a), math.sin(a)
        x, z = p2[:, 0].copy(), p2[:, 2].copy()
        p2[:, 0] = cos_a * x + sin_a * z
        p2[:, 2] = -sin_a * x + cos_a * z

    return neumann_filaments(p1, p2)
