"""High-level user-facing API: Coil and MutualPair.

Examples
--------
>>> from coilcalc import CircularSpiral, LitzWire, Coil
>>> tx = Coil(CircularSpiral(N=10, Do=100e-3, Di=60e-3),
...           LitzWire(strand_d=71e-6, n_strands=420))
>>> tx.L() > 0
True

Ferrite support
---------------
Pass ``ferrite=...`` to the ``Coil`` constructor with any
:class:`coilcalc.ferrite.FerriteShape`. Image-method shapes
(``FerriteSheet``, ``FerriteBars``) add reflected-coil contributions
via the Neumann integrator. Direct-multiplier shapes (``FerriteRod``,
``FerritePotCore``, ``FerriteRing``, ``FerriteCustom``) scale the
air-core L. Both classes contribute Steinmetz core-loss to ``Rac(f)``.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .conductors import FoilStrip, LitzWire, RoundWire
from .geometry.solenoid import Solenoid
from .geometry.spiral import _SpiralBase
from .inductance import self_inductance
from .mutual import mutual_inductance, neumann_filaments
from .proximity import mean_h_squared_per_amp
from .srf import self_resonant_frequency


_Conductor = "RoundWire | LitzWire | FoilStrip"
_DEFAULT_F = 100.0e3   # reference frequency for "L" when no f is given


@dataclass
class Coil:
    """A single physical coil: geometry + conductor (+ optional ferrite).

    Set ``include_proximity=False`` to skip the (slow-ish, O(M²)) Biot-Savart
    proximity calculation and fall back to the conductor's intrinsic R_ac only.

    Pass ``ferrite=`` a :class:`coilcalc.ferrite.FerriteShape` to add a
    ferrite layer. The L and Rac calculations become frequency-dependent
    (μ_r and core-loss roll off with frequency). When ferrite is None the
    behaviour is identical to the air-core API.
    """
    geometry: object
    conductor: object
    include_proximity: bool = True
    ferrite: object = None              # FerriteShape | None
    coil_z0: float = 0.0                # absolute z of this coil's plane

    _L_cache:    Optional[float] = field(default=None, init=False, repr=False)
    _len_cache:  Optional[float] = field(default=None, init=False, repr=False)
    _hsq_cache:  Optional[float] = field(default=None, init=False, repr=False)

    # ------------------------------------------------------------------ L
    def _L_air(self) -> float:
        if self._L_cache is None:
            self._L_cache = self_inductance(self.geometry)
        return self._L_cache

    def L(self, f: float = _DEFAULT_F) -> float:
        """Self-inductance, H. With ferrite, depends on f via μ_r(f)."""
        L0 = self._L_air()
        if self.ferrite is None:
            return L0
        # Multiplier-style shapes
        mult = self.ferrite.l_multiplier(self.geometry, f)
        # Image-method contributions (additive via Neumann)
        path = self.geometry.filament_curve()
        path = path.copy()
        path[:, 2] += self.coil_z0
        extra = 0.0
        for img_path, alpha in self.ferrite.image_paths(path, self.coil_z0, f):
            # GMR for self-Neumann: use ferrite gap as a robust ε so the
            # image's contribution is well-conditioned (image is at depth
            # ~ 2·gap below the coil).
            gap_m = (getattr(self.ferrite, "gap_mm", 0.5)
                     + 0.5 * getattr(self.ferrite, "thickness_mm", 0.0)) * 1e-3
            gmr = max(gap_m, 0.5e-3)
            extra += alpha * neumann_filaments(path, img_path, gmr=gmr)
        return L0 * mult + extra

    # ------------------------------------------------------------------ length
    def wire_length(self) -> float:
        if self._len_cache is None:
            self._len_cache = float(self.geometry.wire_length())
        return self._len_cache

    # ------------------------------------------------------------------ R
    def Rdc(self) -> float:
        return self.conductor.rdc_per_length() * self.wire_length()

    # ------------------------------------------------------------------ proximity
    def _wire_diameter(self) -> float:
        c = self.conductor
        if hasattr(c, "d"):
            return float(c.d)
        if hasattr(c, "bundle_d") and c.bundle_d is not None:
            return float(c.bundle_d)
        if hasattr(c, "thickness"):
            return float(c.thickness) * 2.0
        return 1.0e-3

    def mean_H_squared_per_amp(self) -> float:
        if self._hsq_cache is None:
            path = self.geometry.filament_curve()
            self._hsq_cache = mean_h_squared_per_amp(
                path, wire_d=self._wire_diameter())
        return self._hsq_cache

    # ------------------------------------------------------------------ core-loss R
    def core_loss_resistance(self, f: float, *, I_pk_A: float = 1.0) -> float:
        """Effective series resistance contributed by ferrite core loss.

        Computed as R_core = 2·P_core / I_pk² (peak-to-RMS factor) using
        the shape's Steinmetz / B_pk model.
        """
        if self.ferrite is None:
            return 0.0
        N = float(getattr(self.geometry, "N", 0))
        if N <= 0 or f <= 0:
            return 0.0
        P = self.ferrite.core_loss_W(
            N_turns=N, I_pk_A=I_pk_A, f=f, geom=self.geometry)
        return 2.0 * P / max(I_pk_A * I_pk_A, 1e-30)

    def Rac(self, f: float) -> float:
        """AC resistance, Ω, at frequency f (Hz)."""
        ell = self.wire_length()
        R = self.conductor.rac_per_length(f) * ell
        if self.include_proximity and hasattr(self.conductor, "proximity_loss_coefficient"):
            G = self.conductor.proximity_loss_coefficient(f)
            R += G * self.mean_H_squared_per_amp() * ell
        if self.ferrite is not None:
            R += self.core_loss_resistance(f, I_pk_A=1.0)
        return R

    # ------------------------------------------------------------------ Q
    def Q(self, f: float) -> float:
        omega = 2.0 * math.pi * f
        return omega * self.L(f) / self.Rac(f)

    # ------------------------------------------------------------------ SRF
    def SRF(self) -> float:
        return self_resonant_frequency(self.geometry, self.L())

    # ------------------------------------------------------------------ summary
    def summary(self, f: float) -> dict:
        return {
            "L_uH":    self.L(f) * 1e6,
            "Rdc_mOhm": self.Rdc() * 1e3,
            "Rac_mOhm": self.Rac(f) * 1e3,
            "Q":       self.Q(f),
            "SRF_MHz": self.SRF() * 1e-6,
            "wire_length_m": self.wire_length(),
        }


@dataclass
class MutualPair:
    """Two coils with relative position; computes M, k, and misalignment sweeps.

    Mutual M is enhanced when either or both coils carry a ferrite plate.
    The total M sums:
        M(tx, rx)
      + α_tx · M(tx_image, rx)
      + α_rx · M(tx, rx_image)
      + α_tx·α_rx · M(tx_image, rx_image)
    using each coil's image paths from its ferrite shape.
    """
    tx: Coil
    rx: Coil
    gap: float = 0.0
    lateral: float = 0.0
    tilt_deg: float = 0.0
    f: float = _DEFAULT_F          # frequency for ferrite μ_r lookup

    def _paths(self) -> tuple[np.ndarray, np.ndarray, float, float]:
        tx_path = self.tx.geometry.filament_curve().copy()
        rx_path = self.rx.geometry.filament_curve().copy()
        # Position: Tx at z = coil_z0; Rx at z = coil_z0 + gap with lateral
        # offset and optional tilt about y.
        tx_path[:, 2] += self.tx.coil_z0
        rx_path[:, 2] += self.tx.coil_z0 + self.gap
        rx_path[:, 0] += self.lateral
        if self.tilt_deg != 0.0:
            a = math.radians(self.tilt_deg)
            ca, sa = math.cos(a), math.sin(a)
            x, z = rx_path[:, 0].copy(), rx_path[:, 2].copy()
            rx_path[:, 0] = ca * x + sa * z
            rx_path[:, 2] = -sa * x + ca * z
        return tx_path, rx_path, self.tx.coil_z0, self.tx.coil_z0 + self.gap

    def M(self) -> float:
        # If neither side has ferrite, fall back to the closed-form / Neumann
        # dispatcher that handles coaxial Maxwell as a fast path.
        if self.tx.ferrite is None and self.rx.ferrite is None:
            return mutual_inductance(
                self.tx.geometry, self.rx.geometry,
                gap=self.gap, lateral=self.lateral, tilt_deg=self.tilt_deg,
            )
        tx_path, rx_path, tx_z0, rx_z0 = self._paths()
        M = neumann_filaments(tx_path, rx_path)
        if self.tx.ferrite is not None:
            for img, alpha in self.tx.ferrite.image_paths(tx_path, tx_z0, self.f):
                M += alpha * neumann_filaments(img, rx_path)
        if self.rx.ferrite is not None:
            for img, alpha in self.rx.ferrite.image_paths(rx_path, rx_z0, self.f):
                M += alpha * neumann_filaments(tx_path, img)
        if self.tx.ferrite is not None and self.rx.ferrite is not None:
            tx_images = list(self.tx.ferrite.image_paths(tx_path, tx_z0, self.f))
            rx_images = list(self.rx.ferrite.image_paths(rx_path, rx_z0, self.f))
            for itx, atx in tx_images:
                for irx, arx in rx_images:
                    M += atx * arx * neumann_filaments(itx, irx)
        return M

    def k(self) -> float:
        return self.M() / math.sqrt(self.tx.L(self.f) * self.rx.L(self.f))

    # ------------------------------------------------------------------ sweep
    def sweep_lateral(self, x_min: float, x_max: float, n: int = 21):
        xs = np.linspace(x_min, x_max, n)
        out = np.zeros_like(xs)
        for i, x in enumerate(xs):
            self.lateral = float(x)
            out[i] = self.k()
        self.lateral = 0.0
        return xs, out

    def sweep_gap(self, g_min: float, g_max: float, n: int = 21):
        gs = np.linspace(g_min, g_max, n)
        out = np.zeros_like(gs)
        gap0 = self.gap
        for i, g in enumerate(gs):
            self.gap = float(g)
            out[i] = self.k()
        self.gap = gap0
        return gs, out

    def summary(self, f: float) -> dict:
        self.f = f
        M = self.M()
        return {
            "M_uH": M * 1e6,
            "k":    M / math.sqrt(self.tx.L(f) * self.rx.L(f)),
            "tx":   self.tx.summary(f),
            "rx":   self.rx.summary(f),
        }
