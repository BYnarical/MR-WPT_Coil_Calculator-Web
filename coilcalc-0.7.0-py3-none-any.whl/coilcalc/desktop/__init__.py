"""Pure-Qt desktop GUI for coilcalc.

No web engine. PySide6 widgets + PyQtGraph plots + a dark Material-style
QSS stylesheet. Same physics as the rest of the package.
"""
