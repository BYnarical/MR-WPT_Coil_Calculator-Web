"""Dark Material/Electron-style theme for the coilcalc Qt desktop app.

All visual styling is funnelled through this module so changes propagate to
every tab. Colors are the same palette used in the previous NiceGUI build
(slate-900 background, cyan-500 primary, violet-300 accent).
"""
from __future__ import annotations

# ------------------------------------------------------------------ palette
BG          = "#0f172a"   # slate-900
SURFACE     = "#1e293b"   # slate-800
SURFACE_2   = "#293548"   # slate-700-ish
DIVIDER     = "#334155"   # slate-700
TEXT        = "#e2e8f0"   # slate-200
TEXT_DIM    = "#94a3b8"   # slate-400
TEXT_FAINT  = "#64748b"   # slate-500

PRIMARY     = "#06b6d4"   # cyan-500
PRIMARY_HI  = "#22d3ee"   # cyan-400
ACCENT      = "#a78bfa"   # violet-300
ACCENT_HI   = "#c4b5fd"   # violet-200
DANGER      = "#ef4444"
WARNING     = "#f59e0b"
SUCCESS     = "#10b981"


STYLESHEET = f"""
* {{
    color: {TEXT};
    font-family: 'Segoe UI', 'Noto Sans CJK KR', sans-serif;
    font-size: 13px;
    selection-background-color: {PRIMARY};
    selection-color: {BG};
}}

QMainWindow, QWidget#root, QWidget#tabSurface {{
    background-color: {BG};
}}

/* Top header */
QFrame#header {{
    background-color: {SURFACE};
    border-bottom: 1px solid {DIVIDER};
}}
QLabel#brand {{
    color: {TEXT};
    font-size: 20px;
    font-weight: 700;
    letter-spacing: 0.5px;
}}
QLabel#brand-sub {{
    color: {TEXT_DIM};
    font-size: 12px;
}}

/* Tab bar */
QTabWidget::pane {{
    border: none;
    background: {BG};
}}
QTabBar::tab {{
    background: transparent;
    color: {TEXT_DIM};
    padding: 10px 22px;
    margin: 0 2px;
    border: none;
    border-bottom: 2px solid transparent;
    font-weight: 500;
}}
QTabBar::tab:hover {{
    color: {TEXT};
}}
QTabBar::tab:selected {{
    color: {PRIMARY_HI};
    border-bottom: 2px solid {PRIMARY};
}}

/* Cards */
QFrame#card {{
    background-color: {SURFACE};
    border-radius: 10px;
    border: 1px solid {DIVIDER};
}}
QLabel.section-title {{
    color: {PRIMARY_HI};
    font-size: 14px;
    font-weight: 700;
    padding: 4px 0 8px 0;
}}

/* Metric values */
QLabel.metric-key {{
    color: {TEXT_DIM};
    font-family: 'Consolas', 'Cascadia Mono', monospace;
}}
QLabel.metric-val {{
    color: {ACCENT_HI};
    font-family: 'Consolas', 'Cascadia Mono', monospace;
    font-weight: 700;
    font-size: 14px;
}}

/* Form widgets */
QLabel.form-label {{
    color: {TEXT_DIM};
    font-size: 12px;
}}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background-color: {SURFACE_2};
    color: {TEXT};
    border: 1px solid {DIVIDER};
    border-radius: 6px;
    padding: 5px 8px;
    min-height: 22px;
    selection-background-color: {PRIMARY};
    selection-color: {BG};
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border: 1px solid {PRIMARY};
}}
QComboBox::drop-down {{
    border: none;
    width: 22px;
}}
QComboBox QAbstractItemView {{
    background-color: {SURFACE_2};
    color: {TEXT};
    selection-background-color: {PRIMARY};
    selection-color: {BG};
    border: 1px solid {DIVIDER};
}}

/* Buttons */
QPushButton {{
    background-color: {PRIMARY};
    color: {BG};
    border: none;
    border-radius: 6px;
    padding: 6px 14px;
    font-weight: 600;
}}
QPushButton:hover {{
    background-color: {PRIMARY_HI};
}}
QPushButton:disabled {{
    background-color: {SURFACE_2};
    color: {TEXT_FAINT};
}}
QPushButton.danger {{
    background-color: {DANGER};
    color: {BG};
}}
QPushButton.flat {{
    background-color: transparent;
    color: {PRIMARY_HI};
}}
QPushButton.flat:hover {{
    background-color: {SURFACE_2};
}}

/* Tables */
QTableWidget {{
    background-color: {SURFACE};
    color: {TEXT};
    gridline-color: {DIVIDER};
    border: 1px solid {DIVIDER};
    border-radius: 6px;
}}
QTableWidget::item:selected {{
    background-color: {PRIMARY};
    color: {BG};
}}
QHeaderView::section {{
    background-color: {SURFACE_2};
    color: {TEXT_DIM};
    border: none;
    border-right: 1px solid {DIVIDER};
    border-bottom: 1px solid {DIVIDER};
    padding: 6px;
    font-weight: 600;
}}

/* Splitters */
QSplitter::handle {{
    background-color: {DIVIDER};
}}
QSplitter::handle:horizontal {{
    width: 3px;
}}
QSplitter::handle:vertical {{
    height: 3px;
}}

/* Footer */
QFrame#footer {{
    background-color: {SURFACE};
    border-top: 1px solid {DIVIDER};
}}
QLabel#footer-text {{
    color: {TEXT_FAINT};
    font-size: 11px;
}}

/* Scrollbars */
QScrollBar:vertical {{
    background: {BG}; width: 10px;
}}
QScrollBar::handle:vertical {{
    background: {DIVIDER}; border-radius: 5px; min-height: 20px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    background: none; height: 0;
}}
QScrollBar:horizontal {{
    background: {BG}; height: 10px;
}}
QScrollBar::handle:horizontal {{
    background: {DIVIDER}; border-radius: 5px; min-width: 20px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    background: none; width: 0;
}}
"""


def apply(app) -> None:
    """Apply the dark stylesheet to a QApplication."""
    app.setStyleSheet(STYLESHEET)
