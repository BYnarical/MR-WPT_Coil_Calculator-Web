"""N-coil system tab — editable table of coils + 3D layout + |k| heatmap."""
from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)
import qtawesome as qta

from .. import CircularSpiral, Coil, LitzWire, WPTSystem
from . import theme as T
from .widgets import Card, Coil3D, HeatmapPanel, MetricGrid


class _CoilRow(dict):
    """Just a dict subclass — kept for typing clarity."""


class SystemTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows: list[_CoilRow] = [
            _CoilRow(name="Tx (driver)", x=0.0, y=0.0, z=0.0,  Do=100, Di=60, N=10),
            _CoilRow(name="Relay",       x=0.0, y=0.0, z=30.0, Do=100, Di=60, N=10),
            _CoilRow(name="Rx (load)",   x=0.0, y=0.0, z=60.0, Do=60,  Di=30, N=8),
        ]
        self.R_load = 20.0
        self.V_source = 10.0
        self.freq_hz = 6.78e6

        # --- left card: coil table + add/remove + metrics
        left_card = Card("Coils")
        controls = QHBoxLayout()
        add_btn = QPushButton(qta.icon("mdi.plus", color=T.BG), " Add coil")
        add_btn.clicked.connect(self._add_row)
        rem_btn = QPushButton(qta.icon("mdi.minus", color=T.BG), " Remove selected")
        rem_btn.clicked.connect(self._remove_selected)
        rem_btn.setStyleSheet(
            f"QPushButton {{ background-color:{T.DANGER}; color:{T.BG}; "
            f"border-radius:6px; padding:6px 12px; font-weight:600; }}"
        )
        controls.addWidget(add_btn)
        controls.addWidget(rem_btn)
        controls.addStretch()
        left_card.addLayout(controls)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(
            ["Name", "x (mm)", "y (mm)", "z (mm)", "Do (mm)", "Di (mm)", "N"]
        )
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumHeight(180)
        self.table.itemChanged.connect(self._on_cell_edit)
        left_card.addWidget(self.table)
        self._rebuild_table()

        sys_form = QFormLayout()
        f_sb = QDoubleSpinBox(); f_sb.setRange(0.001, 300); f_sb.setDecimals(3)
        f_sb.setSingleStep(0.01); f_sb.setValue(self.freq_hz*1e-6); f_sb.setSuffix(" MHz")
        f_sb.valueChanged.connect(lambda v: (setattr(self, "freq_hz", v*1e6), self._refresh()))
        r_sb = QDoubleSpinBox(); r_sb.setRange(0.1, 10000); r_sb.setDecimals(2)
        r_sb.setValue(self.R_load); r_sb.setSuffix(" Ω")
        r_sb.valueChanged.connect(lambda v: (setattr(self, "R_load", v), self._refresh()))
        v_sb = QDoubleSpinBox(); v_sb.setRange(0.01, 1000); v_sb.setDecimals(2)
        v_sb.setValue(self.V_source); v_sb.setSuffix(" V")
        v_sb.valueChanged.connect(lambda v: (setattr(self, "V_source", v), self._refresh()))
        for lab, sb in [("Frequency", f_sb), ("R_load", r_sb), ("V_source", v_sb)]:
            l = QLabel(lab); l.setStyleSheet(f"color:{T.TEXT_DIM};")
            sys_form.addRow(l, sb)
        left_card.addLayout(sys_form)

        self.metrics = MetricGrid(["η", "V_out", "Gain", "P_in", "P_load"])
        left_card.addWidget(self.metrics)
        left_card.addStretch()

        # --- right card: 3D layout + heatmap stacked
        self.view = Coil3D()
        self.heatmap = HeatmapPanel("|k_ij|")
        right_split = QSplitter(Qt.Orientation.Vertical)
        layout_card = Card("Layout")
        layout_card.addWidget(self.view, stretch=1)
        heat_card = Card("Coupling matrix")
        heat_card.addWidget(self.heatmap, stretch=1)
        right_split.addWidget(layout_card)
        right_split.addWidget(heat_card)
        right_split.setStretchFactor(0, 3)
        right_split.setStretchFactor(1, 2)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_card)
        splitter.addWidget(right_split)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 4)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.addWidget(splitter)
        self._refresh()

    # ----------------------------------------------------------- table
    def _rebuild_table(self) -> None:
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.rows))
        for r, row in enumerate(self.rows):
            for c, key in enumerate(["name", "x", "y", "z", "Do", "Di", "N"]):
                val = row[key]
                self.table.setItem(r, c, QTableWidgetItem(str(val)))
        self.table.blockSignals(False)

    def _on_cell_edit(self, item) -> None:
        r, c = item.row(), item.column()
        key = ["name", "x", "y", "z", "Do", "Di", "N"][c]
        text = item.text()
        try:
            if key == "name":
                self.rows[r][key] = text
            else:
                self.rows[r][key] = float(text)
        except Exception:
            return
        self._refresh()

    def _add_row(self) -> None:
        z = max([r["z"] for r in self.rows], default=0.0) + 30.0
        self.rows.append(_CoilRow(name=f"Coil {len(self.rows)+1}",
                                  x=0.0, y=0.0, z=z, Do=80, Di=40, N=10))
        self._rebuild_table()
        self._refresh()

    def _remove_selected(self) -> None:
        rows = sorted({i.row() for i in self.table.selectedIndexes()}, reverse=True)
        if not rows or len(self.rows) - len(rows) < 2:
            return
        for r in rows:
            self.rows.pop(r)
        self._rebuild_table()
        self._refresh()

    # ----------------------------------------------------------- refresh
    def _refresh(self) -> None:
        litz = LitzWire(strand_d=71e-6, n_strands=420)
        coils = []
        positions = []
        for r in self.rows:
            try:
                g = CircularSpiral(N=float(r["N"]),
                                   Do=float(r["Do"])*1e-3,
                                   Di=float(r["Di"])*1e-3)
                coils.append(Coil(g, litz))
                positions.append((float(r["x"])*1e-3,
                                  float(r["y"])*1e-3,
                                  float(r["z"])*1e-3))
            except Exception:
                return
        sys = WPTSystem(coils=coils, positions=positions,
                        load_index=len(coils)-1, R_load=self.R_load,
                        V_source=self.V_source, f=self.freq_hz)
        try:
            res = sys.solve()
        except Exception:
            return
        self.metrics.set("η",      f"{res['eta']*100:6.2f} %")
        self.metrics.set("V_out",  f"{abs(res['V_out']):6.3f} V")
        self.metrics.set("Gain",   f"{res['gain']:6.3f}")
        self.metrics.set("P_in",   f"{res['P_in']*1e3:6.3f} mW")
        self.metrics.set("P_load", f"{res['P_load']*1e3:6.3f} mW")

        # 3D layout
        paths = []
        for coil, (x, y, z) in zip(coils, positions):
            p = coil.geometry.filament_curve().copy()
            p[:, 0] += x; p[:, 1] += y; p[:, 2] += z
            paths.append(p)
        self.view.set_paths(paths)

        # Coupling heatmap
        K = sys.coupling_matrix()
        self.heatmap.set_matrix(K)
