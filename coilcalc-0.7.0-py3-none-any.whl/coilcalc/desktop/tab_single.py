"""Single-coil designer tab — pure Qt."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel, QSplitter, QVBoxLayout,
    QWidget,
)

from .. import Coil
from . import theme as T
from .forms import ConductorForm, GeometryForm
from .widgets import Card, Coil3D, MetricGrid


class SingleCoilTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.geom = GeometryForm(default_geom="Circular spiral")
        self.cond = ConductorForm(default="Litz wire")
        self.freq_hz = 6.78e6

        # ---- left card
        left = Card("Geometry")
        left.addWidget(self.geom)
        left_card2 = Card("Conductor")
        left_card2.addWidget(self.cond)
        left_card3 = Card("Frequency")
        freq_form = QFormLayout()
        freq_sb = QDoubleSpinBox()
        freq_sb.setRange(0.001, 300.0)
        freq_sb.setDecimals(3)
        freq_sb.setSingleStep(0.01)
        freq_sb.setValue(self.freq_hz * 1e-6)
        freq_sb.setSuffix(" MHz")
        freq_sb.valueChanged.connect(self._on_freq_change)
        freq_form.addRow(QLabel("f"), freq_sb)
        left_card3.addLayout(freq_form)
        left_col = QWidget()
        lv = QVBoxLayout(left_col)
        lv.setSpacing(10)
        lv.addWidget(left)
        lv.addWidget(left_card2)
        lv.addWidget(left_card3)
        lv.addStretch()

        # ---- centre card (metrics)
        mid = Card("Results")
        self.metrics = MetricGrid(
            ["L", "R_dc", "R_ac", "Q", "SRF", "Wire length"])
        mid.addWidget(self.metrics)
        info = QLabel(
            "Planar spiral → <b>Mohan</b><br>"
            "Solenoid → <b>Wheeler / Nagaoka</b><br>"
            "Multi-layer → <b>Zhao</b><br>"
            "DD pad / Conical → <b>Neumann (GMR)</b><br>"
            "Round → <b>Bessel</b> · Litz → <b>Sullivan</b> · "
            "Foil → <b>Dowell</b> · PCB → <b>Yue</b><br>"
            "Q includes <b>turn-aware Biot-Savart</b> proximity."
        )
        info.setStyleSheet(f"color:{T.TEXT_FAINT}; font-size:12px; padding-top:14px;")
        info.setWordWrap(True)
        mid.addWidget(info)
        mid.addStretch()

        # ---- right card (3D view)
        right = Card("3-D filament path")
        self.view = Coil3D()
        right.addWidget(self.view, stretch=1)

        # ---- splitter to put them all side by side
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_col)
        splitter.addWidget(mid)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 2)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.addWidget(splitter)

        # ---- wire up live updates
        self.geom.changed.connect(self._refresh)
        self.cond.changed.connect(self._refresh)
        self._refresh()

    # ------------------------------------------------------------ slots
    def _on_freq_change(self, mhz: float) -> None:
        self.freq_hz = float(mhz) * 1e6
        self._refresh()

    def _refresh(self) -> None:
        try:
            coil = Coil(self.geom.build_geometry(), self.cond.build_conductor())
        except Exception:
            for k in self.metrics.values:
                self.metrics.set(k, "—")
            return
        f = self.freq_hz
        self.metrics.set("L",   f"{coil.L()*1e6:8.3f}  µH")
        self.metrics.set("R_dc", f"{coil.Rdc()*1e3:8.3f}  mΩ")
        self.metrics.set("R_ac", f"{coil.Rac(f)*1e3:8.3f}  mΩ")
        self.metrics.set("Q",   f"{coil.Q(f):8.0f}")
        srf = coil.SRF()
        self.metrics.set("SRF", f"{srf*1e-6:8.2f}  MHz")
        self.metrics.set("Wire length", f"{coil.wire_length():8.3f}  m")
        self.view.set_paths([coil.geometry.filament_curve()])
