"""Reusable Qt widgets for the coilcalc desktop GUI."""
from __future__ import annotations

from typing import Callable, Optional

import numpy as np
import pyqtgraph as pg
import pyqtgraph.opengl as gl
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QSpinBox, QSizePolicy, QVBoxLayout, QWidget,
)

from . import theme as T


# ---------------------------------------------------------------------- Card
class Card(QFrame):
    """A rounded slate-800 panel with a title at the top."""
    def __init__(self, title: str, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setObjectName("card")
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(14, 12, 14, 12)
        self._layout.setSpacing(6)
        if title:
            t = QLabel(title)
            t.setProperty("class", "section-title")
            t.setStyleSheet(f"color:{T.PRIMARY_HI}; font-size:14px; font-weight:700;")
            self._layout.addWidget(t)

    def addWidget(self, w: QWidget, stretch: int = 0) -> None:
        self._layout.addWidget(w, stretch)

    def addLayout(self, l) -> None:
        self._layout.addLayout(l)

    def addStretch(self, stretch: int = 1) -> None:
        self._layout.addStretch(stretch)


# ---------------------------------------------------------------------- Metric panel
class MetricGrid(QWidget):
    """Two-column key→value grid styled in the theme palette."""
    def __init__(self, keys: list[str], parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.values: dict[str, QLabel] = {}
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 4, 0, 4)
        grid.setVerticalSpacing(6)
        grid.setHorizontalSpacing(20)
        for r, k in enumerate(keys):
            klabel = QLabel(k)
            klabel.setStyleSheet(
                f"color:{T.TEXT_DIM}; font-family:Consolas,monospace;")
            vlabel = QLabel("—")
            vlabel.setStyleSheet(
                f"color:{T.ACCENT_HI}; font-family:Consolas,monospace; "
                f"font-weight:700; font-size:14px;")
            vlabel.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            grid.addWidget(klabel, r, 0)
            grid.addWidget(vlabel, r, 1)
            self.values[k] = vlabel
        grid.setColumnStretch(0, 0)
        grid.setColumnStretch(1, 1)

    def set(self, key: str, text: str) -> None:
        if key in self.values:
            self.values[key].setText(text)


# ---------------------------------------------------------------------- LabeledDouble
def labeled_double(parent_form: QFormLayout, label: str,
                   default: float, *, _min=0.0, _max=1e6, step=1.0,
                   decimals: int = 3,
                   on_change: Optional[Callable[[float], None]] = None,
                   ) -> QDoubleSpinBox:
    sb = QDoubleSpinBox()
    sb.setRange(_min, _max)
    sb.setSingleStep(step)
    sb.setDecimals(decimals)
    sb.setValue(default)
    sb.setMinimumWidth(120)
    if on_change is not None:
        sb.valueChanged.connect(on_change)
    label_w = QLabel(label)
    label_w.setStyleSheet(f"color:{T.TEXT_DIM};")
    parent_form.addRow(label_w, sb)
    return sb


def labeled_int(parent_form: QFormLayout, label: str,
                default: int, *, _min=1, _max=1000, step=1,
                on_change: Optional[Callable[[int], None]] = None,
                ) -> QSpinBox:
    sb = QSpinBox()
    sb.setRange(_min, _max)
    sb.setSingleStep(step)
    sb.setValue(default)
    sb.setMinimumWidth(120)
    if on_change is not None:
        sb.valueChanged.connect(on_change)
    label_w = QLabel(label)
    label_w.setStyleSheet(f"color:{T.TEXT_DIM};")
    parent_form.addRow(label_w, sb)
    return sb


def labeled_combo(parent_form: QFormLayout, label: str, options: list[str],
                  default: str = "",
                  on_change: Optional[Callable[[str], None]] = None,
                  ) -> QComboBox:
    cb = QComboBox()
    cb.addItems(options)
    if default and default in options:
        cb.setCurrentText(default)
    if on_change is not None:
        cb.currentTextChanged.connect(on_change)
    label_w = QLabel(label)
    label_w.setStyleSheet(f"color:{T.TEXT_DIM};")
    parent_form.addRow(label_w, cb)
    return cb


# ---------------------------------------------------------------------- 3D coil view
class Coil3D(QWidget):
    """OpenGL 3-D filament viewer using pyqtgraph.opengl."""
    def __init__(self, parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumHeight(300)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.view = gl.GLViewWidget()
        self.view.setBackgroundColor(T.BG)
        self.view.opts['distance'] = 0.3
        self.view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.view.setMinimumHeight(280)
        layout.addWidget(self.view, 1)

        # Grid plane
        self.grid = gl.GLGridItem()
        self.grid.setColor(QColor(T.DIVIDER))
        self.grid.scale(0.02, 0.02, 0.02)
        self.view.addItem(self.grid)

        # Filament line item — empty until set_paths is called.
        self._items: list[gl.GLLinePlotItem] = []

    def set_paths(self, paths: list[np.ndarray], colors: Optional[list[str]] = None) -> None:
        """Update the 3-D view with one or more filament paths (each (M, 3))."""
        for it in self._items:
            self.view.removeItem(it)
        self._items.clear()
        if not paths:
            return

        default_colors = [T.PRIMARY, T.ACCENT, "#34d399", "#f97316", "#ec4899"]
        colors = colors or [default_colors[i % len(default_colors)] for i in range(len(paths))]

        max_extent = 0.0
        for path, c in zip(paths, colors):
            pts = path.astype(np.float32)
            col = QColor(c)
            color_rgba = (col.redF(), col.greenF(), col.blueF(), 1.0)
            item = gl.GLLinePlotItem(pos=pts, color=color_rgba, width=3, antialias=True)
            self.view.addItem(item)
            self._items.append(item)
            max_extent = max(max_extent, float(np.abs(pts).max()))

        if max_extent > 0:
            self.view.opts['distance'] = max_extent * 4.0
            self.grid.resetTransform()
            scale = max_extent / 5.0
            self.grid.scale(scale, scale, scale)
        self.view.update()


# ---------------------------------------------------------------------- Line plot
class LinePlot(QWidget):
    """2-D line plot panel with theme-friendly axes."""
    def __init__(self, x_label: str = "", y_label: str = "",
                 title: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumHeight(200)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        pg.setConfigOption("background", T.BG)
        pg.setConfigOption("foreground", T.TEXT)
        self.plot = pg.PlotWidget(title=title)
        self.plot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.plot.getPlotItem().setLabel("bottom", x_label, color=T.TEXT_DIM)
        self.plot.getPlotItem().setLabel("left", y_label, color=T.TEXT_DIM)
        self.plot.getPlotItem().showGrid(x=True, y=True, alpha=0.2)
        self.plot.getAxis("bottom").setPen(pg.mkPen(T.DIVIDER))
        self.plot.getAxis("left").setPen(pg.mkPen(T.DIVIDER))
        self.plot.getAxis("bottom").setTextPen(pg.mkPen(T.TEXT_DIM))
        self.plot.getAxis("left").setTextPen(pg.mkPen(T.TEXT_DIM))
        self.plot.setMouseEnabled(x=True, y=True)
        layout.addWidget(self.plot)
        self._curve = self.plot.plot([], [], pen=pg.mkPen(T.PRIMARY, width=2),
                                     symbol="o", symbolBrush=T.ACCENT,
                                     symbolSize=6, symbolPen=None)

    def set_data(self, x, y) -> None:
        self._curve.setData(np.asarray(x, dtype=float),
                            np.asarray(y, dtype=float))


# ---------------------------------------------------------------------- Heatmap
class HeatmapPanel(QWidget):
    """Imshow-style matrix view with a Cividis colormap."""
    def __init__(self, title: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumHeight(220)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        pg.setConfigOption("background", T.BG)
        pg.setConfigOption("foreground", T.TEXT)
        self.view = pg.GraphicsLayoutWidget()
        self.view.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.plot = self.view.addPlot(title=title)
        self.img = pg.ImageItem()
        self.plot.addItem(self.img)
        self.plot.invertY(True)
        cmap = pg.colormap.get("cividis", source="matplotlib", skipCache=True) \
            if hasattr(pg.colormap, "get") else None
        if cmap is not None:
            self.img.setLookupTable(cmap.getLookupTable())
        self.plot.getAxis("bottom").setTextPen(pg.mkPen(T.TEXT_DIM))
        self.plot.getAxis("left").setTextPen(pg.mkPen(T.TEXT_DIM))
        layout.addWidget(self.view)

    def set_matrix(self, M: np.ndarray) -> None:
        # Show absolute value so sign is collapsed (couplings can be negative).
        self.img.setImage(np.abs(M), autoLevels=True)
