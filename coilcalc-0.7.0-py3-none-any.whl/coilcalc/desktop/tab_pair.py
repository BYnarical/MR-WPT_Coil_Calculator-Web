"""Pair / coupling tab — Tx + Rx with alignment sweeps."""
from __future__ import annotations

import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDoubleSpinBox, QFormLayout, QHBoxLayout, QLabel, QSplitter, QVBoxLayout,
    QWidget,
)

from .. import Coil, MutualPair, WPTSystem
from . import theme as T
from .forms import GeometryForm, ConductorForm
from .widgets import Card, LinePlot, MetricGrid


class PairTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.tx_geom = GeometryForm(default_geom="Circular spiral", prefix="Tx ")
        self.rx_geom = GeometryForm(default_geom="Circular spiral", prefix="Rx ")
        self.tx_geom.params.update(N=10, Do=100, Di=60)
        self.rx_geom.params.update(N=8,  Do=60,  Di=30)
        self.tx_geom._rebuild_dynamic()
        self.rx_geom._rebuild_dynamic()
        self.cond = ConductorForm(default="Litz wire")
        self.freq_hz = 6.78e6
        self.gap_mm = 20.0
        self.lat_mm = 0.0
        self.tilt_deg = 0.0
        self.R_load = 20.0
        self.V_source = 10.0

        # ---- Left column: Tx, Rx, conductor
        left_col = QWidget()
        lv = QVBoxLayout(left_col)
        lv.setSpacing(10)
        tx_card = Card("Tx coil")
        tx_card.addWidget(self.tx_geom)
        rx_card = Card("Rx coil")
        rx_card.addWidget(self.rx_geom)
        cond_card = Card("Shared conductor")
        cond_card.addWidget(self.cond)
        lv.addWidget(tx_card)
        lv.addWidget(rx_card)
        lv.addWidget(cond_card)
        lv.addStretch()

        # ---- Centre: alignment + metrics
        mid_col = QWidget()
        mv = QVBoxLayout(mid_col)
        mv.setSpacing(10)
        align_card = Card("Alignment & system")
        align_form = QFormLayout()
        align_card.addLayout(align_form)
        self.gap_sb   = self._dsb(align_form, "Vertical gap (mm)",   20.0, 0,   500, 1, "gap_mm")
        self.lat_sb   = self._dsb(align_form, "Lateral offset (mm)",  0.0, 0,   500, 1, "lat_mm")
        self.tilt_sb  = self._dsb(align_form, "Tilt (deg)",           0.0, 0,    90, 1, "tilt_deg")
        self.rload_sb = self._dsb(align_form, "R_load (Ω)",          20.0, 0.1, 10000, 1, "R_load")
        self.vsrc_sb  = self._dsb(align_form, "V_source (V)",        10.0, 0.01, 1000, 1, "V_source")
        self.freq_sb  = self._dsb(align_form, "Frequency (MHz)",     6.78, 0.001, 300, 0.01, "freq_mhz")
        mv.addWidget(align_card)

        metric_card = Card("Coupling & link")
        self.metrics = MetricGrid(["M", "k", "η", "V_out", "P_in", "P_load"])
        metric_card.addWidget(self.metrics)
        mv.addWidget(metric_card)
        mv.addStretch()

        # ---- Right: 3 sweep plots
        self.plot_k_gap   = LinePlot("gap (mm)",       "k", "k vs gap")
        self.plot_k_lat   = LinePlot("lateral (mm)",   "k", "k vs lateral offset")
        self.plot_eta_gap = LinePlot("gap (mm)",       "η", "η vs gap")
        right_card = Card("Sweeps")
        right_card.addWidget(self.plot_k_gap, stretch=1)
        right_card.addWidget(self.plot_k_lat, stretch=1)
        right_card.addWidget(self.plot_eta_gap, stretch=1)

        # ---- splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.addWidget(left_col)
        splitter.addWidget(mid_col)
        splitter.addWidget(right_card)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 1)
        splitter.setStretchFactor(2, 2)

        outer = QHBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.addWidget(splitter)

        self.tx_geom.changed.connect(self._refresh)
        self.rx_geom.changed.connect(self._refresh)
        self.cond.changed.connect(self._refresh)
        self._refresh()

    def _dsb(self, form, label, default, mn, mx, step, attr):
        sb = QDoubleSpinBox()
        sb.setRange(mn, mx)
        sb.setSingleStep(step)
        sb.setDecimals(3)
        sb.setValue(default)
        def _on(v, attr=attr):
            if attr == "freq_mhz":
                self.freq_hz = float(v) * 1e6
            else:
                setattr(self, attr, float(v))
            self._refresh()
        sb.valueChanged.connect(_on)
        lbl = QLabel(label)
        lbl.setStyleSheet(f"color:{T.TEXT_DIM};")
        form.addRow(lbl, sb)
        return sb

    # ------------------------------------------------------------ refresh
    def _refresh(self):
        try:
            tx_coil = Coil(self.tx_geom.build_geometry(), self.cond.build_conductor())
            rx_coil = Coil(self.rx_geom.build_geometry(), self.cond.build_conductor())
        except Exception as e:
            for k in self.metrics.values:
                self.metrics.set(k, "—")
            return
        f = self.freq_hz
        pair = MutualPair(tx_coil, rx_coil, gap=self.gap_mm*1e-3,
                          lateral=self.lat_mm*1e-3, tilt_deg=self.tilt_deg)
        M_val = pair.M()
        k_val = pair.k()
        sys2 = WPTSystem(coils=[tx_coil, rx_coil],
                         positions=[(0,0,0), (self.lat_mm*1e-3, 0,
                                              self.gap_mm*1e-3)],
                         load_index=1, R_load=self.R_load,
                         V_source=self.V_source, f=f)
        try:
            res = sys2.solve()
        except Exception:
            return
        self.metrics.set("M",     f"{M_val*1e6:7.3f}  µH")
        self.metrics.set("k",     f"{k_val:7.4f}")
        self.metrics.set("η",     f"{res['eta']*100:6.2f} %")
        self.metrics.set("V_out", f"{abs(res['V_out']):6.2f} V")
        self.metrics.set("P_in",  f"{res['P_in']*1e3:6.2f} mW")
        self.metrics.set("P_load", f"{res['P_load']*1e3:6.2f} mW")

        # ---- sweeps
        gaps = np.linspace(2e-3, 200e-3, 25)
        ks = [MutualPair(tx_coil, rx_coil, gap=g,
                         lateral=self.lat_mm*1e-3).k() for g in gaps]
        self.plot_k_gap.set_data(gaps*1e3, ks)

        lat_max = max(self.tx_geom.params.get("Do", 100), 30) * 1e-3
        lats = np.linspace(0.0, lat_max, 25)
        klats = [MutualPair(tx_coil, rx_coil,
                            gap=self.gap_mm*1e-3, lateral=x).k() for x in lats]
        self.plot_k_lat.set_data(lats*1e3, klats)

        gaps_e = np.linspace(2e-3, 200e-3, 18)
        etas = []
        for g in gaps_e:
            s2 = WPTSystem(coils=[tx_coil, rx_coil],
                           positions=[(0,0,0), (self.lat_mm*1e-3, 0, g)],
                           load_index=1, R_load=self.R_load,
                           V_source=self.V_source, f=f)
            try:
                etas.append(s2.solve()["eta"])
            except Exception:
                etas.append(0.0)
        self.plot_eta_gap.set_data(gaps_e*1e3, etas)
