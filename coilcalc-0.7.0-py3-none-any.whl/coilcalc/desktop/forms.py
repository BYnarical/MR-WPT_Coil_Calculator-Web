"""Geometry + conductor input forms for the desktop GUI.

Each form is a self-contained QWidget that owns a parameter dict and emits
a `changed` signal whenever any input changes.
"""
from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QSpinBox, QVBoxLayout,
    QWidget,
)

from .. import (
    BipolarPad, CircularSpiral, Coil, ConicalHelix, DDPad, FoilStrip,
    LitzWire, MultiLayerSpiral, PCBTrace, PolygonalSpiral,
    RectangularSpiral, RoundWire, Solenoid,
)
from . import theme as T
from .widgets import labeled_combo, labeled_double, labeled_int


GEOMETRY_OPTIONS = [
    "Circular spiral",
    "Square spiral",
    "Hexagonal spiral",
    "Octagonal spiral",
    "Rectangular spiral",
    "Solenoid",
    "Conical helix",
    "Multi-layer planar",
    "Double-D pad",
]
_SHAPE_OF = {
    "Circular spiral":    "circular",
    "Square spiral":      "square",
    "Hexagonal spiral":   "hexagonal",
    "Octagonal spiral":   "octagonal",
    "Rectangular spiral": "rectangular",
    "Solenoid":           "solenoid",
    "Conical helix":      "conical",
    "Multi-layer planar": "multilayer",
    "Double-D pad":       "DD",
}

CONDUCTOR_OPTIONS = ["Litz wire", "Solid round wire", "Copper foil/strip", "PCB trace"]
_COND_OF = {
    "Litz wire":         "litz",
    "Solid round wire":  "round",
    "Copper foil/strip": "foil",
    "PCB trace":         "pcb",
}


# ----------------------------------------------------------- GeometryForm
class GeometryForm(QFrame):
    changed = Signal()

    def __init__(self, *, default_geom: str = "Circular spiral",
                 prefix: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.params: dict = dict(
            N=10, Do=100, Di=60,
            a=200, b=150, Di_a=80, Di_b=40, gap_between=10,
            D=30, length=50, r_top=20, r_bot=40,
            n_layers=2, layer_spacing=1.6,
            w=1.0, s=0.5, wire_d=1.0,
        )
        self._kind = _SHAPE_OF[default_geom]
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._form = QFormLayout()
        layout.addLayout(self._form)
        self._kind_combo = labeled_combo(
            self._form, prefix + "Type", GEOMETRY_OPTIONS, default_geom,
            on_change=self._on_kind_change,
        )
        self._dynamic_form = QFormLayout()
        layout.addLayout(self._dynamic_form)
        self._rebuild_dynamic()

    def _on_kind_change(self, value: str) -> None:
        self._kind = _SHAPE_OF[value]
        self._rebuild_dynamic()
        self.changed.emit()

    def _clear_form(self, form: QFormLayout) -> None:
        while form.rowCount():
            form.removeRow(0)

    def _bind(self, key: str):
        def _on(v):
            self.params[key] = float(v)
            self.changed.emit()
        return _on

    def _rebuild_dynamic(self) -> None:
        self._clear_form(self._dynamic_form)
        k = self._kind
        p = self.params

        labeled_double(self._dynamic_form, "Turns N", p["N"], _min=0.5,
                       _max=200, step=0.5, on_change=self._bind("N"))
        if k in ("circular", "square", "hexagonal", "octagonal", "multilayer"):
            labeled_double(self._dynamic_form, "Outer Ø (mm)", p["Do"],
                           _min=1, _max=2000, step=1, on_change=self._bind("Do"))
            labeled_double(self._dynamic_form, "Inner Ø (mm)", p["Di"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("Di"))
            if k == "multilayer":
                labeled_int(self._dynamic_form, "Layers", int(p["n_layers"]),
                            _min=1, _max=16, on_change=self._bind("n_layers"))
                labeled_double(self._dynamic_form, "Layer spacing (mm)",
                               p["layer_spacing"], _min=0.01, _max=20, step=0.1,
                               on_change=self._bind("layer_spacing"))
        elif k in ("rectangular", "DD"):
            labeled_double(self._dynamic_form, "Outer a (mm)", p["a"],
                           _min=1, _max=2000, step=1, on_change=self._bind("a"))
            labeled_double(self._dynamic_form, "Outer b (mm)", p["b"],
                           _min=1, _max=2000, step=1, on_change=self._bind("b"))
            labeled_double(self._dynamic_form, "Inner a (mm)", p["Di_a"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("Di_a"))
            labeled_double(self._dynamic_form, "Inner b (mm)", p["Di_b"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("Di_b"))
            if k == "DD":
                labeled_double(self._dynamic_form, "Gap between Ds (mm)",
                               p["gap_between"], _min=0, _max=200, step=1,
                               on_change=self._bind("gap_between"))
        elif k == "solenoid":
            labeled_double(self._dynamic_form, "Diameter D (mm)", p["D"],
                           _min=1, _max=1000, step=1, on_change=self._bind("D"))
            labeled_double(self._dynamic_form, "Length (mm)", p["length"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("length"))
        elif k == "conical":
            labeled_double(self._dynamic_form, "Top r (mm)", p["r_top"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("r_top"))
            labeled_double(self._dynamic_form, "Bottom r (mm)", p["r_bot"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("r_bot"))
            labeled_double(self._dynamic_form, "Length (mm)", p["length"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("length"))
        labeled_double(self._dynamic_form, "Conductor w (mm)", p["w"],
                       _min=0.01, _max=50, step=0.05, on_change=self._bind("w"))
        labeled_double(self._dynamic_form, "Turn gap s (mm)", p["s"],
                       _min=0.01, _max=50, step=0.05, on_change=self._bind("s"))

    def build_geometry(self):
        p = self.params
        k = self._kind
        if k == "circular":
            return CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                                  w=p["w"]*1e-3, s=p["s"]*1e-3)
        if k in ("square", "hexagonal", "octagonal"):
            return PolygonalSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                                   w=p["w"]*1e-3, s=p["s"]*1e-3, shape=k)
        if k == "rectangular":
            return RectangularSpiral(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                                     Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                                     w=p["w"]*1e-3, s=p["s"]*1e-3)
        if k == "solenoid":
            return Solenoid(N=p["N"], D=p["D"]*1e-3, length=p["length"]*1e-3,
                            wire_d=p["w"]*1e-3)
        if k == "conical":
            return ConicalHelix(N=p["N"], r_top=p["r_top"]*1e-3,
                                r_bot=p["r_bot"]*1e-3, length=p["length"]*1e-3,
                                wire_d=p["w"]*1e-3)
        if k == "multilayer":
            base = CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                                  w=p["w"]*1e-3, s=p["s"]*1e-3)
            return MultiLayerSpiral(layer_geom=base, n_layers=int(p["n_layers"]),
                                    layer_spacing=p["layer_spacing"]*1e-3)
        if k == "DD":
            return DDPad(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                         Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                         w=p["w"]*1e-3, s=p["s"]*1e-3,
                         gap_between=p["gap_between"]*1e-3)
        raise ValueError(k)


# ----------------------------------------------------------- ConductorForm
class ConductorForm(QFrame):
    changed = Signal()

    def __init__(self, *, default: str = "Litz wire",
                 prefix: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.params: dict = dict(
            d=1.0, strand_d=71.0, n_strands=420,
            thickness=50.0, width=10.0, pitch=2.5,
        )
        self._kind = _COND_OF[default]
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._form = QFormLayout()
        layout.addLayout(self._form)
        self._kind_combo = labeled_combo(
            self._form, prefix + "Type", CONDUCTOR_OPTIONS, default,
            on_change=self._on_kind_change,
        )
        self._dynamic_form = QFormLayout()
        layout.addLayout(self._dynamic_form)
        self._rebuild_dynamic()

    def _on_kind_change(self, value: str) -> None:
        self._kind = _COND_OF[value]
        self._rebuild_dynamic()
        self.changed.emit()

    def _clear_form(self, form: QFormLayout) -> None:
        while form.rowCount():
            form.removeRow(0)

    def _bind(self, key: str):
        def _on(v):
            self.params[key] = float(v)
            self.changed.emit()
        return _on

    def _rebuild_dynamic(self) -> None:
        self._clear_form(self._dynamic_form)
        p = self.params
        k = self._kind
        if k == "round":
            labeled_double(self._dynamic_form, "Wire Ø (mm)", p["d"],
                           _min=0.05, _max=20, step=0.05,
                           on_change=self._bind("d"))
        elif k == "litz":
            labeled_double(self._dynamic_form, "Strand Ø (µm)", p["strand_d"],
                           _min=10, _max=500, step=1,
                           on_change=self._bind("strand_d"))
            labeled_int(self._dynamic_form, "# strands", int(p["n_strands"]),
                        _min=1, _max=10000, on_change=self._bind("n_strands"))
        elif k == "foil":
            labeled_double(self._dynamic_form, "Thickness (µm)", p["thickness"],
                           _min=1, _max=5000, step=1,
                           on_change=self._bind("thickness"))
            labeled_double(self._dynamic_form, "Width (mm)", p["width"],
                           _min=0.05, _max=200, step=0.1,
                           on_change=self._bind("width"))
        elif k == "pcb":
            labeled_double(self._dynamic_form, "Trace width (mm)", p["width"],
                           _min=0.05, _max=200, step=0.05,
                           on_change=self._bind("width"))
            labeled_double(self._dynamic_form, "Cu thickness (µm)", p["thickness"],
                           _min=1, _max=200, step=1,
                           on_change=self._bind("thickness"))
            labeled_double(self._dynamic_form, "Trace pitch (mm)", p["pitch"],
                           _min=0.05, _max=200, step=0.05,
                           on_change=self._bind("pitch"))

    def build_conductor(self):
        p = self.params
        k = self._kind
        if k == "round":
            return RoundWire(d=p["d"]*1e-3)
        if k == "litz":
            return LitzWire(strand_d=p["strand_d"]*1e-6,
                            n_strands=int(p["n_strands"]))
        if k == "foil":
            return FoilStrip(thickness=p["thickness"]*1e-6,
                             width=p["width"]*1e-3)
        if k == "pcb":
            return PCBTrace(width=p["width"]*1e-3,
                            thickness=p["thickness"]*1e-6,
                            pitch=p["pitch"]*1e-3)
        raise ValueError(k)
