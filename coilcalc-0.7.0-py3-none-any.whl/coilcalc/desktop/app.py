"""Main window for the coilcalc Qt desktop app."""
from __future__ import annotations

import sys

import qtawesome as qta
from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication, QIcon
from PySide6.QtWidgets import (
    QApplication, QFrame, QHBoxLayout, QLabel, QMainWindow, QTabWidget,
    QVBoxLayout, QWidget,
)

from . import theme as T
from .tab_pair import PairTab
from .tab_single import SingleCoilTab
from .tab_system import SystemTab
from .. import __version__


def _build_about() -> QWidget:
    w = QWidget()
    layout = QVBoxLayout(w)
    layout.setContentsMargins(40, 30, 40, 30)
    title = QLabel(f"coilcalc  ·  v{__version__}")
    title.setStyleSheet(f"color:{T.PRIMARY_HI}; font-size:24px; font-weight:700;")
    sub = QLabel("MR-WPT coil calculator — pure-Qt desktop edition.")
    sub.setStyleSheet(f"color:{T.TEXT_DIM}; font-size:14px; margin-bottom:18px;")
    body = QLabel(
        "<b>Geometries</b>: Circular / polygonal / rectangular spiral · "
        "solenoid · conical helix · multi-layer stack · DD pad.<br><br>"
        "<b>Conductors</b>: Solid round (Bessel) · Litz (Sullivan) · "
        "foil (Dowell) · PCB trace (Yue).<br><br>"
        "<b>Physics</b>: L via Mohan / Wheeler-Nagaoka / Zhao / Neumann + GMR; "
        "M via Maxwell coaxial + universal Neumann; Q includes turn-aware "
        "Biot-Savart proximity; SRF via Medhurst + GKMR + Yun; "
        "N-coil system η via full Z-matrix solver.<br><br>"
        "<b>UI</b>: PySide6 + PyQtGraph + QtAwesome.  No web engine."
    )
    body.setWordWrap(True)
    body.setStyleSheet(f"color:{T.TEXT}; font-size:13px;")
    layout.addWidget(title)
    layout.addWidget(sub)
    layout.addWidget(body)
    layout.addStretch()
    return w


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"coilcalc — MR-WPT coil calculator  v{__version__}")
        self.resize(1600, 1000)

        # ---- top header bar
        header = QFrame()
        header.setObjectName("header")
        header.setFixedHeight(56)
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(20, 0, 20, 0)

        bolt = QLabel()
        bolt.setPixmap(qta.icon("mdi.flash", color=T.PRIMARY).pixmap(28, 28))
        brand = QLabel("coilcalc")
        brand.setObjectName("brand")
        sub = QLabel(f"MR-WPT coil calculator · v{__version__}")
        sub.setObjectName("brand-sub")
        h_layout.addWidget(bolt)
        h_layout.addSpacing(8)
        h_layout.addWidget(brand)
        h_layout.addSpacing(10)
        h_layout.addWidget(sub)
        h_layout.addStretch()

        # ---- tabs
        tabs = QTabWidget()
        tabs.setDocumentMode(True)
        tabs.setMovable(False)
        single = SingleCoilTab()
        pair = PairTab()
        sysw = SystemTab()
        about = _build_about()
        tabs.addTab(single,  qta.icon("mdi.circle-outline", color=T.PRIMARY_HI), "  Single coil")
        tabs.addTab(pair,    qta.icon("mdi.link-variant",   color=T.PRIMARY_HI), "  Pair / coupling")
        tabs.addTab(sysw,    qta.icon("mdi.hubspot",        color=T.PRIMARY_HI), "  System (N-coil)")
        tabs.addTab(about,   qta.icon("mdi.information-outline", color=T.PRIMARY_HI), "  About")

        # ---- footer
        footer = QFrame()
        footer.setObjectName("footer")
        footer.setFixedHeight(28)
        f_layout = QHBoxLayout(footer)
        f_layout.setContentsMargins(20, 0, 20, 0)
        left = QLabel(f"coilcalc desktop · PySide6 + PyQtGraph · v{__version__}")
        left.setObjectName("footer-text")
        right = QLabel("© 2026 Bynarical")
        right.setObjectName("footer-text")
        f_layout.addWidget(left)
        f_layout.addStretch()
        f_layout.addWidget(right)

        # ---- assemble
        root = QWidget()
        root.setObjectName("root")
        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(header)
        outer.addWidget(tabs, 1)
        outer.addWidget(footer)
        self.setCentralWidget(root)


def run() -> int:
    qt_argv = [sys.argv[0]] if sys.argv else [""]
    app = QApplication.instance() or QApplication(qt_argv)
    app.setApplicationName("coilcalc")
    app.setOrganizationName("Bynarical")
    T.apply(app)

    win = MainWindow()
    win.setWindowIcon(qta.icon("mdi.flash", color=T.PRIMARY))
    win.show()

    # Centre on primary screen.
    screen = QGuiApplication.primaryScreen()
    if screen is not None:
        geom = screen.availableGeometry()
        win.move(geom.center() - win.rect().center())

    return app.exec()


if __name__ == "__main__":
    sys.exit(run())
