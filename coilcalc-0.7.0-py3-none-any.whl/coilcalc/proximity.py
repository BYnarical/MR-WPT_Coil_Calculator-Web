"""External-proximity helper: compute the squared H-field along a coil's
filament path due to all OTHER turns of the same coil.

This is the missing piece of Phase 1's R_ac estimate. The output is a single
scalar:

    ⟨H_ext / I⟩²  =  ⟨(1/I²) · |H_external|²⟩_path     [units: 1/m²]

averaged over the wire's length. The conductor models multiply this by the
appropriate Sullivan / Ferreira coefficient to obtain the additional R_ac
per unit length due to neighbouring turns.

Implementation: pre-compute Biot-Savart field from every filament segment at
every filament midpoint, **excluding segments closer than one wire-diameter**
so the local self-field contribution (which is already accounted for in the
intrinsic skin loss) is not double-counted.
"""
from __future__ import annotations

import math

import numpy as np


def biot_savart_along_path(
    path: np.ndarray,
    *,
    exclude_radius: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute H/I at the midpoint of each segment along ``path``.

    For each midpoint p_i, the field is the sum of Biot-Savart contributions
    from all segments j whose midpoint is **farther than ``exclude_radius``**
    from p_i (so the self-segment plus its immediate neighbours are removed).

    Args:
        path:           (M, 3) array of filament points.
        exclude_radius: radius around each midpoint inside which contributing
                        segments are skipped — typically ~ wire diameter so
                        the singular self-contribution is excluded.

    Returns:
        (H, seg_lengths) where
          H : (M-1, 3) Biot-Savart field per unit current at each midpoint
          seg_lengths : (M-1,) lengths of each segment.
    """
    diffs = np.diff(path, axis=0)            # (M-1, 3)
    mids = 0.5 * (path[:-1] + path[1:])       # (M-1, 3)
    seg_lens = np.linalg.norm(diffs, axis=1)  # (M-1,)
    M = mids.shape[0]

    H = np.zeros((M, 3), dtype=float)
    for i in range(M):
        # vector from each segment midpoint j to test point i
        r_vec = mids[i] - mids                      # (M, 3)
        r2 = np.einsum("ij,ij->i", r_vec, r_vec)
        r = np.sqrt(r2 + 1e-30)
        mask = r > exclude_radius
        if not np.any(mask):
            continue
        # Biot-Savart contribution dH = (1/(4π)) · (dl × r̂)/r²
        cross = np.cross(diffs[mask], r_vec[mask])   # dl × r_vec
        # cross / r³ then divided by 4π
        H[i] = (cross / (r[mask, None] ** 3)).sum(axis=0) / (4.0 * math.pi)

    return H, seg_lens


def mean_h_squared_per_amp(
    path: np.ndarray,
    *,
    wire_d: float,
) -> float:
    """Return ⟨|H/I|²⟩ averaged over the wire's length, in 1/m²."""
    H, seg_lens = biot_savart_along_path(path, exclude_radius=wire_d)
    H_sq = np.einsum("ij,ij->i", H, H)
    total_len = seg_lens.sum()
    return float(np.sum(H_sq * seg_lens) / total_len)
