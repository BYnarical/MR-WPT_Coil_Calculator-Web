"""EV-class polarised coil topologies built from rectangular sub-coils.

Each "pad" exposes ``filament_curve()`` as a *concatenated* polyline of its
constituent rectangular loops, so the universal Neumann integrator can compute
self-L and pad-to-pad M without special-casing.

Topologies:
- ``DDPad``        — two adjacent rectangular D-loops, series-connected, with
                     opposing winding direction so flux is horizontal between
                     them.
- ``DDQPad``       — DD plus a centred Quadrature coil decoupled from the DD.
- ``BipolarPad``   — two partially-overlapping rectangular coils with near-zero
                     mutual inductance.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .rectangular import RectangularSpiral


@dataclass
class DDPad:
    """Double-D pad: two coplanar rectangular D-loops side by side."""
    N: float                      # turns per D-loop
    a:  float                     # long side per D, m
    b:  float                     # short side per D, m
    Di_a: float
    Di_b: float
    w: float = 1.0e-3
    s: float = 0.5e-3
    gap_between: float = 5.0e-3   # gap between the two D's, m
    z: float = 0.0

    shape: str = "DD"

    def _make_subloops(self) -> tuple[RectangularSpiral, RectangularSpiral]:
        loop_l = RectangularSpiral(
            N=self.N, a=self.a, b=self.b,
            Di_a=self.Di_a, Di_b=self.Di_b,
            w=self.w, s=self.s, z=self.z,
        )
        loop_r = RectangularSpiral(
            N=self.N, a=self.a, b=self.b,
            Di_a=self.Di_a, Di_b=self.Di_b,
            w=self.w, s=self.s, z=self.z,
        )
        return loop_l, loop_r

    @property
    def d_avg(self) -> float:
        return 0.5 * (self.a + self.Di_a)

    @property
    def rho(self) -> float:
        peri_o = 2 * (self.a + self.b)
        peri_i = 2 * (self.Di_a + self.Di_b)
        return (peri_o - peri_i) / (peri_o + peri_i)

    def wire_length(self) -> float:
        loop_l, loop_r = self._make_subloops()
        return loop_l.wire_length() + loop_r.wire_length()

    def filament_curve(self, n_points_per_turn: int = 200) -> np.ndarray:
        """Return concatenated path of the two D-loops.

        Loop A is offset to x = +(a/2 + gap/2). Loop B is offset to
        x = −(a/2 + gap/2) and traversed in the *opposite* sense so currents
        flow oppositely (defining flux horizontally).
        """
        offset = self.a / 2 + self.gap_between / 2
        loop_l, loop_r = self._make_subloops()
        p_l = loop_l.filament_curve(n_points_per_turn)
        p_r = loop_r.filament_curve(n_points_per_turn)
        p_l = p_l.copy();  p_l[:, 0] -= offset
        p_r = p_r.copy();  p_r[:, 0] += offset
        # Reverse loop_r so it is traversed in opposite winding direction.
        p_r = p_r[::-1]
        return np.concatenate([p_l, p_r], axis=0)


@dataclass
class DDQPad(DDPad):
    """DD + centred Quadrature coil (orthogonal flux pickup)."""
    q_a: float = 0.0     # quadrature coil length
    q_b: float = 0.0     # quadrature coil width
    q_Di_a: float = 0.0
    q_Di_b: float = 0.0
    q_N: float = 0.0
    q_z: float = 5.0e-3  # height above the DD plane

    shape: str = "DDQ"

    def filament_curve(self, n_points_per_turn: int = 200) -> np.ndarray:
        dd_path = super().filament_curve(n_points_per_turn)
        if self.q_N <= 0 or self.q_a <= 0:
            return dd_path
        q = RectangularSpiral(
            N=self.q_N, a=self.q_a, b=self.q_b,
            Di_a=self.q_Di_a, Di_b=self.q_Di_b,
            w=self.w, s=self.s, z=self.z + self.q_z,
        )
        return np.concatenate([dd_path, q.filament_curve(n_points_per_turn)], axis=0)

    def wire_length(self) -> float:
        base = super().wire_length()
        if self.q_N <= 0 or self.q_a <= 0:
            return base
        q = RectangularSpiral(
            N=self.q_N, a=self.q_a, b=self.q_b,
            Di_a=self.q_Di_a, Di_b=self.q_Di_b,
            w=self.w, s=self.s, z=self.z + self.q_z,
        )
        return base + q.wire_length()


@dataclass
class BipolarPad:
    """Two partially-overlapping rectangular coils (overlap chosen so M_12 ≈ 0)."""
    N: float
    a: float
    b: float
    Di_a: float
    Di_b: float
    overlap_frac: float = 0.32   # canonical 32 % overlap zeroes M for square BPP
    w: float = 1.0e-3
    s: float = 0.5e-3
    z: float = 0.0

    shape: str = "BPP"

    @property
    def d_avg(self) -> float:
        return 0.5 * (self.a + self.Di_a)

    @property
    def rho(self) -> float:
        peri_o = 2 * (self.a + self.b)
        peri_i = 2 * (self.Di_a + self.Di_b)
        return (peri_o - peri_i) / (peri_o + peri_i)

    def wire_length(self) -> float:
        sub = RectangularSpiral(N=self.N, a=self.a, b=self.b,
                                Di_a=self.Di_a, Di_b=self.Di_b,
                                w=self.w, s=self.s, z=self.z)
        return 2.0 * sub.wire_length()

    def filament_curve(self, n_points_per_turn: int = 200) -> np.ndarray:
        sub = RectangularSpiral(N=self.N, a=self.a, b=self.b,
                                Di_a=self.Di_a, Di_b=self.Di_b,
                                w=self.w, s=self.s, z=self.z)
        offset = (self.a / 2) * (1.0 - self.overlap_frac)
        p1 = sub.filament_curve(n_points_per_turn)
        p2 = sub.filament_curve(n_points_per_turn)
        p1 = p1.copy(); p1[:, 0] -= offset
        p2 = p2.copy(); p2[:, 0] += offset
        return np.concatenate([p1, p2], axis=0)
