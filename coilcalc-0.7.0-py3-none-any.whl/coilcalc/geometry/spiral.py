"""Planar spiral geometry (circular and polygonal).

Convention (SI):
  N   - number of turns
  Do  - outer diameter, m
  Di  - inner diameter, m
  w   - conductor width / wire diameter, m  (informational here; used by Rac/SRF)
  s   - turn-to-turn gap, m                  (informational)
  z   - vertical offset from origin, m
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import numpy as np

SpiralShape = Literal["circular", "square", "hexagonal", "octagonal"]


@dataclass
class _SpiralBase:
    N: float
    Do: float
    Di: float
    w: float = 0.5e-3
    s: float = 0.3e-3
    z: float = 0.0

    def __post_init__(self) -> None:
        if self.Do <= self.Di:
            raise ValueError("Do must be greater than Di")
        if self.N <= 0:
            raise ValueError("N must be > 0")

    @property
    def d_avg(self) -> float:
        return 0.5 * (self.Do + self.Di)

    @property
    def rho(self) -> float:
        """Mohan fill ratio (Do-Di)/(Do+Di)."""
        return (self.Do - self.Di) / (self.Do + self.Di)

    @property
    def r_avg(self) -> float:
        return 0.25 * (self.Do + self.Di)

    def wire_length(self) -> float:
        """Approximate total conductor length, m."""
        return self.N * np.pi * self.d_avg  # tight for circular; ~2 % off for square


@dataclass
class CircularSpiral(_SpiralBase):
    """Archimedean (planar) circular spiral."""
    shape: SpiralShape = "circular"

    def filament_curve(self, n_points_per_turn: int = 90) -> np.ndarray:
        """Return (M, 3) Archimedean spiral points from inner to outer radius."""
        n_pts = int(max(2, round(self.N * n_points_per_turn)))
        t = np.linspace(0.0, self.N, n_pts)
        r_in = 0.5 * self.Di
        r_out = 0.5 * self.Do
        r = r_in + (r_out - r_in) * (t / self.N)
        theta = 2.0 * np.pi * t
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        z = np.full_like(x, self.z)
        return np.stack([x, y, z], axis=1)


@dataclass
class PolygonalSpiral(_SpiralBase):
    """Polygonal planar spiral (square / hex / octagon).

    Discretised as N concentric polygons with linearly-interpolated side length.
    """
    shape: SpiralShape = "square"

    _SIDES = {"square": 4, "hexagonal": 6, "octagonal": 8}

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.shape not in self._SIDES:
            raise ValueError(f"PolygonalSpiral.shape must be one of {list(self._SIDES)}")

    @property
    def n_sides(self) -> int:
        return self._SIDES[self.shape]

    def filament_curve(self, n_points_per_turn: int | None = None) -> np.ndarray:
        nsides = self.n_sides
        n_pts_turn = n_points_per_turn or max(8, 4 * nsides)
        n_pts = int(self.N * n_pts_turn) + 1

        t = np.linspace(0.0, self.N, n_pts)
        r_in = 0.5 * self.Di
        r_out = 0.5 * self.Do
        r = r_in + (r_out - r_in) * (t / self.N)
        theta = 2.0 * np.pi * t
        # Polygon radial modulation: vertex at theta = 2π·k/nsides.
        phi = (theta * nsides / (2.0 * np.pi)) % 1.0   # 0..1 within a side
        # Distance from polygon centre to side midpoint = R·cos(π/nsides);
        # to vertex = R. Interpolate via cos of local angle.
        local = (phi - 0.5) * (2.0 * np.pi / nsides)
        r_poly = r * np.cos(np.pi / nsides) / np.cos(local)
        x = r_poly * np.cos(theta)
        y = r_poly * np.sin(theta)
        z = np.full_like(x, self.z)
        return np.stack([x, y, z], axis=1)
