"""Rectangular planar spiral (a × b outer footprint).

Used as the base shape for EV-class pads (DD, DDQ, BPP).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RectangularSpiral:
    """Rectangular Archimedean spiral with rounded corners.

    Args:
        N:        number of turns
        a:        outer length (long side), m
        b:        outer width  (short side), m
        Di_a:     inner length, m
        Di_b:     inner width,  m
        w, s, z:  conductor width, turn gap, z-offset, m
    """
    N: float
    a: float
    b: float
    Di_a: float
    Di_b: float
    w: float = 1.0e-3
    s: float = 0.5e-3
    z: float = 0.0

    shape: str = "rectangle"

    def __post_init__(self) -> None:
        if self.a <= self.Di_a or self.b <= self.Di_b:
            raise ValueError("Outer dims must exceed inner dims.")
        if self.N <= 0:
            raise ValueError("N must be > 0")

    @property
    def d_avg(self) -> float:
        return 0.5 * ((self.a + self.Di_a) + (self.b + self.Di_b)) / 2.0

    @property
    def rho(self) -> float:
        peri_o = 2 * (self.a + self.b)
        peri_i = 2 * (self.Di_a + self.Di_b)
        return (peri_o - peri_i) / (peri_o + peri_i)

    def wire_length(self) -> float:
        per_turn = 2.0 * (self.a + self.b - (self.w + self.s))   # approx 2(a+b) per turn
        return self.N * (per_turn - (self.N - 1) * (self.w + self.s))

    def filament_curve(self, n_points_per_turn: int = 200) -> np.ndarray:
        n_pts = int(self.N * n_points_per_turn) + 1
        t = np.linspace(0.0, self.N, n_pts)
        # Parametric rectangle: walk perimeter, with linearly shrinking half-extents.
        ax = self.a / 2 + (self.Di_a - self.a) / 2 * (t / self.N)
        ay = self.b / 2 + (self.Di_b - self.b) / 2 * (t / self.N)
        # Phase around rectangle: 0→1 traverses perimeter once. Each turn = +1.
        phi = (t * 4.0) % 4.0
        x = np.zeros_like(t)
        y = np.zeros_like(t)
        for i, p in enumerate(phi):
            if p < 1.0:
                x[i] = ax[i] - 2 * ax[i] * p
                y[i] = ay[i]
            elif p < 2.0:
                x[i] = -ax[i]
                y[i] = ay[i] - 2 * ay[i] * (p - 1)
            elif p < 3.0:
                x[i] = -ax[i] + 2 * ax[i] * (p - 2)
                y[i] = -ay[i]
            else:
                x[i] = ax[i]
                y[i] = -ay[i] + 2 * ay[i] * (p - 3)
        z = np.full_like(t, self.z)
        return np.stack([x, y, z], axis=1)
