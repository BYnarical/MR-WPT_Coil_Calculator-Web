"""Conical (dome) helix and stacked multi-layer planar geometry."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import numpy as np


@dataclass
class ConicalHelix:
    """Conical / dome helix with linearly-varying radius along z.

    Args:
        N:        turns
        r_top:    top radius, m
        r_bot:    bottom radius, m
        length:   axial length, m
        wire_d:   wire diameter, m (informational)
        z0:       z-offset of bottom plane, m
    """
    N: float
    r_top: float
    r_bot: float
    length: float
    wire_d: float = 1.0e-3
    z0: float = 0.0

    def __post_init__(self) -> None:
        if self.length <= 0 or self.N <= 0:
            raise ValueError("length, N must be > 0")

    @property
    def r_avg(self) -> float:
        return 0.5 * (self.r_top + self.r_bot)

    @property
    def d_avg(self) -> float:
        return 2.0 * self.r_avg

    def wire_length(self) -> float:
        # ∑ over turns of √((2πr_i)² + pitch²); approximate via average radius.
        pitch = self.length / self.N
        return self.N * np.sqrt((2 * np.pi * self.r_avg) ** 2 + pitch ** 2)

    def filament_curve(self, n_points_per_turn: int = 60) -> np.ndarray:
        n_pts = int(max(2, round(self.N * n_points_per_turn)))
        t = np.linspace(0.0, self.N, n_pts)
        theta = 2.0 * np.pi * t
        z = self.z0 + self.length * (t / self.N)
        # linear taper bottom→top
        r = self.r_bot + (self.r_top - self.r_bot) * (t / self.N)
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        return np.stack([x, y, z], axis=1)


@dataclass
class MultiLayerSpiral:
    """N stacked identical planar spirals, series-connected through vias.

    The constituent ``layer_geom`` defines the geometry of each layer; the
    stack repeats with vertical spacing ``layer_spacing``. All layers are
    traversed in the same winding direction (series-aiding).
    """
    layer_geom: object              # CircularSpiral / PolygonalSpiral / RectangularSpiral
    n_layers: int = 2
    layer_spacing: float = 1.6e-3   # FR-4 prepreg ≈ 1.6 mm

    shape: str = "multilayer"

    def __post_init__(self) -> None:
        if self.n_layers < 1:
            raise ValueError("n_layers must be >= 1")

    @property
    def d_avg(self) -> float:
        return float(self.layer_geom.d_avg)

    @property
    def rho(self) -> float:
        return float(self.layer_geom.rho)

    def wire_length(self) -> float:
        return self.n_layers * float(self.layer_geom.wire_length())

    def filament_curve(self, n_points_per_turn: int = 60) -> np.ndarray:
        parts: List[np.ndarray] = []
        for k in range(self.n_layers):
            p = self.layer_geom.filament_curve(n_points_per_turn).copy()
            p[:, 2] += k * self.layer_spacing
            # Every other layer flips direction so the vias connect cleanly.
            if k % 2 == 1:
                p = p[::-1]
            parts.append(p)
        return np.concatenate(parts, axis=0)
