"""Coil geometry primitives.

Each geometry exposes:
- field-relevant parameters (N, dimensions, fill ratio)
- a `filament_curve(...)` method returning a discretised 3-D path for the
  universal Neumann integrator
- a shape tag that drives the analytical inductance formula chosen.
"""
from .spiral import CircularSpiral, PolygonalSpiral, SpiralShape  # noqa: F401
from .solenoid import Solenoid  # noqa: F401
from .rectangular import RectangularSpiral  # noqa: F401
from .conical import ConicalHelix, MultiLayerSpiral  # noqa: F401
from .ev_pads import BipolarPad, DDPad, DDQPad  # noqa: F401
