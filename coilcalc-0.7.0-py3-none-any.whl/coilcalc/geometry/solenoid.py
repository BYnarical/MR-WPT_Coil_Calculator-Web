"""Single-layer cylindrical helical (solenoid) geometry."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class Solenoid:
    """Single-layer cylindrical helical coil.

    Args:
        N: number of turns
        D: mean diameter, m
        length: axial length (pitch * N), m
        wire_d: conductor diameter, m (informational; used by Rac/SRF)
        z0: axial offset of the lower end, m (default 0 → solenoid centred on z=length/2)
    """
    N: float
    D: float
    length: float
    wire_d: float = 1.0e-3
    z0: float = 0.0

    def __post_init__(self) -> None:
        if self.D <= 0 or self.length <= 0 or self.N <= 0:
            raise ValueError("D, length, N must all be > 0")

    @property
    def radius(self) -> float:
        return 0.5 * self.D

    @property
    def pitch(self) -> float:
        return self.length / self.N

    @property
    def form_factor(self) -> float:
        """Solenoid form factor x = D/length (used by Nagaoka)."""
        return self.D / self.length

    def wire_length(self) -> float:
        circ = np.pi * self.D
        return self.N * np.sqrt(circ**2 + self.pitch**2)

    def filament_curve(self, n_points_per_turn: int = 60) -> np.ndarray:
        n_pts = int(max(2, round(self.N * n_points_per_turn)))
        t = np.linspace(0.0, self.N, n_pts)
        theta = 2.0 * np.pi * t
        r = self.radius
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        z = self.z0 + self.length * (t / self.N)
        return np.stack([x, y, z], axis=1)
