"""Typer command-line interface for coilcalc."""
from __future__ import annotations

import re
import sys
from typing import Optional

# Force UTF-8 stdout so the µ symbol etc. render correctly on Windows code-page
# 949 / 1252 consoles. Must happen before rich.Console is instantiated.
try:
    sys.stdout.reconfigure(encoding="utf-8")
except (AttributeError, OSError):
    pass

import typer
from rich.console import Console
from rich.table import Table

from .api import Coil, MutualPair
from .conductors import FoilStrip, LitzWire, RoundWire
from .geometry.solenoid import Solenoid
from .geometry.spiral import CircularSpiral, PolygonalSpiral

app = typer.Typer(add_completion=False, help="MR-WPT coil calculator (Phase 1 MVP).")
console = Console()


# --------------------------------------------------------------------- helpers
_LITZ_RE = re.compile(r"^\s*(\d+)\s*[xX*]\s*([\d.]+)\s*(um|µm|mm)\s*$")


def _parse_conductor(round_d: Optional[float], litz: Optional[str],
                     foil: Optional[str]) -> object:
    flags = sum(x is not None for x in (round_d, litz, foil))
    if flags != 1:
        raise typer.BadParameter("Provide exactly one of --wire-d / --litz / --foil.")
    if round_d is not None:
        return RoundWire(d=round_d * 1e-3)              # mm → m
    if litz is not None:
        m = _LITZ_RE.match(litz)
        if not m:
            raise typer.BadParameter(
                "Litz spec must look like  420x71um  or  300x100um.")
        n, ds, unit = int(m.group(1)), float(m.group(2)), m.group(3)
        ds_m = ds * 1e-6 if unit in ("um", "µm") else ds * 1e-3
        return LitzWire(strand_d=ds_m, n_strands=n)
    # foil 'thickness_mm x width_mm'
    m = re.match(r"^\s*([\d.]+)\s*[xX*]\s*([\d.]+)\s*$", foil)  # type: ignore[arg-type]
    if not m:
        raise typer.BadParameter("Foil spec must look like  0.05x10  (thickness_mm x width_mm).")
    h, b = float(m.group(1)), float(m.group(2))
    return FoilStrip(thickness=h * 1e-3, width=b * 1e-3)


def _print_summary(label: str, summary: dict) -> None:
    table = Table(title=label, show_header=True, header_style="bold")
    table.add_column("Quantity")
    table.add_column("Value", justify="right")
    for k, v in summary.items():
        if isinstance(v, dict):
            continue
        table.add_row(k, f"{v:.4g}")
    console.print(table)


# --------------------------------------------------------------------- spiral
@app.command()
def spiral(
    N:  float = typer.Option(..., "--N", help="Number of turns"),
    Do: float = typer.Option(..., "--Do", help="Outer diameter, mm"),
    Di: float = typer.Option(..., "--Di", help="Inner diameter, mm"),
    shape: str = typer.Option("circular", "--shape",
                              help="circular | square | hexagonal | octagonal"),
    w:  float = typer.Option(0.5, "--w", help="Conductor width / wire diameter, mm"),
    s:  float = typer.Option(0.3, "--s", help="Turn-to-turn gap, mm"),
    f:  float = typer.Option(6.78e6, "--f", help="Frequency, Hz"),
    wire_d: Optional[float] = typer.Option(None, "--wire-d",
                                           help="Solid round wire diameter, mm"),
    litz: Optional[str] = typer.Option(None, "--litz",
                                       help="Litz spec e.g. '420x71um'"),
    foil: Optional[str] = typer.Option(None, "--foil",
                                       help="Foil spec mm e.g. '0.05x10'"),
):
    """Analyse a single planar spiral."""
    cond = _parse_conductor(wire_d, litz, foil)
    if shape == "circular":
        geom = CircularSpiral(N=N, Do=Do * 1e-3, Di=Di * 1e-3,
                              w=w * 1e-3, s=s * 1e-3)
    else:
        geom = PolygonalSpiral(N=N, Do=Do * 1e-3, Di=Di * 1e-3,
                               w=w * 1e-3, s=s * 1e-3, shape=shape)  # type: ignore[arg-type]
    coil = Coil(geometry=geom, conductor=cond)
    _print_summary(f"Spiral ({shape}, N={N}, Do={Do} mm, Di={Di} mm) @ {f:.3g} Hz",
                   coil.summary(f))


# --------------------------------------------------------------------- solenoid
@app.command()
def solenoid(
    N:      float = typer.Option(..., "--N", help="Number of turns"),
    D:      float = typer.Option(..., "--D", help="Mean diameter, mm"),
    length: float = typer.Option(..., "--length", help="Coil length, mm"),
    f:      float = typer.Option(200e3, "--f", help="Frequency, Hz"),
    wire_d: Optional[float] = typer.Option(None, "--wire-d",
                                           help="Solid round wire diameter, mm"),
    litz:   Optional[str] = typer.Option(None, "--litz",
                                         help="Litz spec, e.g. '300x100um'"),
    foil:   Optional[str] = typer.Option(None, "--foil",
                                         help="Foil spec, e.g. '0.1x5'"),
):
    """Analyse a single-layer solenoid."""
    cond = _parse_conductor(wire_d, litz, foil)
    wd = (wire_d or 1.0) * 1e-3
    geom = Solenoid(N=N, D=D * 1e-3, length=length * 1e-3, wire_d=wd)
    coil = Coil(geometry=geom, conductor=cond)
    _print_summary(f"Solenoid (N={N}, D={D} mm, ℓ={length} mm) @ {f:.3g} Hz",
                   coil.summary(f))


# --------------------------------------------------------------------- pair
def _spec_to_spiral(spec: str) -> CircularSpiral:
    """Parse 'N,Do,Di' (Do, Di in mm) into a CircularSpiral."""
    parts = [p.strip() for p in spec.split(",")]
    if len(parts) != 3:
        raise typer.BadParameter("Spiral spec must be 'N,Do,Di' with Do,Di in mm")
    N, Do, Di = float(parts[0]), float(parts[1]), float(parts[2])
    return CircularSpiral(N=N, Do=Do * 1e-3, Di=Di * 1e-3)


@app.command()
def pair(
    tx_spiral: str = typer.Option(..., "--tx-spiral",
                                  help="'N,Do,Di' of Tx coil, in mm"),
    rx_spiral: str = typer.Option(..., "--rx-spiral",
                                  help="'N,Do,Di' of Rx coil, in mm"),
    gap:      float = typer.Option(20.0, help="Vertical gap Tx→Rx, mm"),
    lateral:  float = typer.Option(0.0,  help="Lateral offset, mm"),
    tilt:     float = typer.Option(0.0,  help="Tilt angle, deg"),
    f:        float = typer.Option(6.78e6, help="Frequency, Hz"),
    wire_d:   Optional[float] = typer.Option(None, "--wire-d",
                                             help="Round-wire diameter, mm"),
    litz:     Optional[str] = typer.Option("420x71um", help="Litz spec"),
):
    """Compute mutual inductance and coupling between a Tx and Rx coil pair."""
    cond = _parse_conductor(wire_d, litz, None)
    tx = Coil(_spec_to_spiral(tx_spiral), cond)
    rx = Coil(_spec_to_spiral(rx_spiral), cond)
    p = MutualPair(tx, rx, gap=gap * 1e-3, lateral=lateral * 1e-3, tilt_deg=tilt)
    s = p.summary(f)
    console.print(
        f"[bold]Mutual:[/]  M = {s['M_uH']:.3f} µH    k = {s['k']:.4f}")
    _print_summary("Tx", s["tx"])
    _print_summary("Rx", s["rx"])


# --------------------------------------------------------------------- gui
@app.command()
def gui(
    port:   int  = typer.Option(8765, "--port", help="Local port to serve on"),
    native: bool = typer.Option(False, "--native",
                                help="Open a native desktop window (needs pywebview)"),
):
    """Launch the coilcalc desktop GUI in your browser (or native window)."""
    try:
        from . import gui as gui_mod
    except ImportError:
        console.print("[bold red]GUI deps not installed.[/]  "
                      "Run:  [cyan]pip install 'coilcalc[gui]'[/]")
        raise typer.Exit(code=1)
    gui_mod.run_gui(port=port, native=native)


# --------------------------------------------------------------------- main
def main() -> None:
    app()


if __name__ == "__main__":
    main()
