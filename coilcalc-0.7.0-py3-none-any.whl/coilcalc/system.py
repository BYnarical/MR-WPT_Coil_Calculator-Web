"""N-coil MR-WPT system solver.

For N coils each tuned to resonance at angular frequency ω with capacitor
C_i = 1/(ω²·L_i), the KVL system at steady state is:

    Z · I = V

where Z is the N×N impedance matrix with:
    Z_ii = R_i + R_load_i (only on the loaded coil)
    Z_ij = jω·M_ij                                            for i ≠ j

(All terms involving L and C cancel at resonance.) The first coil is driven
by a sinusoidal source V_s, all other coils are short-circuited through their
resonant capacitors except for the designated load coil(s), which carry R_load.

This module computes:
- coil currents I_i
- input/output power, link efficiency
- gain Vout/Vin
- sweeps over coupling / load / frequency
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import numpy as np

from .api import Coil, MutualPair


# --------------------------------------------------------------------- builder
def build_LM_matrix(coils: Sequence[Coil],
                    positions: Sequence[Tuple[float, float, float]],
                    *,
                    f: float = 100e3,
                    n_points_per_turn: int = 60) -> Tuple[np.ndarray, np.ndarray]:
    """Return (L_vec, M_matrix) for N coils placed at given (x, y, z) positions.

    L_vec is length-N self-inductances (ferrite-aware via ``Coil.L(f)``);
    M_matrix is the symmetric N×N mutual-inductance matrix with zero
    diagonal. Each coil's ferrite contributes image-method reflections to
    every pairwise M.
    """
    from .mutual import neumann_filaments

    N = len(coils)
    if len(positions) != N:
        raise ValueError("coils and positions must have the same length")

    L_vec = np.array([c.L(f) for c in coils], dtype=float)
    M = np.zeros((N, N), dtype=float)

    # Build absolute paths for each coil.
    paths = []
    for c, p in zip(coils, positions):
        path = c.geometry.filament_curve(n_points_per_turn).copy()
        path[:, 0] += p[0]
        path[:, 1] += p[1]
        path[:, 2] += p[2]
        paths.append(path)

    # For each coil, pre-compute its list of (image_path, alpha) at the
    # working frequency.
    images: list[list[tuple[np.ndarray, float]]] = []
    for c, p, path in zip(coils, positions, paths):
        if c.ferrite is None:
            images.append([])
        else:
            images.append(list(c.ferrite.image_paths(path, p[2], f)))

    for i in range(N):
        for j in range(i + 1, N):
            m = neumann_filaments(paths[i], paths[j])
            for img_i, ai in images[i]:
                m += ai * neumann_filaments(img_i, paths[j])
            for img_j, aj in images[j]:
                m += aj * neumann_filaments(paths[i], img_j)
            for img_i, ai in images[i]:
                for img_j, aj in images[j]:
                    m += ai * aj * neumann_filaments(img_i, img_j)
            M[i, j] = m
            M[j, i] = m
    return L_vec, M


# --------------------------------------------------------------------- solver
@dataclass
class WPTSystem:
    """Series-resonant N-coil MR-WPT system.

    All coils are assumed series-capacitor-tuned to the operating frequency f.
    Coil 0 is the source coil driven by ``V_source`` (V rms). Coil
    ``load_index`` carries the load resistance ``R_load`` (Ω). Other coils are
    intermediate resonators (drive loop, relay, etc.) with only their own R_ac.

    Provide either:
        coils & positions  →  Mutual inductance auto-computed.
        L_vec, M, R_vec    →  Pre-computed matrices (skips geometry).
    """
    coils: Optional[Sequence[Coil]] = None
    positions: Optional[Sequence[Tuple[float, float, float]]] = None
    L_vec: Optional[np.ndarray] = None
    M:     Optional[np.ndarray] = None
    R_vec: Optional[np.ndarray] = None

    load_index: int = -1                  # -1 → last coil is the load
    R_load:     float = 50.0
    V_source:   float = 1.0
    f:          float = 6.78e6

    # Cached after solve.
    _I: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # ------------------------------------------------------------------ build
    def _ensure_matrices(self) -> None:
        if self.L_vec is not None and self.M is not None and self.R_vec is not None:
            return
        if self.coils is None or self.positions is None:
            raise ValueError("Provide either matrices or (coils + positions).")
        self.L_vec, self.M = build_LM_matrix(self.coils, self.positions, f=self.f)
        self.R_vec = np.array([c.Rac(self.f) for c in self.coils], dtype=float)

    # ------------------------------------------------------------------ solve
    def solve(self) -> dict:
        self._ensure_matrices()
        N = len(self.L_vec)
        omega = 2.0 * math.pi * self.f
        load_idx = self.load_index % N

        Z = np.zeros((N, N), dtype=complex)
        # All coils resonant, so only the R_ac (plus the load) appears on the diagonal.
        for i in range(N):
            Z[i, i] = self.R_vec[i]
        Z[load_idx, load_idx] += self.R_load
        for i in range(N):
            for j in range(N):
                if i != j:
                    Z[i, j] = 1j * omega * self.M[i, j]

        V = np.zeros(N, dtype=complex)
        V[0] = self.V_source

        I = np.linalg.solve(Z, V)
        self._I = I

        P_in    = 0.5 * np.real(np.conj(V) @ I)             # real input power
        P_load  = 0.5 * self.R_load * abs(I[load_idx]) ** 2
        P_loss  = 0.5 * sum(self.R_vec[i] * abs(I[i]) ** 2 for i in range(N))
        eta     = P_load / (P_load + P_loss) if (P_load + P_loss) > 0 else 0.0
        V_out   = self.R_load * I[load_idx]

        return {
            "I":      I,
            "P_in":   P_in,
            "P_load": P_load,
            "P_loss": P_loss,
            "eta":    eta,
            "V_out":  V_out,
            "gain":   abs(V_out / self.V_source),
        }

    # ------------------------------------------------------------------ k
    def coupling_matrix(self) -> np.ndarray:
        self._ensure_matrices()
        N = len(self.L_vec)
        K = np.zeros((N, N), dtype=float)
        for i in range(N):
            for j in range(N):
                if i != j:
                    K[i, j] = self.M[i, j] / math.sqrt(self.L_vec[i] * self.L_vec[j])
        return K


# --------------------------------------------------------------------- helpers
def domino_chain(coil: Coil, n: int, spacing: float,
                 *,
                 R_load: float = 50.0,
                 V_source: float = 1.0,
                 f: float = 6.78e6) -> WPTSystem:
    """Build a relay/domino chain of n identical coils along the z-axis.

    Coil 0 is driven, coil n-1 is the load, coils 1..n-2 are intermediate
    resonators.
    """
    coils = [coil for _ in range(n)]
    positions = [(0.0, 0.0, k * spacing) for k in range(n)]
    return WPTSystem(coils=coils, positions=positions,
                     load_index=n - 1, R_load=R_load, V_source=V_source, f=f)


def four_coil_system(driver: Coil, tx_res: Coil, rx_res: Coil, load_loop: Coil,
                     *,
                     gap_driver_tx: float,
                     gap_tx_rx: float,
                     gap_rx_load: float,
                     R_load: float = 50.0,
                     V_source: float = 1.0,
                     f: float = 6.78e6) -> WPTSystem:
    """Classic 4-coil (Soljačić) MR-WPT system.

    Arrangement along the z-axis:
        driver loop  →  Tx resonator  →  Rx resonator  →  load loop
    The driver loop is the input port; the load loop carries the load.
    """
    coils = [driver, tx_res, rx_res, load_loop]
    z = 0.0
    positions = [(0.0, 0.0, 0.0)]
    z += gap_driver_tx;   positions.append((0.0, 0.0, z))
    z += gap_tx_rx;       positions.append((0.0, 0.0, z))
    z += gap_rx_load;     positions.append((0.0, 0.0, z))
    return WPTSystem(coils=coils, positions=positions,
                     load_index=3, R_load=R_load, V_source=V_source, f=f)


def multi_tx(coils_tx: Sequence[Coil],
             positions_tx: Sequence[Tuple[float, float, float]],
             rx_coil: Coil,
             rx_pos: Tuple[float, float, float],
             *,
             R_load: float = 50.0,
             V_source: float = 1.0,
             f: float = 6.78e6) -> WPTSystem:
    """Build a multi-Tx array with a single Rx (load).

    Only coil 0 has the source voltage applied — to model phased arrays with
    multiple driven sources, set V_source = 0 and supply your own V vector
    via the lower-level API in :class:`WPTSystem`. (Phase 4 will expose this
    directly.)
    """
    coils = list(coils_tx) + [rx_coil]
    positions = list(positions_tx) + [rx_pos]
    return WPTSystem(coils=coils, positions=positions,
                     load_index=len(coils) - 1,
                     R_load=R_load, V_source=V_source, f=f)
