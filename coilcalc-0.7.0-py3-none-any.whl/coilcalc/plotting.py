"""Plotly plotting helpers (optional — requires ``pip install coilcalc[plot]``).

All functions return Plotly Figure objects; they don't show or save by default.
"""
from __future__ import annotations

from typing import Optional, Sequence

import numpy as np

try:
    import plotly.graph_objects as go
except ImportError:                                          # pragma: no cover
    go = None                                                # type: ignore[assignment]


def _require_plotly() -> None:
    if go is None:
        raise ImportError("plotly is required: pip install 'coilcalc[plot]'")


# --------------------------------------------------------------------- 3D coil
def plot_coil_3d(coil, *, title: Optional[str] = None):
    """Render a coil's filament path in 3-D."""
    _require_plotly()
    pts = coil.geometry.filament_curve()
    fig = go.Figure(
        data=[go.Scatter3d(x=pts[:, 0] * 1e3, y=pts[:, 1] * 1e3, z=pts[:, 2] * 1e3,
                           mode="lines", line=dict(width=4))],
        layout=go.Layout(
            title=title or f"{type(coil.geometry).__name__}",
            scene=dict(xaxis_title="x (mm)", yaxis_title="y (mm)",
                       zaxis_title="z (mm)", aspectmode="data"),
        ),
    )
    return fig


# --------------------------------------------------------------------- k sweep
def plot_k_sweep(xs: Sequence[float], ks: Sequence[float],
                 *, x_label: str = "offset (mm)", title: str = "k vs offset"):
    _require_plotly()
    fig = go.Figure(
        data=[go.Scatter(x=np.asarray(xs) * 1e3, y=ks, mode="lines+markers")],
        layout=go.Layout(title=title, xaxis_title=x_label, yaxis_title="k"),
    )
    return fig


# --------------------------------------------------------------------- η vs gap
def plot_efficiency_vs_gap(system, gaps_m: Sequence[float], *,
                           moving_index: int = 1,
                           title: str = "η vs gap"):
    """Sweep one coil's z-position and plot link efficiency."""
    _require_plotly()
    etas = []
    z0 = list(system.positions[moving_index])  # type: ignore[index]
    for g in gaps_m:
        new_pos = list(system.positions)         # type: ignore[arg-type]
        new_pos[moving_index] = (z0[0], z0[1], g)
        system.positions = new_pos               # type: ignore[assignment]
        system.L_vec = None
        system.M = None
        system.R_vec = None
        etas.append(system.solve()["eta"])
    fig = go.Figure(
        data=[go.Scatter(x=np.asarray(gaps_m) * 1e3, y=etas, mode="lines+markers")],
        layout=go.Layout(title=title, xaxis_title="gap (mm)", yaxis_title="η"),
    )
    return fig


# --------------------------------------------------------------------- field
def plot_h_field_along_coil(coil, *, title: Optional[str] = None):
    """Plot |H/I|² along the filament path — useful for spotting hotspots."""
    _require_plotly()
    from .proximity import biot_savart_along_path
    H, _ = biot_savart_along_path(coil.geometry.filament_curve(),
                                  exclude_radius=coil._wire_diameter())  # noqa: SLF001
    H2 = np.einsum("ij,ij->i", H, H)
    fig = go.Figure(
        data=[go.Scatter(y=H2, mode="lines")],
        layout=go.Layout(title=title or "|H/I|² along filament",
                         xaxis_title="segment idx", yaxis_title="|H/I|² (1/m²)"),
    )
    return fig
