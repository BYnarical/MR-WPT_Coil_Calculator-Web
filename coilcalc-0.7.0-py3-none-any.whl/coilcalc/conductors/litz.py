"""Litz wire — Sullivan-style strand skin + internal-proximity model.

For a standalone Litz conductor (i.e. no surrounding-winding context yet),
the AC resistance is dominated by:

  F_R_strand    : skin effect within each strand (Bessel exact on d_s)
  F_P_internal  : proximity-effect contribution from neighbouring strands
                  *inside the bundle*. Sullivan 2014 expresses this as
                  F_P_internal = γ · (d_s/δ)²  with γ ≈ 0.5–1.0 for
                  typical tightly-packed bundles.

The *external* proximity contribution from neighbouring turns of the same
coil — the dominant term for densely-wound coils — is a function of the coil
geometry and will be added in Phase 2 once the coil context is known.

So this module deliberately models only what a conductor sample knows.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..constants import MU_0, RHO_COPPER, skin_depth
from .round import RoundWire


@dataclass
class LitzWire:
    """Twisted multi-strand Litz wire."""
    strand_d: float                  # individual strand diameter, m
    n_strands: int                   # number of strands
    rho: float = RHO_COPPER
    mu_r: float = 1.0
    bundle_d: float | None = None    # optional measured bundle diameter, m
    gamma_internal: float = 0.5      # internal-proximity coefficient (~0.5–1.0)

    def __post_init__(self) -> None:
        if self.n_strands < 1:
            raise ValueError("n_strands must be >= 1")
        if self.bundle_d is None:
            # Empirical: bundle ≈ √n · d_s · 1.155 (hex packing + insulation slack)
            self.bundle_d = 1.155 * math.sqrt(self.n_strands) * self.strand_d

    # ------------------------------------------------------------------ DC
    def area(self) -> float:
        return self.n_strands * math.pi * (self.strand_d * 0.5) ** 2

    def rdc_per_length(self) -> float:
        return self.rho / self.area()

    # ------------------------------------------------------------------ AC
    def rac_over_rdc(self, f: float) -> float:
        if f <= 0.0:
            return 1.0
        # Strand-level skin factor (Bessel exact).
        strand = RoundWire(d=self.strand_d, rho=self.rho, mu_r=self.mu_r)
        Fr_strand = strand.rac_over_rdc(f)

        # Internal proximity within the bundle — Sullivan small-strand limit.
        delta = skin_depth(f, self.rho, self.mu_r)
        x = self.strand_d / delta
        Fp_internal = self.gamma_internal * x * x
        return Fr_strand + Fp_internal

    def rac_per_length(self, f: float) -> float:
        return self.rdc_per_length() * self.rac_over_rdc(f)

    # ------------------------------------------------------------------ proximity
    def proximity_loss_coefficient(self, f: float) -> float:
        """ΔR_ac_prox / length = G_L · ⟨|H_ext/I|²⟩ [Ω·m].

        Sullivan 1999 simplified form for a Litz bundle of n strands of
        diameter d_s in an external field H_ext:

            P_prox/ℓ = n · (π · d_s⁴ · ω² · μ₀²) / (128·ρ) · |H_ext|²

        Treated as additional series resistance per amp²:
            G_L = n · π · d_s⁴ · ω² · μ₀² / (128 · ρ)
        """
        if f <= 0.0:
            return 0.0
        from ..constants import MU_0
        omega = 2.0 * math.pi * f
        ds = self.strand_d
        return self.n_strands * math.pi * (ds ** 4) * (omega ** 2) * (MU_0 ** 2) / (128.0 * self.rho)

    def __repr__(self) -> str:
        return (f"LitzWire({self.n_strands}× {self.strand_d*1e6:.0f} µm, "
                f"bundle≈{self.bundle_d*1e3:.2f} mm)")
