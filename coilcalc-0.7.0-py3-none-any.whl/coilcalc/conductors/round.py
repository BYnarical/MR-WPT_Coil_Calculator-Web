"""Solid round wire — exact Bessel-function AC-resistance.

R_ac/R_dc = (ξ/2) · [ber(ξ)·bei'(ξ) − bei(ξ)·ber'(ξ)] / [ber'(ξ)² + bei'(ξ)²]
ξ = d / (δ√2)

For very small ξ (low f) the ratio → 1; for large ξ → ξ/(2√2).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from scipy import special

from ..constants import MU_0, RHO_COPPER, skin_depth


@dataclass
class RoundWire:
    """Solid round conductor."""
    d: float                       # wire diameter, m
    rho: float = RHO_COPPER        # resistivity, Ω·m
    mu_r: float = 1.0              # relative permeability (1 for Cu/Al)

    def area(self) -> float:
        return math.pi * (self.d * 0.5) ** 2

    def rdc_per_length(self) -> float:
        return self.rho / self.area()

    def _xi(self, f: float) -> float:
        delta = skin_depth(f, self.rho, self.mu_r)
        return self.d / (delta * math.sqrt(2.0))

    def rac_over_rdc(self, f: float) -> float:
        """Exact Bessel/Kelvin AC resistance ratio for an isolated round wire."""
        if f <= 0.0:
            return 1.0
        xi = self._xi(f)
        if xi < 1e-3:
            return 1.0 + (xi ** 4) / 48.0
        # scipy.special.kelvin returns (Be, Ke, Bep, Kep)
        # Be = ber + j·bei,  Bep = ber' + j·bei'
        Be, _Ke, Bep, _Kep = special.kelvin(xi)
        ber, bei = Be.real, Be.imag
        berp, beip = Bep.real, Bep.imag
        num = ber * beip - bei * berp
        den = berp * berp + beip * beip
        return 0.5 * xi * num / den

    def rac_per_length(self, f: float) -> float:
        return self.rdc_per_length() * self.rac_over_rdc(f)

    # ------------------------------------------------------------------ proximity
    def proximity_loss_coefficient(self, f: float) -> float:
        """Return G_R such that ΔR_ac_prox / length = G_R · ⟨|H_ext/I|²⟩ [Ω·m].

        Ferreira closed form, low-frequency limit (d/δ ≤ ~1.5):
            G_R = π · d⁴ · ω² · μ₀² / (128 · ρ)

        For larger d/δ the exact Bessel expression is used.
        """
        if f <= 0.0:
            return 0.0
        from ..constants import MU_0
        omega = 2.0 * math.pi * f
        delta = skin_depth(f, self.rho, self.mu_r)
        x = self.d / delta
        if x < 1.5:
            return math.pi * (self.d ** 4) * (omega ** 2) * (MU_0 ** 2) / (128.0 * self.rho)
        # High-frequency form: surface integral, G_R → (π/2) · d · √(ω·μ₀·ρ/2) · |H|²
        # but the linearisation in d/δ form is fine: use the integrated Bessel
        # result G_R = (ρ/d²) · F_P(x) with F_P from kelvin functions.
        from scipy import special
        Be, _, Bep, _ = special.kelvin(x)
        ber, bei = Be.real, Be.imag
        berp, beip = Bep.real, Bep.imag
        num = ber * berp + bei * beip
        den = berp * berp + beip * beip
        F_P = -2.0 * math.pi * x * num / den
        return F_P * self.rho

    def __repr__(self) -> str:
        return f"RoundWire(d={self.d*1e3:.3f} mm)"
