"""PCB trace conductor — Kuhn / Yue AC-resistance model.

Yue (UCSB) skin-only term for a rectangular trace of width w and thickness t:
    R_dc/length = ρ / (w·t)
    R_ac/length = ρ / (w·δ·(1 − e^(−t/δ)))           (skin in the t direction)

Kuhn proximity correction for adjacent traces of pitch (w+s):
    R_ac = R_dc · [1 + (1/10) · (f/f_crit)²]
    f_crit = 3.1 · (w + s) · R_sheet / (π·μ₀·w²)
    R_sheet = ρ/t  [Ω/□]

For the proximity_loss_coefficient we expose the surface-current model:
    ΔR/ℓ = (ρ / (w·δ)) · F_P · ⟨|H_ext|²⟩  · (small geometric correction)

This is sufficient for first-order PCB-trace design at f ≤ 30 MHz; deeper
modelling (current-crowding at vias, inner-turn proximity) is Phase 4.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..constants import RHO_COPPER, MU_0, skin_depth


@dataclass
class PCBTrace:
    """Rectangular PCB trace conductor."""
    width:     float                  # w, m
    thickness: float                  # t (copper height), m
    pitch:     float = 0.0            # adjacent-trace pitch (w + s), m. 0 = isolated
    rho:       float = RHO_COPPER
    mu_r:      float = 1.0

    def area(self) -> float:
        return self.width * self.thickness

    def rdc_per_length(self) -> float:
        return self.rho / self.area()

    def _f_crit(self) -> float:
        if self.pitch <= self.width:
            return 1e18                                    # isolated trace
        R_sheet = self.rho / self.thickness                # Ω per square
        return 3.1 * self.pitch * R_sheet / (math.pi * MU_0 * (self.width ** 2))

    def rac_over_rdc(self, f: float) -> float:
        """Skin-only (Yue) R_ac/R_dc.

        The Kuhn current-crowding correction for neighbouring spiral turns is
        *not* applied here — that term is a coil-level effect, exposed through
        :meth:`proximity_loss_coefficient` and combined by the ``Coil`` class
        using the actual Biot-Savart field, which is more physically faithful.
        """
        if f <= 0.0:
            return 1.0
        delta = skin_depth(f, self.rho, self.mu_r)
        rac_dc_skin = self.thickness / (delta * (1.0 - math.exp(-self.thickness / delta)))
        return max(rac_dc_skin, 1.0)

    def rac_per_length(self, f: float) -> float:
        return self.rdc_per_length() * self.rac_over_rdc(f)

    # ------------------------------------------------------------------ proximity
    def proximity_loss_coefficient(self, f: float) -> float:
        """Additional R per amp² per length for external-H proximity."""
        if f <= 0.0:
            return 0.0
        delta = skin_depth(f, self.rho, self.mu_r)
        # Treat trace as a thin foil of thickness ``thickness``: surface current
        # contribution is  ΔR/ℓ ≈ ρ·F_P·t² / (w·δ) ; for thin traces (t < δ)
        # this is small. Use Dowell single-layer F_P with ξ = t/δ.
        xi = self.thickness / delta
        if xi < 1e-3:
            F_P = (2.0 / 3.0) * xi ** 3
        else:
            num = math.sinh(2.0 * xi) - math.sin(2.0 * xi)
            den = math.cosh(2.0 * xi) - math.cos(2.0 * xi)
            F_P = xi * num / den
        return self.rho * F_P * (self.thickness ** 2) / (self.width * delta)

    def __repr__(self) -> str:
        return f"PCBTrace(w={self.width*1e3:.2f} mm, t={self.thickness*1e6:.0f} µm)"
