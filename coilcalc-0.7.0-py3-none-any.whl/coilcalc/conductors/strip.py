"""Copper foil / strip — Dowell skin & proximity model.

For a single isolated foil layer of thickness h and width b carrying axial
current, AC resistance follows Dowell's formula (m = 1):

    F_R = ξ · (sinh 2ξ + sin 2ξ) / (cosh 2ξ − cos 2ξ),    ξ = h / δ

This module models a *single-layer* foil winding (e.g., a wide flat strip
wound as a planar spiral or pancake). Multi-layer Dowell with porosity η
will be added in Phase 2.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..constants import RHO_COPPER, skin_depth


@dataclass
class FoilStrip:
    """Rectangular foil/strip conductor (h × b cross-section)."""
    thickness: float                # h, m
    width: float                    # b, m
    rho: float = RHO_COPPER
    mu_r: float = 1.0

    def area(self) -> float:
        return self.thickness * self.width

    def rdc_per_length(self) -> float:
        return self.rho / self.area()

    def rac_over_rdc(self, f: float) -> float:
        if f <= 0.0:
            return 1.0
        delta = skin_depth(f, self.rho, self.mu_r)
        xi = self.thickness / delta
        if xi < 1e-3:
            return 1.0 + (xi ** 4) / 45.0
        num = math.sinh(2.0 * xi) + math.sin(2.0 * xi)
        den = math.cosh(2.0 * xi) - math.cos(2.0 * xi)
        return xi * num / den

    def rac_per_length(self, f: float) -> float:
        return self.rdc_per_length() * self.rac_over_rdc(f)

    # ------------------------------------------------------------------ proximity
    def proximity_loss_coefficient(self, f: float) -> float:
        """Foil proximity coefficient (Dowell single-layer extended).

        For a single foil of thickness h and width b in a tangential field,
        Dowell gives the proximity factor:
            F_P = ξ · (sinh 2ξ − sin 2ξ) / (cosh 2ξ − cos 2ξ),  ξ = h/δ
        and the additional R per unit length:
            ΔR/ℓ = (ρ / (b·δ)) · F_P · ⟨H_tangential²⟩ × (cross-section)
        Returned coefficient is the ratio  ΔR / (⟨H/I⟩² · length).
        """
        if f <= 0.0:
            return 0.0
        delta = skin_depth(f, self.rho, self.mu_r)
        xi = self.thickness / delta
        if xi < 1e-3:
            F_P = (2.0 / 3.0) * xi ** 3
        else:
            num = math.sinh(2.0 * xi) - math.sin(2.0 * xi)
            den = math.cosh(2.0 * xi) - math.cos(2.0 * xi)
            F_P = xi * num / den
        # ΔR per amp² per unit length ≈ ρ · F_P / (b · δ) — same dimensional shape
        # as G_R for round wire; multiplied by ⟨|H/I|²⟩ in the coil model.
        # The physical pre-factor for a flat strip is approximately h² (the foil's
        # tangential cross-section), giving G_F ≈ ρ·F_P·h² / (b·δ).
        return self.rho * F_P * (self.thickness ** 2) / (self.width * delta)

    def __repr__(self) -> str:
        return f"FoilStrip({self.thickness*1e3:.3f}×{self.width*1e3:.2f} mm)"
