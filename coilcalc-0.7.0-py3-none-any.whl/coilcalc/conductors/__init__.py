"""Conductor cross-section models with skin/proximity AC-resistance."""
from .round import RoundWire  # noqa: F401
from .litz import LitzWire  # noqa: F401
from .strip import FoilStrip  # noqa: F401
from .pcb_trace import PCBTrace  # noqa: F401

Conductor = "RoundWire | LitzWire | FoilStrip | PCBTrace"
