"""Physical constants and material properties (SI units)."""
from __future__ import annotations

MU_0 = 1.25663706212e-6        # vacuum permeability, H/m
EPS_0 = 8.8541878128e-12       # vacuum permittivity, F/m
C_LIGHT = 299_792_458.0        # m/s

# Conductor resistivities (Ω·m, 20 °C) — relative permeability 1 for non-magnetic.
RHO_COPPER = 1.724e-8
RHO_ALUMINUM = 2.65e-8
RHO_SILVER = 1.59e-8

# Copper temperature coefficient (1/K).
ALPHA_COPPER = 3.93e-3


def skin_depth(f: float, rho: float = RHO_COPPER, mu_r: float = 1.0) -> float:
    """Skin depth δ = √(ρ / (π f μ)).

    Args:
        f: frequency, Hz.
        rho: resistivity, Ω·m (default copper).
        mu_r: relative permeability (default 1).

    Returns:
        δ in metres.
    """
    import math
    return math.sqrt(rho / (math.pi * f * MU_0 * mu_r))
