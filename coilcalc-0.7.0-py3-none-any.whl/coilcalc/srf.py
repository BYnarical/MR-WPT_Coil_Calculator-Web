"""Self-resonant frequency estimators (lumped-capacitance approximations).

- Medhurst 1947: single-layer solenoid stray capacitance
      C_self [pF] = H · D[cm]
  H(ℓ/D) is an empirically tabulated coefficient; we use the published table
  with log-linear interpolation.

- GKMR (Grandi, Kazimierczuk, Massarini, Reggiani, IEEE TIA 1999):
  turn-to-turn capacitance sum for single-layer windings; we apply the same
  spirit to a planar spiral by approximating each adjacent-turn pair as two
  parallel cylinders separated by gap s, in vacuum (no ferrite).

SRF = 1 / (2π √(L · C_self)).
"""
from __future__ import annotations

import math

import numpy as np

from .constants import C_LIGHT, EPS_0
from .geometry.solenoid import Solenoid
from .geometry.spiral import _SpiralBase
from .geometry.conical import ConicalHelix, MultiLayerSpiral
from .geometry.rectangular import RectangularSpiral


# Medhurst's H values (pF/cm) as a function of solenoid length/diameter ratio.
# Source: Medhurst, Wireless Engineer, vol. 24, 1947.
_MEDHURST_LD = np.array([0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.50,
                         0.60, 0.70, 0.80, 1.00, 1.50, 2.00, 3.00, 4.00,
                         5.00, 7.00, 10.0, 20.0, 40.0, 100.0])
_MEDHURST_H = np.array([0.96, 0.79, 0.78, 0.64, 0.60, 0.57, 0.54, 0.50,
                        0.48, 0.47, 0.46, 0.46, 0.47, 0.50, 0.61, 0.72,
                        0.81, 1.01, 1.32, 2.36, 4.31, 9.83])


def medhurst_capacitance(geom: Solenoid) -> float:
    """Medhurst's stray self-capacitance for a single-layer solenoid, in F."""
    ld = max(min(geom.length / geom.D, _MEDHURST_LD[-1]), _MEDHURST_LD[0])
    H = float(np.interp(ld, _MEDHURST_LD, _MEDHURST_H))   # pF per cm of diameter
    D_cm = geom.D * 100.0
    return H * D_cm * 1e-12                                # Farads


def solenoid_srf(geom: Solenoid, L: float) -> float:
    C = medhurst_capacitance(geom)
    return 1.0 / (2.0 * math.pi * math.sqrt(L * C))


def gkmr_spiral_capacitance(geom: _SpiralBase) -> float:
    """GKMR-style turn-to-turn capacitance for a planar spiral, F.

    Approximates each turn pair as two long parallel cylinders of effective
    diameter d_eff = w (conductor width) separated by gap s, length ≈ π·d_avg
    per turn. Returns the series capacitance over the (N − 1) turn pairs
    multiplied by the per-turn length.
    """
    n_pairs = max(int(round(geom.N)) - 1, 0)
    if n_pairs == 0:
        return 1e-15  # avoid div-by-zero; pico-tiny
    d_eff = max(geom.w, 1e-6)
    s = max(geom.s, 1e-6)
    # Parallel-cylinder capacitance per unit length:
    #   C/ℓ = π·ε₀ / acosh((d_eff + s) / d_eff)
    ratio = (d_eff + s) / d_eff
    if ratio <= 1.0:
        return 1e-15
    c_per_l = math.pi * EPS_0 / math.acosh(ratio)
    per_turn_length = math.pi * geom.d_avg
    c_pair = c_per_l * per_turn_length
    # Adjacent turns are in series for the whole-coil capacitance — Grandi 1999.
    return c_pair / n_pairs


def spiral_srf(geom: _SpiralBase, L: float) -> float:
    C = gkmr_spiral_capacitance(geom)
    if C <= 0.0:
        return float("inf")
    return 1.0 / (2.0 * math.pi * math.sqrt(L * C))


def yun_archimedean_srf(geom, L: float, eps_r_eff: float = 1.0) -> float:
    """Yun 2014 closed-form Archimedean-spiral SRF.

        f_srf ≈ c / (ℓ_wire · √ε_r_eff)  with a 0.5 quarter-wave factor.

    This treats the spiral conductor as a transmission line of length ℓ_wire
    in an effective medium of permittivity ε_r_eff (≈ 1 for air-core).
    """
    if not hasattr(geom, "wire_length"):
        return float("inf")
    ell = float(geom.wire_length())
    if ell <= 0.0:
        return float("inf")
    return C_LIGHT / (2.0 * ell * math.sqrt(eps_r_eff))


def self_resonant_frequency(geom, L: float) -> float:
    if isinstance(geom, Solenoid):
        return solenoid_srf(geom, L)
    if isinstance(geom, _SpiralBase):
        # Take the *lower* of GKMR and Yun (limiting case wins).
        f_lumped = spiral_srf(geom, L)
        f_yun = yun_archimedean_srf(geom, L)
        return min(f_lumped, f_yun)
    if isinstance(geom, RectangularSpiral):
        return yun_archimedean_srf(geom, L)
    if isinstance(geom, MultiLayerSpiral):
        # Stack SRF dominated by the longer effective wire length.
        return yun_archimedean_srf(geom, L)
    if isinstance(geom, ConicalHelix):
        return yun_archimedean_srf(geom, L)
    # Fallback — return a high "infinity" so callers won't blow up.
    return float("inf")
