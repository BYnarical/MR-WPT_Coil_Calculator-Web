"""Optional FEMM bridge — runs a 2-D FEMM model and returns L / R_eff.

Use this when you want ground-truth FEM results for ferrite shapes that the
image-method approximates (rod inside solenoid, planar spiral with axisym-
metric backplate, pot core). Falls back to analytical when FEMM is not
installed.

Requirements (local desktop builds only — *not* the Pyodide web build):
* FEMM (https://www.femm.info) installed.
* ``pip install pyfemm``.

Usage::

    from coilcalc import Coil, CircularSpiral, LitzWire, FerriteSheet
    from coilcalc.femm_bridge import femm_inductance

    coil = Coil(CircularSpiral(N=10, Do=100e-3, Di=60e-3),
                LitzWire(strand_d=71e-6, n_strands=420),
                ferrite=FerriteSheet(thickness_mm=2.0, area_mm2=10000, gap_mm=0.5))
    L, R_core = femm_inductance(coil, f=100e3)

The bridge runs an axisymmetric model (planar spiral assumed circular).
For full 3-D geometries (DD pads, BPP, etc.) FEMM cannot help — those
remain analytical-only.

If FEMM is not installed, all functions return ``(nan, nan)`` and print
a one-line warning so callers can fall back gracefully.
"""
from __future__ import annotations

import math
import warnings
from typing import Optional, Tuple

import numpy as np

from .api import Coil
from .ferrite import (FerriteBars, FerritePotCore, FerriteRing, FerriteRod,
                      FerriteSheet)
from .geometry.solenoid import Solenoid
from .geometry.spiral import CircularSpiral

_NAN = float("nan")


def _femm_available() -> bool:
    try:
        import femm  # noqa: F401
        return True
    except Exception:
        return False


def _warn_no_femm(method: str) -> None:
    warnings.warn(
        f"[coilcalc.femm_bridge] FEMM not installed — '{method}' "
        f"returns NaN. Install pyfemm and FEMM (https://www.femm.info) "
        f"to enable the FEMM bridge.")


# ----------------------------------------------------------- material map
def _femm_material_block(femm, mat) -> str:
    """Add the ferrite material block to the FEMM model. Returns the name."""
    name = mat.name.replace(" ", "_")
    # FEMM signature: mi_addmaterial(name, mu_x, mu_y, H_c, J, σ, dlam, ψ,
    #                               LamFill, LamType, ψhx, ψhy, NStrands, WireD)
    femm.mi_addmaterial(name, mat.mu_r0, mat.mu_r0, 0, 0, 1.0 / mat.rho,
                        0, 0, 1, 0, 0, 0, 0, 0)
    return name


def _femm_coil_block(femm, conductor, label_pos: tuple[float, float], current: float,
                     turns: int) -> str:
    """Add a copper coil block + circuit at the given (r, z)."""
    femm.mi_addcircprop("coil", current, 1)   # series circuit at 1 A
    femm.mi_addmaterial("Copper", 1, 1, 0, 0, 58, 0, 0, 1, 0, 0, 0, 0, 0)
    return "Copper"


# ----------------------------------------------------------- main entry
def femm_inductance(coil: Coil, f: float = 100e3,
                    *, current_A: float = 1.0,
                    units: str = "millimeters") -> Tuple[float, float]:
    """Compute (L, R_eff) using FEMM for the given Coil + ferrite.

    Only **axisymmetric** geometries are supported: ``CircularSpiral`` and
    ``Solenoid`` (and ferrite ``FerriteSheet`` / ``FerriteRod`` /
    ``FerritePotCore`` / ``FerriteRing``). 3-D shapes return (NaN, NaN).

    Returns ``(L_H, R_core_Ω)``. R_core is the lumped equivalent
    resistance contributed by core losses at the supplied frequency.
    """
    if not _femm_available():
        _warn_no_femm("femm_inductance")
        return _NAN, _NAN

    geom = coil.geometry
    fer = coil.ferrite

    if not isinstance(geom, (CircularSpiral, Solenoid)):
        warnings.warn(f"[coilcalc.femm_bridge] geometry "
                      f"{type(geom).__name__} not axisymmetric — skipping.")
        return _NAN, _NAN

    import femm
    femm.openfemm(bHide=True)
    try:
        femm.newdocument(0)                                 # magnetics
        femm.mi_probdef(f, units, "axi", 1e-8, 0, 30)
        femm.mi_addmaterial("Air", 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0)
        cu_name = _femm_coil_block(femm, coil.conductor,
                                   label_pos=(0.0, 0.0),
                                   current=current_A,
                                   turns=int(getattr(geom, "N", 1)))
        mat_name = _femm_material_block(femm, fer.material) if fer else None

        # ---- coil cross-section
        if isinstance(geom, CircularSpiral):
            r_in = geom.Di * 0.5 * 1e3
            r_out = geom.Do * 0.5 * 1e3
            z = 0.0
            femm.mi_drawrectangle(r_in, z - 0.5, r_out, z + 0.5)
            femm.mi_addblocklabel((r_in + r_out) / 2, z)
            femm.mi_selectlabel((r_in + r_out) / 2, z)
            femm.mi_setblockprop(cu_name, 0, 1, "coil", 0, 0, int(geom.N))
            femm.mi_clearselected()
        elif isinstance(geom, Solenoid):
            r = geom.D * 0.5 * 1e3
            half_l = geom.length * 0.5 * 1e3
            femm.mi_drawrectangle(r - 0.5, -half_l, r + 0.5, half_l)
            femm.mi_addblocklabel(r, 0.0)
            femm.mi_selectlabel(r, 0.0)
            femm.mi_setblockprop(cu_name, 0, 1, "coil", 0, 0, int(geom.N))
            femm.mi_clearselected()

        # ---- ferrite cross-section
        if isinstance(fer, FerriteSheet):
            r_out = (geom.Do * 0.5 * 1e3 if isinstance(geom, CircularSpiral)
                     else geom.D * 0.5 * 1e3)
            zt = -fer.gap_mm
            zb = zt - fer.thickness_mm
            femm.mi_drawrectangle(0.0, zb, r_out, zt)
            femm.mi_addblocklabel(r_out * 0.5, (zb + zt) / 2)
            femm.mi_selectlabel(r_out * 0.5, (zb + zt) / 2)
            femm.mi_setblockprop(mat_name, 0, 1, "<None>", 0, 0, 0)
            femm.mi_clearselected()
        elif isinstance(fer, FerriteRod):
            r = fer.diameter_mm * 0.5
            h = fer.length_mm * 0.5
            femm.mi_drawrectangle(0.0, -h, r, h)
            femm.mi_addblocklabel(r * 0.5, 0.0)
            femm.mi_selectlabel(r * 0.5, 0.0)
            femm.mi_setblockprop(mat_name, 0, 1, "<None>", 0, 0, 0)
            femm.mi_clearselected()
        elif isinstance(fer, FerritePotCore):
            OD = fer.OD_mm * 0.5
            ID = fer.ID_mm * 0.5
            H = fer.height_mm
            # cup side
            femm.mi_drawrectangle(ID, -H * 0.5, OD, H * 0.5)
            femm.mi_addblocklabel((ID + OD) / 2, 0.0)
            femm.mi_selectlabel((ID + OD) / 2, 0.0)
            femm.mi_setblockprop(mat_name, 0, 1, "<None>", 0, 0, 0)
            femm.mi_clearselected()

        # ---- air bound + far-field
        r_bound = 200.0
        femm.mi_drawline(0, -r_bound, 0, r_bound)
        femm.mi_drawarc(0, r_bound, 0, -r_bound, 180, 5)
        femm.mi_addblocklabel(r_bound * 0.7, 0)
        femm.mi_selectlabel(r_bound * 0.7, 0)
        femm.mi_setblockprop("Air", 0, 1, "<None>", 0, 0, 0)
        femm.mi_clearselected()

        femm.mi_zoomnatural()
        femm.mi_analyze(1)
        femm.mi_loadsolution()

        # Circuit properties → (current, voltage drop, flux_linkage)
        cur, volt, flux = femm.mo_getcircuitproperties("coil")
        omega = 2.0 * math.pi * f
        # flux is complex: flux = Re + j·Im;  Re/I = L, Im/(ω·I) = R_loss / ω
        if hasattr(flux, "real"):
            L = flux.real / current_A
            R = -omega * flux.imag / current_A
        else:
            L = float(flux) / current_A
            R = 0.0
        return L, R
    finally:
        femm.mi_close()
        femm.closefemm()


def is_available() -> bool:
    """True if FEMM + pyfemm are installed and importable."""
    return _femm_available()
