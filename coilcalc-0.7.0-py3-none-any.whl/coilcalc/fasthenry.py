"""Optional FastHenry / FastHenry2 bridge for ground-truth validation.

This module writes a coil's filament path as a FastHenry ``.inp`` file,
invokes the FastHenry executable (must be installed separately), and parses
the resulting ``Zc.mat`` to recover (R + jωL).

Usage:
    from coilcalc.fasthenry import fasthenry_inductance
    L, R = fasthenry_inductance(coil, f=6.78e6, exe="FastHenry2.exe")

FastHenry2 download: https://www.fastfieldsolvers.com/fasthenry2.htm
"""
from __future__ import annotations

import math
import os
import re
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

import numpy as np

from .api import Coil


def write_fasthenry_inp(coil: Coil, path: Path, *, f: float = 6.78e6,
                        wire_w: Optional[float] = None,
                        wire_h: Optional[float] = None) -> None:
    """Write a FastHenry input file for ``coil`` at frequency ``f``."""
    pts = coil.geometry.filament_curve()
    # Conductor cross-section (rectangular w×h in FastHenry).
    if wire_w is None:
        wire_w = (getattr(coil.conductor, "d", None)
                  or getattr(coil.conductor, "bundle_d", None)
                  or getattr(coil.conductor, "width", None)
                  or 1.0e-3)
    if wire_h is None:
        wire_h = wire_w
    rho = getattr(coil.conductor, "rho", 1.724e-8)
    sigma = 1.0 / rho

    lines = ["* coilcalc auto-generated FastHenry input",
             "* units in metres",
             ".units M",
             f".default sigma={sigma:.6e} nwinc=8 nhinc=8 w={wire_w:.6e} h={wire_h:.6e}"]

    # Nodes.
    for i, (x, y, z) in enumerate(pts):
        lines.append(f"N{i:04d}  x={x:.6e}  y={y:.6e}  z={z:.6e}")
    # Segments connecting consecutive nodes.
    for i in range(len(pts) - 1):
        lines.append(f"E{i:04d}  N{i:04d}  N{i+1:04d}")
    # External port from first to last node.
    lines.append(f".external N0000 N{len(pts)-1:04d}")
    lines.append(f".freq fmin={f:.6e} fmax={f:.6e} ndec=1")
    lines.append(".end")
    path.write_text("\n".join(lines))


def parse_zc_mat(path: Path) -> complex:
    """Parse FastHenry's ``Zc.mat`` and return the first impedance entry."""
    text = path.read_text()
    nums = re.findall(r"[-+]?\d+\.\d+(?:[eE][-+]?\d+)?", text)
    if len(nums) < 2:
        raise RuntimeError(f"Could not parse FastHenry output: {path}")
    return complex(float(nums[0]), float(nums[1]))


def fasthenry_inductance(coil: Coil, *, f: float = 6.78e6,
                         exe: str = "fasthenry") -> tuple[float, float]:
    """Run FastHenry and return (L, R) at frequency ``f``.

    Returns (NaN, NaN) and prints a warning if FastHenry is not installed.
    """
    with tempfile.TemporaryDirectory() as td:
        td_path = Path(td)
        inp = td_path / "coil.inp"
        write_fasthenry_inp(coil, inp, f=f)
        try:
            subprocess.run([exe, str(inp)], cwd=td, check=True,
                           capture_output=True, timeout=300)
        except FileNotFoundError:
            print(f"[fasthenry] '{exe}' not found on PATH — skipping.")
            return float("nan"), float("nan")
        except subprocess.CalledProcessError as e:
            print(f"[fasthenry] failed: {e.stderr.decode(errors='ignore')[:200]}")
            return float("nan"), float("nan")
        zc = parse_zc_mat(td_path / "Zc.mat")
    L = zc.imag / (2.0 * math.pi * f)
    R = zc.real
    return L, R
