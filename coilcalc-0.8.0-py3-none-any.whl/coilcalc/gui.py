"""Desktop GUI for coilcalc — NiceGUI (Quasar/Vue) app.

Launches with ``coilcalc gui`` or ``python -m coilcalc.gui``. By default it
opens in your browser at http://localhost:8765. Pass ``--native`` to spawn
a desktop window via pywebview (requires ``pip install coilcalc[native]``).
"""
from __future__ import annotations

import math
import sys
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

try:
    from nicegui import app, ui
except ImportError:                                     # pragma: no cover
    raise SystemExit(
        "GUI deps missing — run:  pip install 'coilcalc[gui]'"
    )

import plotly.graph_objects as go

# Use absolute imports — NiceGUI's reload mode re-executes the entry file
# under runpy, which loses the package context for relative imports.
from coilcalc import (
    CircularSpiral, Coil, ConicalHelix, DDPad, FoilStrip, LitzWire,
    MultiLayerSpiral, MutualPair, PCBTrace, PolygonalSpiral,
    RectangularSpiral, RoundWire, Solenoid, WPTSystem,
)

# ---------------------------------------------------------------------- theme
PRIMARY = "#06b6d4"          # cyan-500
ACCENT = "#a78bfa"           # violet-300
DARK_BG = "#0f172a"          # slate-900
CARD_BG = "#1e293b"          # slate-800

GEOMETRY_OPTIONS = {
    "Circular spiral":     "circular",
    "Square spiral":       "square",
    "Hexagonal spiral":    "hexagonal",
    "Octagonal spiral":    "octagonal",
    "Rectangular spiral":  "rectangular",
    "Solenoid":            "solenoid",
    "Conical helix":       "conical",
    "Multi-layer planar":  "multilayer",
    "Double-D pad":        "DD",
}

CONDUCTOR_OPTIONS = {
    "Litz wire":         "litz",
    "Solid round wire":  "round",
    "Copper foil/strip": "foil",
    "PCB trace":         "pcb",
}


# ---------------------------------------------------------------------- helpers
def _build_geometry(kind: str, p: dict):
    if kind == "circular":
        return CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                              w=p["w"]*1e-3, s=p["s"]*1e-3)
    if kind in ("square", "hexagonal", "octagonal"):
        return PolygonalSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                               w=p["w"]*1e-3, s=p["s"]*1e-3, shape=kind)
    if kind == "rectangular":
        return RectangularSpiral(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                                 Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                                 w=p["w"]*1e-3, s=p["s"]*1e-3)
    if kind == "solenoid":
        return Solenoid(N=p["N"], D=p["D"]*1e-3, length=p["length"]*1e-3,
                        wire_d=p["wire_d"]*1e-3)
    if kind == "conical":
        return ConicalHelix(N=p["N"], r_top=p["r_top"]*1e-3,
                            r_bot=p["r_bot"]*1e-3, length=p["length"]*1e-3,
                            wire_d=p["wire_d"]*1e-3)
    if kind == "multilayer":
        base = CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                              w=p["w"]*1e-3, s=p["s"]*1e-3)
        return MultiLayerSpiral(layer_geom=base, n_layers=int(p["n_layers"]),
                                layer_spacing=p["layer_spacing"]*1e-3)
    if kind == "DD":
        return DDPad(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                     Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                     w=p["w"]*1e-3, s=p["s"]*1e-3,
                     gap_between=p["gap_between"]*1e-3)
    raise ValueError(f"Unknown geometry: {kind}")


def _build_conductor(kind: str, p: dict):
    if kind == "round":
        return RoundWire(d=p["d"]*1e-3)
    if kind == "litz":
        return LitzWire(strand_d=p["strand_d"]*1e-6, n_strands=int(p["n_strands"]))
    if kind == "foil":
        return FoilStrip(thickness=p["thickness"]*1e-6, width=p["width"]*1e-3)
    if kind == "pcb":
        return PCBTrace(width=p["width"]*1e-3, thickness=p["thickness"]*1e-6,
                        pitch=p["pitch"]*1e-3)
    raise ValueError(f"Unknown conductor: {kind}")


def _dark_scene():
    pane = dict(backgroundcolor="#0f172a", gridcolor="#1f2937",
                zerolinecolor="#374151", showbackground=True)
    return dict(
        xaxis=dict(title="x (mm)", **pane),
        yaxis=dict(title="y (mm)", **pane),
        zaxis=dict(title="z (mm)", **pane),
        bgcolor="#0f172a",
        aspectmode="data",
    )


def _coil_3d_figure(coil: Coil, title: str = "") -> go.Figure:
    pts = coil.geometry.filament_curve()
    fig = go.Figure(
        data=[go.Scatter3d(
            x=pts[:, 0]*1e3, y=pts[:, 1]*1e3, z=pts[:, 2]*1e3,
            mode="lines", line=dict(width=6, color=PRIMARY),
            hovertemplate="x %{x:.2f}<br>y %{y:.2f}<br>z %{z:.2f} mm",
        )],
        layout=go.Layout(
            title=title, margin=dict(l=0, r=0, t=30, b=0),
            paper_bgcolor="#0f172a", plot_bgcolor="#0f172a",
            font=dict(color="#e2e8f0"),
            scene=_dark_scene(),
        ),
    )
    return fig


def _line_figure(x, y, *, x_label: str, y_label: str, title: str = "") -> go.Figure:
    fig = go.Figure(
        data=[go.Scatter(x=x, y=y, mode="lines+markers",
                         line=dict(color=PRIMARY, width=3),
                         marker=dict(size=8, color=ACCENT))],
        layout=go.Layout(
            title=title, margin=dict(l=50, r=20, t=40, b=50),
            paper_bgcolor="#1e293b", plot_bgcolor="#0f172a",
            font=dict(color="#e2e8f0"),
            xaxis=dict(title=x_label, gridcolor="#334155", zerolinecolor="#475569"),
            yaxis=dict(title=y_label, gridcolor="#334155", zerolinecolor="#475569"),
        ),
    )
    return fig


def _heatmap_figure(matrix: np.ndarray, *, title: str = "") -> go.Figure:
    fig = go.Figure(
        data=[go.Heatmap(z=matrix, colorscale="Cividis", showscale=True,
                         hovertemplate="i %{y}, j %{x}: %{z:.3f}<extra></extra>")],
        layout=go.Layout(
            title=title, margin=dict(l=40, r=40, t=40, b=40),
            paper_bgcolor="#1e293b", font=dict(color="#e2e8f0"),
            xaxis=dict(title="j"), yaxis=dict(title="i", autorange="reversed"),
        ),
    )
    return fig


FERRITE_OPTIONS = {
    "None (air-core)":      "none",
    "Sheet / backplate":    "sheet",
    "Rod (axial core)":     "rod",
    "Bars (EV-pad)":        "bars",
    "Pot core (cup)":       "potcore",
    "Ring / toroid":        "ring",
    "Custom (raw L mult)":  "custom",
}


# ---------------------------------------------------------------------- state
@dataclass
class CoilState:
    geometry_kind: str = "circular"
    geom_params:   dict = field(default_factory=lambda: dict(
        N=10, Do=100, Di=60, a=100, b=60, Di_a=40, Di_b=20,
        D=30, length=50, r_top=20, r_bot=40, n_layers=2, layer_spacing=1.6,
        gap_between=5, w=1.0, s=0.5, wire_d=1.0,
    ))
    conductor_kind: str = "litz"
    cond_params:    dict = field(default_factory=lambda: dict(
        d=1.0, strand_d=71, n_strands=420,
        thickness=50, width=10, pitch=2.5,
    ))
    ferrite_kind:    str = "none"
    ferrite_params:  dict = field(default_factory=lambda: dict(
        thickness_mm=1.5, area_mm2=0.0, gap_mm=0.5,
        length_mm=50.0, diameter_mm=10.0,
        n_bars=4, width_mm=25.0, spacing_mm=5.0,
        OD_mm=40.0, ID_mm=15.0, height_mm=12.0, air_gap_mm=0.5,
        l_mult_at_dc=2.0, rolloff_f=1e6, core_volume=0.0, eff_path=0.05,
    ))
    ferrite_material: str = "Custom"
    ferrite_custom:   dict = field(default_factory=lambda: dict(
        mu_r0=2000.0, f_cutoff=1e6, Bsat_T=0.4, rho=5.0,
        k_sm=1.8e-3, alpha_sm=1.5, beta_sm=2.6,
    ))

    def _build_ferrite(self):
        from .ferrite import build_ferrite
        if self.ferrite_kind == "none":
            return None
        spec = {"kind": self.ferrite_kind, **self.ferrite_params}
        if self.ferrite_material == "Custom":
            spec["material"] = {"name": "Custom", "family": "MnZn", **self.ferrite_custom}
        else:
            spec["material"] = self.ferrite_material
        return build_ferrite(spec)

    def build(self) -> Coil:
        g = _build_geometry(self.geometry_kind, self.geom_params)
        c = _build_conductor(self.conductor_kind, self.cond_params)
        fer = self._build_ferrite()
        return Coil(g, c, ferrite=fer)


@dataclass
class GUIState:
    tx: CoilState = field(default_factory=CoilState)
    rx: CoilState = field(default_factory=lambda: CoilState(
        geom_params=dict(N=8, Do=60, Di=30, a=60, b=40, Di_a=20, Di_b=10,
                         D=30, length=50, r_top=20, r_bot=40, n_layers=2,
                         layer_spacing=1.6, gap_between=5, w=1.0, s=0.5,
                         wire_d=1.0),
    ))
    gap_mm:      float = 20.0
    lateral_mm:  float = 0.0
    tilt_deg:    float = 0.0
    frequency:   float = 6.78e6
    R_load:      float = 20.0
    V_source:    float = 10.0


STATE = GUIState()


# ---------------------------------------------------------------------- tab 1
def _geometry_inputs(state: CoilState, on_change):
    """Render geometry parameter inputs that adapt to the geometry kind."""
    container = ui.column().classes("w-full")

    def rebuild():
        container.clear()
        k = state.geometry_kind
        with container:
            with ui.row().classes("w-full items-center"):
                ui.number("Turns N", value=state.geom_params["N"], min=0.5,
                          max=200, step=0.5).bind_value(state.geom_params, "N"
                          ).classes("w-32").on_value_change(on_change)
            if k in ("circular", "square", "hexagonal", "octagonal", "multilayer"):
                with ui.row().classes("w-full items-center"):
                    ui.number("Outer Ø (mm)", value=state.geom_params["Do"], min=1,
                              max=2000).bind_value(state.geom_params, "Do"
                              ).classes("w-40").on_value_change(on_change)
                    ui.number("Inner Ø (mm)", value=state.geom_params["Di"], min=0.1,
                              max=2000).bind_value(state.geom_params, "Di"
                              ).classes("w-40").on_value_change(on_change)
                if k == "multilayer":
                    with ui.row().classes("w-full items-center"):
                        ui.number("Layers", value=state.geom_params["n_layers"], min=1,
                                  max=16, step=1).bind_value(state.geom_params, "n_layers"
                                  ).classes("w-32").on_value_change(on_change)
                        ui.number("Layer spacing (mm)", value=state.geom_params["layer_spacing"],
                                  min=0.01, max=20).bind_value(state.geom_params, "layer_spacing"
                                  ).classes("w-40").on_value_change(on_change)
            elif k in ("rectangular", "DD"):
                with ui.row().classes("w-full items-center"):
                    ui.number("Outer a (mm)", value=state.geom_params["a"], min=1
                              ).bind_value(state.geom_params, "a"
                              ).classes("w-32").on_value_change(on_change)
                    ui.number("Outer b (mm)", value=state.geom_params["b"], min=1
                              ).bind_value(state.geom_params, "b"
                              ).classes("w-32").on_value_change(on_change)
                with ui.row().classes("w-full items-center"):
                    ui.number("Inner a (mm)", value=state.geom_params["Di_a"], min=0.1
                              ).bind_value(state.geom_params, "Di_a"
                              ).classes("w-32").on_value_change(on_change)
                    ui.number("Inner b (mm)", value=state.geom_params["Di_b"], min=0.1
                              ).bind_value(state.geom_params, "Di_b"
                              ).classes("w-32").on_value_change(on_change)
                if k == "DD":
                    ui.number("Gap between D's (mm)", value=state.geom_params["gap_between"],
                              min=0, max=200).bind_value(state.geom_params, "gap_between"
                              ).classes("w-40").on_value_change(on_change)
            elif k == "solenoid":
                with ui.row().classes("w-full items-center"):
                    ui.number("Diameter D (mm)", value=state.geom_params["D"], min=1
                              ).bind_value(state.geom_params, "D"
                              ).classes("w-40").on_value_change(on_change)
                    ui.number("Length (mm)", value=state.geom_params["length"], min=0.1
                              ).bind_value(state.geom_params, "length"
                              ).classes("w-32").on_value_change(on_change)
            elif k == "conical":
                with ui.row().classes("w-full items-center"):
                    ui.number("Top radius (mm)", value=state.geom_params["r_top"], min=0.1
                              ).bind_value(state.geom_params, "r_top"
                              ).classes("w-32").on_value_change(on_change)
                    ui.number("Bottom radius (mm)", value=state.geom_params["r_bot"], min=0.1
                              ).bind_value(state.geom_params, "r_bot"
                              ).classes("w-32").on_value_change(on_change)
                    ui.number("Length (mm)", value=state.geom_params["length"], min=0.1
                              ).bind_value(state.geom_params, "length"
                              ).classes("w-32").on_value_change(on_change)
            with ui.row().classes("w-full items-center"):
                ui.number("Conductor w (mm)", value=state.geom_params["w"], min=0.01
                          ).bind_value(state.geom_params, "w"
                          ).classes("w-32").on_value_change(on_change)
                ui.number("Turn gap s (mm)", value=state.geom_params["s"], min=0.01
                          ).bind_value(state.geom_params, "s"
                          ).classes("w-32").on_value_change(on_change)

    rebuild()
    return rebuild


def _conductor_inputs(state: CoilState, on_change):
    container = ui.column().classes("w-full")

    def rebuild():
        container.clear()
        k = state.conductor_kind
        with container:
            if k == "round":
                ui.number("Wire Ø (mm)", value=state.cond_params["d"], min=0.05
                          ).bind_value(state.cond_params, "d"
                          ).classes("w-40").on_value_change(on_change)
            elif k == "litz":
                with ui.row().classes("w-full items-center"):
                    ui.number("Strand Ø (µm)", value=state.cond_params["strand_d"], min=10
                              ).bind_value(state.cond_params, "strand_d"
                              ).classes("w-40").on_value_change(on_change)
                    ui.number("# strands", value=state.cond_params["n_strands"], min=1,
                              step=1).bind_value(state.cond_params, "n_strands"
                              ).classes("w-32").on_value_change(on_change)
            elif k == "foil":
                with ui.row().classes("w-full items-center"):
                    ui.number("Thickness (µm)", value=state.cond_params["thickness"], min=1
                              ).bind_value(state.cond_params, "thickness"
                              ).classes("w-40").on_value_change(on_change)
                    ui.number("Width (mm)", value=state.cond_params["width"], min=0.05
                              ).bind_value(state.cond_params, "width"
                              ).classes("w-32").on_value_change(on_change)
            elif k == "pcb":
                with ui.row().classes("w-full items-center"):
                    ui.number("Trace W (mm)", value=state.cond_params["width"], min=0.05
                              ).bind_value(state.cond_params, "width"
                              ).classes("w-32").on_value_change(on_change)
                    ui.number("Cu thickness (µm)", value=state.cond_params["thickness"], min=1
                              ).bind_value(state.cond_params, "thickness"
                              ).classes("w-40").on_value_change(on_change)
                    ui.number("Pitch (mm)", value=state.cond_params["pitch"], min=0.05
                              ).bind_value(state.cond_params, "pitch"
                              ).classes("w-32").on_value_change(on_change)

    rebuild()
    return rebuild


# ---------------------------------------------------------------------- tabs
def build_single_coil_tab():
    state = STATE.tx     # share the Tx as the "single coil" workspace
    metric_labels: dict = {}
    plot_holder: dict = {"fig": None}

    def update_all():
        try:
            coil = state.build()
        except Exception as e:
            for k in metric_labels:
                metric_labels[k].text = "—"
            ui.notify(f"Error: {e}", type="negative")
            return
        f = STATE.frequency
        metric_labels["L"].text       = f"{coil.L(f)*1e6:8.3f} µH"
        metric_labels["R_dc"].text    = f"{coil.Rdc()*1e3:8.3f} mΩ"
        metric_labels["R_ac"].text    = f"{coil.Rac(f)*1e3:8.3f} mΩ"
        metric_labels["Q"].text       = f"{coil.Q(f):8.0f}"
        metric_labels["SRF"].text     = f"{coil.SRF()*1e-6:8.2f} MHz"
        metric_labels["length"].text  = f"{coil.wire_length():8.3f} m"
        if coil.ferrite is not None and "ferr_mult" in metric_labels:
            L_air = coil._L_air()  # noqa: SLF001
            metric_labels["ferr_mult"].text = f"× {coil.L(f)/L_air:6.2f}"
            metric_labels["ferr_mur"].text  = f"{coil.ferrite.material.mu_r_at(f):8.1f}"
            metric_labels["ferr_coreR"].text = f"{coil.core_loss_resistance(f)*1e3:8.3f} mΩ"
        elif "ferr_mult" in metric_labels:
            metric_labels["ferr_mult"].text  = "—"
            metric_labels["ferr_mur"].text   = "—"
            metric_labels["ferr_coreR"].text = "—"
        plot_holder["fig"].update_figure(_coil_3d_figure(coil, title=""))

    with ui.row().classes("w-full no-wrap gap-4"):
        # left: geometry + conductor inputs
        with ui.card().classes("w-1/3 bg-slate-800 text-slate-100"):
            ui.label("Geometry").classes("text-lg font-bold text-cyan-400")
            geom_select = ui.select(list(GEOMETRY_OPTIONS.keys()),
                                    value="Circular spiral", label="Type"
                                    ).classes("w-full")
            geom_rebuild = [None]

            def on_geom_kind_change(e):
                state.geometry_kind = GEOMETRY_OPTIONS[e.value]
                geom_rebuild[0]()
                update_all()
            geom_select.on_value_change(on_geom_kind_change)
            geom_rebuild[0] = _geometry_inputs(state, update_all)

            ui.separator().classes("my-3")
            ui.label("Conductor").classes("text-lg font-bold text-cyan-400")
            cond_select = ui.select(list(CONDUCTOR_OPTIONS.keys()),
                                    value="Litz wire", label="Type"
                                    ).classes("w-full")
            cond_rebuild = [None]

            def on_cond_kind_change(e):
                state.conductor_kind = CONDUCTOR_OPTIONS[e.value]
                cond_rebuild[0]()
                update_all()
            cond_select.on_value_change(on_cond_kind_change)
            cond_rebuild[0] = _conductor_inputs(state, update_all)

            ui.separator().classes("my-3")
            ui.label("Ferrite").classes("text-lg font-bold text-cyan-400")
            ferr_shape = ui.select(list(FERRITE_OPTIONS.keys()),
                                   value="None (air-core)", label="Shape"
                                   ).classes("w-full")
            from .ferrite import PRESETS as _FPRESETS
            ferr_mat = ui.select(["Custom"] + list(_FPRESETS.keys()),
                                 value="Custom", label="Material"
                                 ).classes("w-full")
            ferr_fields = ui.column().classes("w-full")
            def _on_ferr_param(key, val):
                state.ferrite_params[key] = float(val)
                update_all()
            def _on_ferr_custom(key, val):
                state.ferrite_custom[key] = float(val)
                update_all()
            def rebuild_ferr_fields():
                ferr_fields.clear()
                kind = state.ferrite_kind
                if kind == "none":
                    return
                with ferr_fields:
                    schema = {
                        "sheet":   [("thickness_mm","Thickness (mm)"), ("area_mm2","Area (mm², 0=auto)"), ("gap_mm","Gap coil→plate (mm)")],
                        "rod":     [("length_mm","Length (mm)"), ("diameter_mm","Diameter (mm)")],
                        "bars":    [("n_bars","# bars"), ("length_mm","Length (mm)"), ("width_mm","Width (mm)"), ("thickness_mm","Thickness (mm)"), ("spacing_mm","Spacing (mm)")],
                        "potcore": [("OD_mm","OD (mm)"), ("ID_mm","ID (mm)"), ("height_mm","Height (mm)"), ("air_gap_mm","Air gap (mm)")],
                        "ring":    [("OD_mm","OD (mm)"), ("ID_mm","ID (mm)"), ("height_mm","Height (mm)"), ("air_gap_mm","Air gap (mm)")],
                        "custom":  [("l_mult_at_dc","L gain × at DC"), ("rolloff_f","μ_r rolloff f (Hz)"), ("core_volume","Core volume (m³)"), ("eff_path","Effective path (m)")],
                    }
                    for key, label in schema.get(kind, []):
                        ui.number(label, value=state.ferrite_params[key]
                                  ).classes("w-full"
                                  ).on_value_change(lambda e, k=key: _on_ferr_param(k, e.value))
                    if state.ferrite_material == "Custom":
                        ui.label("Custom material parameters:").classes("text-xs text-slate-500 mt-2")
                        for key, label in [("mu_r0","μ_r at DC"), ("f_cutoff","μ_r cutoff f (Hz)"),
                                            ("Bsat_T","B_sat (T)"), ("rho","ρ (Ω·m)"),
                                            ("k_sm","Steinmetz k"), ("alpha_sm","Steinmetz α"),
                                            ("beta_sm","Steinmetz β")]:
                            ui.number(label, value=state.ferrite_custom[key]
                                      ).classes("w-full"
                                      ).on_value_change(lambda e, k=key: _on_ferr_custom(k, e.value))
            def on_ferr_shape_change(e):
                state.ferrite_kind = FERRITE_OPTIONS[e.value]
                rebuild_ferr_fields()
                update_all()
            def on_ferr_mat_change(e):
                state.ferrite_material = e.value
                rebuild_ferr_fields()
                update_all()
            ferr_shape.on_value_change(on_ferr_shape_change)
            ferr_mat.on_value_change(on_ferr_mat_change)
            rebuild_ferr_fields()

            ui.separator().classes("my-3")
            ui.label("Frequency").classes("text-lg font-bold text-cyan-400")
            f_input = ui.number("f (MHz)", value=6.78, min=0.01, max=300,
                                step=0.01).classes("w-40")
            def on_f_change(e):
                STATE.frequency = float(e.value) * 1e6
                update_all()
            f_input.on_value_change(on_f_change)

        # centre: live metric card
        with ui.card().classes("w-1/3 bg-slate-800 text-slate-100"):
            ui.label("Results").classes("text-lg font-bold text-cyan-400")
            with ui.grid(columns=2).classes("w-full gap-y-3 text-base font-mono"):
                for label_key, pretty in [
                    ("L", "L"), ("R_dc", "R_dc"), ("R_ac", "R_ac"),
                    ("Q", "Q"), ("SRF", "SRF"), ("length", "Wire length"),
                    ("ferr_mult", "L gain ×"), ("ferr_mur", "μ_r @ f"),
                    ("ferr_coreR", "Core-loss R"),
                ]:
                    ui.label(pretty).classes("text-slate-400")
                    metric_labels[label_key] = ui.label("—").classes("text-right text-violet-300 font-bold")
            ui.separator().classes("my-3")
            ui.label("Phase 1+2 model dispatcher").classes("text-xs text-slate-500")
            ui.markdown(
                "- Planar spiral → **Mohan**\n"
                "- Solenoid → **Wheeler / Nagaoka**\n"
                "- Multi-layer → **Zhao**\n"
                "- DD pad / Conical → **Neumann (GMR)**\n"
                "- Round → **Bessel** · Litz → **Sullivan** · Foil → **Dowell** · PCB → **Yue**\n"
                "- Q includes **turn-aware Biot-Savart** proximity"
            ).classes("text-xs text-slate-400")

        # right: 3D view
        with ui.card().classes("w-1/3 bg-slate-800 text-slate-100"):
            ui.label("3-D filament path").classes("text-lg font-bold text-cyan-400")
            plot_holder["fig"] = ui.plotly(_coil_3d_figure(state.build())
                                           ).classes("w-full").style("height:480px")

    update_all()


# ---------------------------------------------------------------------- tab 2
def build_pair_tab():
    """Pair tab: Tx ↔ Rx coupling, η, alignment sweep plots."""
    metric: dict = {}
    plot_k = {"fig": None}
    plot_eta = {"fig": None}
    plot_lat = {"fig": None}

    def update_all():
        f = STATE.frequency
        try:
            tx_coil = STATE.tx.build()
            rx_coil = STATE.rx.build()
        except Exception as e:
            ui.notify(f"Error: {e}", type="negative")
            return
        pair = MutualPair(tx_coil, rx_coil,
                          gap=STATE.gap_mm*1e-3,
                          lateral=STATE.lateral_mm*1e-3,
                          tilt_deg=STATE.tilt_deg)
        M_val = pair.M()
        k_val = pair.k()
        sys2 = WPTSystem(coils=[tx_coil, rx_coil],
                         positions=[(0,0,0), (STATE.lateral_mm*1e-3, 0,
                                               STATE.gap_mm*1e-3)],
                         load_index=1, R_load=STATE.R_load,
                         V_source=STATE.V_source, f=f)
        res = sys2.solve()
        metric["M"].text   = f"{M_val*1e6:7.3f} µH"
        metric["k"].text   = f"{k_val:7.4f}"
        metric["eta"].text = f"{res['eta']*100:6.2f} %"
        metric["Vout"].text = f"{abs(res['V_out']):6.2f} V"
        metric["Pin"].text  = f"{res['P_in']*1e3:6.2f} mW"
        metric["Pload"].text = f"{res['P_load']*1e3:6.2f} mW"

        # k vs gap sweep
        gaps = np.linspace(2e-3, 200e-3, 25)
        ks = []
        for g in gaps:
            p2 = MutualPair(tx_coil, rx_coil, gap=g, lateral=STATE.lateral_mm*1e-3)
            ks.append(p2.k())
        plot_k["fig"].update_figure(_line_figure(
            gaps*1e3, ks, x_label="gap (mm)", y_label="k", title="k vs gap"))

        # k vs lateral
        lats = np.linspace(0, STATE.tx.geom_params["Do"]*1.0e-3, 25)
        klats = []
        for x in lats:
            p2 = MutualPair(tx_coil, rx_coil, gap=STATE.gap_mm*1e-3, lateral=x)
            klats.append(p2.k())
        plot_lat["fig"].update_figure(_line_figure(
            lats*1e3, klats, x_label="lateral offset (mm)", y_label="k",
            title="k vs lateral offset"))

        # η vs gap
        gaps = np.linspace(2e-3, 200e-3, 18)
        etas = []
        for g in gaps:
            s2 = WPTSystem(coils=[tx_coil, rx_coil],
                           positions=[(0,0,0), (STATE.lateral_mm*1e-3, 0, g)],
                           load_index=1, R_load=STATE.R_load,
                           V_source=STATE.V_source, f=f)
            etas.append(s2.solve()["eta"])
        plot_eta["fig"].update_figure(_line_figure(
            gaps*1e3, etas, x_label="gap (mm)", y_label="η",
            title="link efficiency η vs gap"))

    with ui.row().classes("w-full no-wrap gap-4"):
        # left: Tx + Rx compact controls
        with ui.card().classes("w-1/3 bg-slate-800 text-slate-100"):
            with ui.row().classes("w-full justify-between items-center"):
                ui.label("Tx coil").classes("text-lg font-bold text-cyan-400")
            tx_sel = ui.select(list(GEOMETRY_OPTIONS.keys()),
                               value="Circular spiral", label="Tx type"
                               ).classes("w-full")
            tx_rebuild = [None]
            def on_tx_geom(e):
                STATE.tx.geometry_kind = GEOMETRY_OPTIONS[e.value]
                tx_rebuild[0]()
                update_all()
            tx_sel.on_value_change(on_tx_geom)
            tx_rebuild[0] = _geometry_inputs(STATE.tx, update_all)

            ui.separator().classes("my-2")
            ui.label("Rx coil").classes("text-lg font-bold text-cyan-400")
            rx_sel = ui.select(list(GEOMETRY_OPTIONS.keys()),
                               value="Circular spiral", label="Rx type"
                               ).classes("w-full")
            rx_rebuild = [None]
            def on_rx_geom(e):
                STATE.rx.geometry_kind = GEOMETRY_OPTIONS[e.value]
                rx_rebuild[0]()
                update_all()
            rx_sel.on_value_change(on_rx_geom)
            rx_rebuild[0] = _geometry_inputs(STATE.rx, update_all)

        # centre: alignment + system params + metrics
        with ui.card().classes("w-1/3 bg-slate-800 text-slate-100"):
            ui.label("Alignment & system").classes("text-lg font-bold text-cyan-400")
            with ui.column().classes("w-full"):
                ui.number("Vertical gap (mm)", value=20, min=0, max=300
                          ).bind_value(STATE, "gap_mm"
                          ).classes("w-full").on_value_change(update_all)
                ui.number("Lateral offset (mm)", value=0, min=0, max=300
                          ).bind_value(STATE, "lateral_mm"
                          ).classes("w-full").on_value_change(update_all)
                ui.number("Tilt (deg)", value=0, min=0, max=90
                          ).bind_value(STATE, "tilt_deg"
                          ).classes("w-full").on_value_change(update_all)
                ui.number("R_load (Ω)", value=20.0, min=0.1, max=10000
                          ).bind_value(STATE, "R_load"
                          ).classes("w-full").on_value_change(update_all)
                ui.number("V_source (V)", value=10.0, min=0.01, max=1000
                          ).bind_value(STATE, "V_source"
                          ).classes("w-full").on_value_change(update_all)
                ui.number("Frequency (MHz)", value=STATE.frequency*1e-6,
                          min=0.01, max=300, step=0.01
                          ).bind_value(STATE, "frequency",
                                       forward=lambda v: float(v)*1e6,
                                       backward=lambda v: float(v)*1e-6
                          ).classes("w-full").on_value_change(update_all)
            ui.separator().classes("my-3")
            with ui.grid(columns=2).classes("w-full gap-y-3 text-base font-mono"):
                for k, pretty in [("M", "M"), ("k", "k"),
                                  ("eta", "η"), ("Vout", "V_out"),
                                  ("Pin", "P_in"), ("Pload", "P_load")]:
                    ui.label(pretty).classes("text-slate-400")
                    metric[k] = ui.label("—").classes("text-right text-violet-300 font-bold")

        # right: three Plotly plots stacked
        with ui.card().classes("w-1/3 bg-slate-800 text-slate-100"):
            ui.label("Sweeps").classes("text-lg font-bold text-cyan-400")
            plot_k["fig"]   = ui.plotly(_line_figure([0],[0], x_label="gap (mm)", y_label="k")
                                       ).classes("w-full").style("height:230px")
            plot_lat["fig"] = ui.plotly(_line_figure([0],[0], x_label="lateral (mm)", y_label="k")
                                       ).classes("w-full").style("height:230px")
            plot_eta["fig"] = ui.plotly(_line_figure([0],[0], x_label="gap (mm)", y_label="η")
                                       ).classes("w-full").style("height:230px")

    update_all()


# ---------------------------------------------------------------------- tab 3
def build_system_tab():
    """N-coil system: editable table of coils + positions, with η + coupling matrix."""
    coil_rows: list[dict] = [
        dict(name="Tx (driver)", x=0.0, y=0.0, z=0.0, Do=100, Di=60, N=10),
        dict(name="Relay",       x=0.0, y=0.0, z=30.0, Do=100, Di=60, N=10),
        dict(name="Rx (load)",   x=0.0, y=0.0, z=60.0, Do=60,  Di=30, N=8),
    ]
    metric: dict = {}
    plot_layout = {"fig": None}
    plot_heat = {"fig": None}

    def build_system_and_solve():
        litz = LitzWire(strand_d=71e-6, n_strands=420)
        coils = []
        positions = []
        for row in coil_rows:
            try:
                g = CircularSpiral(N=float(row["N"]), Do=float(row["Do"])*1e-3,
                                   Di=float(row["Di"])*1e-3)
                coils.append(Coil(g, litz))
                positions.append((float(row["x"])*1e-3, float(row["y"])*1e-3,
                                  float(row["z"])*1e-3))
            except Exception as e:
                ui.notify(f"Row {row.get('name')}: {e}", type="negative")
                return None, None, None
        sys = WPTSystem(coils=coils, positions=positions,
                        load_index=len(coils)-1, R_load=STATE.R_load,
                        V_source=STATE.V_source, f=STATE.frequency)
        try:
            res = sys.solve()
        except Exception as e:
            ui.notify(f"Solve error: {e}", type="negative")
            return None, None, None
        return sys, res, positions

    def update_all():
        sys, res, positions = build_system_and_solve()
        if sys is None:
            return
        metric["eta"].text  = f"{res['eta']*100:6.2f} %"
        metric["Pin"].text  = f"{res['P_in']*1e3:6.3f} mW"
        metric["Pload"].text = f"{res['P_load']*1e3:6.3f} mW"
        metric["Vout"].text = f"{abs(res['V_out']):6.3f} V"
        metric["gain"].text = f"{res['gain']:6.3f}"

        # 3D layout view
        fig = go.Figure()
        for coil, (x, y, z), row in zip(sys.coils, positions, coil_rows):
            pts = coil.geometry.filament_curve()
            fig.add_trace(go.Scatter3d(
                x=(pts[:, 0]+x)*1e3, y=(pts[:, 1]+y)*1e3, z=(pts[:, 2]+z)*1e3,
                mode="lines", name=row["name"], line=dict(width=4),
            ))
        fig.update_layout(margin=dict(l=0,r=0,t=20,b=0),
                          paper_bgcolor="#0f172a",
                          font=dict(color="#e2e8f0"),
                          scene=_dark_scene())
        plot_layout["fig"].update_figure(fig)

        K = sys.coupling_matrix()
        plot_heat["fig"].update_figure(_heatmap_figure(K, title="|k_ij| matrix"))

    def add_row():
        coil_rows.append(dict(name=f"Coil {len(coil_rows)+1}",
                              x=0.0, y=0.0, z=80.0, Do=80, Di=40, N=10))
        rebuild_table()
        update_all()

    def remove_row(idx: int):
        if len(coil_rows) <= 2:
            ui.notify("Need at least 2 coils", type="warning")
            return
        coil_rows.pop(idx)
        rebuild_table()
        update_all()

    table_container = None

    def rebuild_table():
        table_container.clear()
        with table_container:
            with ui.grid(columns=8).classes("w-full gap-2 text-xs text-slate-300"):
                for h in ["Name", "x (mm)", "y (mm)", "z (mm)",
                          "Do (mm)", "Di (mm)", "N", ""]:
                    ui.label(h).classes("font-bold text-slate-400")
                for i, row in enumerate(coil_rows):
                    ui.input(value=row["name"]).bind_value(row, "name"
                            ).classes("w-full text-xs").on_value_change(update_all)
                    for key in ("x", "y", "z", "Do", "Di", "N"):
                        ui.number(value=row[key]).bind_value(row, key
                                  ).classes("w-full text-xs").on_value_change(update_all)
                    ui.button(icon="delete", on_click=lambda _e, idx=i: remove_row(idx)
                              ).props("flat color=negative dense")

    with ui.row().classes("w-full no-wrap gap-4"):
        # left: editable coil/position table
        with ui.card().classes("w-1/2 bg-slate-800 text-slate-100"):
            with ui.row().classes("w-full justify-between items-center"):
                ui.label("Coils").classes("text-lg font-bold text-cyan-400")
                ui.button("Add coil", icon="add", on_click=add_row
                          ).props("color=cyan dense")
            table_container = ui.column().classes("w-full")
            rebuild_table()

            ui.separator().classes("my-3")
            with ui.grid(columns=2).classes("w-full gap-y-3 text-base font-mono"):
                for k, pretty in [("eta", "η"), ("Vout", "V_out"),
                                  ("gain", "Gain"),
                                  ("Pin", "P_in"), ("Pload", "P_load")]:
                    ui.label(pretty).classes("text-slate-400")
                    metric[k] = ui.label("—").classes("text-right text-violet-300 font-bold")

        # right: layout + coupling heatmap
        with ui.card().classes("w-1/2 bg-slate-800 text-slate-100"):
            ui.label("Layout").classes("text-lg font-bold text-cyan-400")
            plot_layout["fig"] = ui.plotly(go.Figure()
                                          ).classes("w-full").style("height:340px")
            ui.separator().classes("my-2")
            ui.label("Coupling matrix").classes("text-lg font-bold text-cyan-400")
            plot_heat["fig"] = ui.plotly(_heatmap_figure(np.zeros((3, 3)))
                                         ).classes("w-full").style("height:240px")

    update_all()


# ---------------------------------------------------------------------- about
def build_about_tab():
    with ui.card().classes("w-full max-w-3xl mx-auto bg-slate-800 text-slate-100"):
        ui.html(
            "<h2 style='color:#06b6d4;font-weight:bold'>coilcalc — MR-WPT coil calculator</h2>"
            "<p style='color:#cbd5e1'>Standalone Python package + GUI for "
            "magnetic-resonance wireless power transfer.</p>"
        )
        ui.markdown(
            "**Geometries**\n\n"
            "- Circular / polygonal / rectangular planar spiral\n"
            "- Single-layer solenoid\n"
            "- Conical / dome helix\n"
            "- Multi-layer planar stack\n"
            "- DD / DDQ / Bipolar EV pads\n\n"
            "**Conductors**\n\n"
            "- Solid round wire (Bessel)\n- Litz (Sullivan)\n- Foil (Dowell)\n- PCB trace (Yue)\n\n"
            "**Physics**\n\n"
            "- L: Mohan, Wheeler/Nagaoka, Zhao, universal Neumann + GMR\n"
            "- M: Maxwell coaxial closed-form + universal Neumann numerical\n"
            "- Q: includes turn-aware Biot-Savart external proximity\n"
            "- SRF: Medhurst + GKMR + Yun\n"
            "- N-coil system η via full Z-matrix solver\n\n"
            "**41 / 41 tests passing.** Phase 1+2+3+4 complete."
        )


# ---------------------------------------------------------------------- main
def run_gui(*, port: int = 8765, native: bool = False, dark: bool = True) -> None:
    """Launch the coilcalc GUI."""
    # UTF-8 fix for Windows cp949 etc.
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

    @ui.page("/")
    def _index() -> None:                                  # noqa: C901
        # Decorator-based routing — required so NiceGUI never falls back to
        # runpy.run_path(sys.argv[0]) (PyInstaller bundles have a binary
        # argv[0] which makes runpy raise "null bytes in source").
        # NiceGUI 3.x forbids ANY global-scope UI calls when @ui.page is
        # present, so theme setup also lives inside the handler.
        ui.colors(primary=PRIMARY, accent=ACCENT,
                  dark="#0f172a", dark_page="#020617",
                  positive="#10b981", negative="#ef4444", warning="#f59e0b")
        ui.dark_mode(dark)

        # ------------- top bar
        with ui.header(elevated=True).classes(
                "bg-slate-900 text-slate-100 items-center justify-between"):
            with ui.row().classes("items-center"):
                ui.icon("bolt", color="cyan").classes("text-3xl")
                ui.label("coilcalc").classes("text-2xl font-bold")
                ui.label("MR-WPT coil calculator · v0.3").classes(
                    "text-sm text-slate-400 ml-2")
            with ui.row().classes("items-center"):
                ui.icon("brightness_6").classes("cursor-pointer").on(
                    "click", lambda: ui.dark_mode().toggle())
                ui.button("Github", icon="open_in_new",
                          on_click=lambda: ui.run_javascript(
                              "window.open('https://github.com/', '_blank')")
                          ).props("flat color=cyan-3")

        # ------------- main tabs
        with ui.tabs().classes("w-full bg-slate-900") as tabs:
            t_single = ui.tab("Single coil", icon="circle")
            t_pair   = ui.tab("Pair / coupling", icon="link")
            t_sys    = ui.tab("System (N-coil)", icon="hub")
            t_about  = ui.tab("About", icon="info")
        with ui.tab_panels(tabs, value=t_single).classes(
                "w-full bg-slate-900 min-h-screen p-4"):
            with ui.tab_panel(t_single):
                build_single_coil_tab()
            with ui.tab_panel(t_pair):
                build_pair_tab()
            with ui.tab_panel(t_sys):
                build_system_tab()
            with ui.tab_panel(t_about):
                build_about_tab()

        # ------------- footer status bar
        with ui.footer().classes("bg-slate-900 text-slate-400 text-xs justify-between"):
            ui.label("coilcalc GUI · NiceGUI + Plotly")
            ui.label("© 2026 Bynarical")

    ui.run(host="127.0.0.1", port=port, native=native, dark=dark,
           title="coilcalc — MR-WPT coil calculator",
           favicon="🔌", reload=False, show=not native)


def main() -> None:                                       # pragma: no cover
    native = "--native" in sys.argv
    port = 8765
    for i, a in enumerate(sys.argv):
        if a == "--port" and i + 1 < len(sys.argv):
            port = int(sys.argv[i + 1])
    run_gui(port=port, native=native)


if __name__ in {"__main__", "__mp_main__"}:                # pragma: no cover
    main()
