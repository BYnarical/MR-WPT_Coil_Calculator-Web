"""Geometry + conductor input forms for the desktop GUI.

Each form is a self-contained QWidget that owns a parameter dict and emits
a `changed` signal whenever any input changes.
"""
from __future__ import annotations

from typing import Callable, Optional

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import (
    QComboBox, QDoubleSpinBox, QFormLayout, QFrame, QSpinBox, QVBoxLayout,
    QWidget,
)

from .. import (
    BipolarPad, CircularSpiral, Coil, ConicalHelix, DDPad, FoilStrip,
    LitzWire, MultiLayerSpiral, PCBTrace, PolygonalSpiral,
    RectangularSpiral, RoundWire, Solenoid,
)
from ..ferrite import (
    PRESETS as FERRITE_PRESETS, FerriteBars, FerriteCustom, FerriteMaterial,
    FerritePotCore, FerriteRing, FerriteRod, FerriteSheet,
)
from . import theme as T
from .widgets import labeled_combo, labeled_double, labeled_int


GEOMETRY_OPTIONS = [
    "Circular spiral",
    "Square spiral",
    "Hexagonal spiral",
    "Octagonal spiral",
    "Rectangular spiral",
    "Solenoid",
    "Conical helix",
    "Multi-layer planar",
    "Double-D pad",
]
_SHAPE_OF = {
    "Circular spiral":    "circular",
    "Square spiral":      "square",
    "Hexagonal spiral":   "hexagonal",
    "Octagonal spiral":   "octagonal",
    "Rectangular spiral": "rectangular",
    "Solenoid":           "solenoid",
    "Conical helix":      "conical",
    "Multi-layer planar": "multilayer",
    "Double-D pad":       "DD",
}

CONDUCTOR_OPTIONS = ["Litz wire", "Solid round wire", "Copper foil/strip", "PCB trace"]
_COND_OF = {
    "Litz wire":         "litz",
    "Solid round wire":  "round",
    "Copper foil/strip": "foil",
    "PCB trace":         "pcb",
}


# ----------------------------------------------------------- GeometryForm
class GeometryForm(QFrame):
    changed = Signal()

    def __init__(self, *, default_geom: str = "Circular spiral",
                 prefix: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.params: dict = dict(
            N=10, Do=100, Di=60,
            a=200, b=150, Di_a=80, Di_b=40, gap_between=10,
            D=30, length=50, r_top=20, r_bot=40,
            n_layers=2, layer_spacing=1.6,
            w=1.0, s=0.5, wire_d=1.0,
        )
        self._kind = _SHAPE_OF[default_geom]
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._form = QFormLayout()
        layout.addLayout(self._form)
        self._kind_combo = labeled_combo(
            self._form, prefix + "Type", GEOMETRY_OPTIONS, default_geom,
            on_change=self._on_kind_change,
        )
        self._dynamic_form = QFormLayout()
        layout.addLayout(self._dynamic_form)
        self._rebuild_dynamic()

    def _on_kind_change(self, value: str) -> None:
        self._kind = _SHAPE_OF[value]
        self._rebuild_dynamic()
        self.changed.emit()

    def _clear_form(self, form: QFormLayout) -> None:
        while form.rowCount():
            form.removeRow(0)

    def _bind(self, key: str):
        def _on(v):
            self.params[key] = float(v)
            self.changed.emit()
        return _on

    def _rebuild_dynamic(self) -> None:
        self._clear_form(self._dynamic_form)
        k = self._kind
        p = self.params

        labeled_double(self._dynamic_form, "Turns N", p["N"], _min=0.5,
                       _max=200, step=0.5, on_change=self._bind("N"))
        if k in ("circular", "square", "hexagonal", "octagonal", "multilayer"):
            labeled_double(self._dynamic_form, "Outer Ø (mm)", p["Do"],
                           _min=1, _max=2000, step=1, on_change=self._bind("Do"))
            labeled_double(self._dynamic_form, "Inner Ø (mm)", p["Di"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("Di"))
            if k == "multilayer":
                labeled_int(self._dynamic_form, "Layers", int(p["n_layers"]),
                            _min=1, _max=16, on_change=self._bind("n_layers"))
                labeled_double(self._dynamic_form, "Layer spacing (mm)",
                               p["layer_spacing"], _min=0.01, _max=20, step=0.1,
                               on_change=self._bind("layer_spacing"))
        elif k in ("rectangular", "DD"):
            labeled_double(self._dynamic_form, "Outer a (mm)", p["a"],
                           _min=1, _max=2000, step=1, on_change=self._bind("a"))
            labeled_double(self._dynamic_form, "Outer b (mm)", p["b"],
                           _min=1, _max=2000, step=1, on_change=self._bind("b"))
            labeled_double(self._dynamic_form, "Inner a (mm)", p["Di_a"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("Di_a"))
            labeled_double(self._dynamic_form, "Inner b (mm)", p["Di_b"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("Di_b"))
            if k == "DD":
                labeled_double(self._dynamic_form, "Gap between Ds (mm)",
                               p["gap_between"], _min=0, _max=200, step=1,
                               on_change=self._bind("gap_between"))
        elif k == "solenoid":
            labeled_double(self._dynamic_form, "Diameter D (mm)", p["D"],
                           _min=1, _max=1000, step=1, on_change=self._bind("D"))
            labeled_double(self._dynamic_form, "Length (mm)", p["length"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("length"))
        elif k == "conical":
            labeled_double(self._dynamic_form, "Top r (mm)", p["r_top"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("r_top"))
            labeled_double(self._dynamic_form, "Bottom r (mm)", p["r_bot"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("r_bot"))
            labeled_double(self._dynamic_form, "Length (mm)", p["length"],
                           _min=0.1, _max=2000, step=1, on_change=self._bind("length"))
        labeled_double(self._dynamic_form, "Conductor w (mm)", p["w"],
                       _min=0.01, _max=50, step=0.05, on_change=self._bind("w"))
        labeled_double(self._dynamic_form, "Turn gap s (mm)", p["s"],
                       _min=0.01, _max=50, step=0.05, on_change=self._bind("s"))

    def build_geometry(self):
        p = self.params
        k = self._kind
        if k == "circular":
            return CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                                  w=p["w"]*1e-3, s=p["s"]*1e-3)
        if k in ("square", "hexagonal", "octagonal"):
            return PolygonalSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                                   w=p["w"]*1e-3, s=p["s"]*1e-3, shape=k)
        if k == "rectangular":
            return RectangularSpiral(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                                     Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                                     w=p["w"]*1e-3, s=p["s"]*1e-3)
        if k == "solenoid":
            return Solenoid(N=p["N"], D=p["D"]*1e-3, length=p["length"]*1e-3,
                            wire_d=p["w"]*1e-3)
        if k == "conical":
            return ConicalHelix(N=p["N"], r_top=p["r_top"]*1e-3,
                                r_bot=p["r_bot"]*1e-3, length=p["length"]*1e-3,
                                wire_d=p["w"]*1e-3)
        if k == "multilayer":
            base = CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                                  w=p["w"]*1e-3, s=p["s"]*1e-3)
            return MultiLayerSpiral(layer_geom=base, n_layers=int(p["n_layers"]),
                                    layer_spacing=p["layer_spacing"]*1e-3)
        if k == "DD":
            return DDPad(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                         Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                         w=p["w"]*1e-3, s=p["s"]*1e-3,
                         gap_between=p["gap_between"]*1e-3)
        raise ValueError(k)


# ----------------------------------------------------------- ConductorForm
class ConductorForm(QFrame):
    changed = Signal()

    def __init__(self, *, default: str = "Litz wire",
                 prefix: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self.params: dict = dict(
            d=1.0, strand_d=71.0, n_strands=420,
            thickness=50.0, width=10.0, pitch=2.5,
        )
        self._kind = _COND_OF[default]
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._form = QFormLayout()
        layout.addLayout(self._form)
        self._kind_combo = labeled_combo(
            self._form, prefix + "Type", CONDUCTOR_OPTIONS, default,
            on_change=self._on_kind_change,
        )
        self._dynamic_form = QFormLayout()
        layout.addLayout(self._dynamic_form)
        self._rebuild_dynamic()

    def _on_kind_change(self, value: str) -> None:
        self._kind = _COND_OF[value]
        self._rebuild_dynamic()
        self.changed.emit()

    def _clear_form(self, form: QFormLayout) -> None:
        while form.rowCount():
            form.removeRow(0)

    def _bind(self, key: str):
        def _on(v):
            self.params[key] = float(v)
            self.changed.emit()
        return _on

    def _rebuild_dynamic(self) -> None:
        self._clear_form(self._dynamic_form)
        p = self.params
        k = self._kind
        if k == "round":
            labeled_double(self._dynamic_form, "Wire Ø (mm)", p["d"],
                           _min=0.05, _max=20, step=0.05,
                           on_change=self._bind("d"))
        elif k == "litz":
            labeled_double(self._dynamic_form, "Strand Ø (µm)", p["strand_d"],
                           _min=10, _max=500, step=1,
                           on_change=self._bind("strand_d"))
            labeled_int(self._dynamic_form, "# strands", int(p["n_strands"]),
                        _min=1, _max=10000, on_change=self._bind("n_strands"))
        elif k == "foil":
            labeled_double(self._dynamic_form, "Thickness (µm)", p["thickness"],
                           _min=1, _max=5000, step=1,
                           on_change=self._bind("thickness"))
            labeled_double(self._dynamic_form, "Width (mm)", p["width"],
                           _min=0.05, _max=200, step=0.1,
                           on_change=self._bind("width"))
        elif k == "pcb":
            labeled_double(self._dynamic_form, "Trace width (mm)", p["width"],
                           _min=0.05, _max=200, step=0.05,
                           on_change=self._bind("width"))
            labeled_double(self._dynamic_form, "Cu thickness (µm)", p["thickness"],
                           _min=1, _max=200, step=1,
                           on_change=self._bind("thickness"))
            labeled_double(self._dynamic_form, "Trace pitch (mm)", p["pitch"],
                           _min=0.05, _max=200, step=0.05,
                           on_change=self._bind("pitch"))

    def build_conductor(self):
        p = self.params
        k = self._kind
        if k == "round":
            return RoundWire(d=p["d"]*1e-3)
        if k == "litz":
            return LitzWire(strand_d=p["strand_d"]*1e-6,
                            n_strands=int(p["n_strands"]))
        if k == "foil":
            return FoilStrip(thickness=p["thickness"]*1e-6,
                             width=p["width"]*1e-3)
        if k == "pcb":
            return PCBTrace(width=p["width"]*1e-3,
                            thickness=p["thickness"]*1e-6,
                            pitch=p["pitch"]*1e-3)
        raise ValueError(k)


# ----------------------------------------------------------- FerriteForm
FERRITE_SHAPE_OPTIONS = [
    "None (air-core)", "Sheet / backplate", "Rod (axial core)",
    "Bars (EV-pad)", "Pot core (cup)", "Ring / toroid",
    "Custom (raw L mult)",
]
_FERR_KIND_OF = {
    "None (air-core)":      "none",
    "Sheet / backplate":    "sheet",
    "Rod (axial core)":     "rod",
    "Bars (EV-pad)":        "bars",
    "Pot core (cup)":       "potcore",
    "Ring / toroid":        "ring",
    "Custom (raw L mult)":  "custom",
}


class FerriteForm(QFrame):
    """Ferrite-shape + material picker. ``build_ferrite()`` returns a
    FerriteShape instance or None when kind == 'none'."""
    changed = Signal()

    def __init__(self, *, prefix: str = "",
                 parent: Optional[QWidget] = None):
        super().__init__(parent)
        self._kind = "none"
        self.params: dict = dict(
            thickness_mm=1.5, area_mm2=0.0, gap_mm=0.5,
            length_mm=50.0, diameter_mm=10.0,
            n_bars=4, width_mm=25.0, spacing_mm=5.0,
            OD_mm=40.0, ID_mm=15.0, height_mm=12.0, air_gap_mm=0.5,
            l_mult_at_dc=2.0, rolloff_f=1e6, core_volume=0.0, eff_path=0.05,
        )
        self.custom_mat: dict = dict(
            mu_r0=2000.0, f_cutoff=1e6, Bsat_T=0.4, rho=5.0,
            k_sm=1.8e-3, alpha_sm=1.5, beta_sm=2.6,
        )
        self._material_name = "Custom"

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._form = QFormLayout()
        layout.addLayout(self._form)
        self._kind_combo = labeled_combo(
            self._form, prefix + "Shape", FERRITE_SHAPE_OPTIONS,
            "None (air-core)", on_change=self._on_kind_change,
        )
        mat_names = ["Custom"] + list(FERRITE_PRESETS.keys())
        self._mat_combo = labeled_combo(
            self._form, prefix + "Material", mat_names, "Custom",
            on_change=self._on_mat_change,
        )
        self._dynamic_form = QFormLayout()
        layout.addLayout(self._dynamic_form)
        self._rebuild()

    def _on_kind_change(self, value: str) -> None:
        self._kind = _FERR_KIND_OF[value]
        self._rebuild()
        self.changed.emit()

    def _on_mat_change(self, value: str) -> None:
        self._material_name = value
        self._rebuild()
        self.changed.emit()

    def _clear_form(self, form: QFormLayout) -> None:
        while form.rowCount():
            form.removeRow(0)

    def _bind(self, key: str, in_custom_mat: bool = False):
        def _on(v):
            (self.custom_mat if in_custom_mat else self.params)[key] = float(v)
            self.changed.emit()
        return _on

    def _rebuild(self) -> None:
        self._clear_form(self._dynamic_form)
        k = self._kind
        p = self.params
        # Per-shape numerical fields
        if k == "sheet":
            labeled_double(self._dynamic_form, "Thickness (mm)", p["thickness_mm"],
                           _min=0.01, _max=100, step=0.1, on_change=self._bind("thickness_mm"))
            labeled_double(self._dynamic_form, "Area (mm², 0=auto)", p["area_mm2"],
                           _min=0, _max=1e8, step=100, on_change=self._bind("area_mm2"))
            labeled_double(self._dynamic_form, "Gap coil→plate (mm)", p["gap_mm"],
                           _min=0, _max=100, step=0.1, on_change=self._bind("gap_mm"))
        elif k == "rod":
            labeled_double(self._dynamic_form, "Length (mm)", p["length_mm"],
                           _min=1, _max=1000, step=1, on_change=self._bind("length_mm"))
            labeled_double(self._dynamic_form, "Diameter (mm)", p["diameter_mm"],
                           _min=0.1, _max=200, step=0.5, on_change=self._bind("diameter_mm"))
        elif k == "bars":
            labeled_int(self._dynamic_form, "Number of bars", int(p["n_bars"]),
                        _min=1, _max=64, on_change=self._bind("n_bars"))
            labeled_double(self._dynamic_form, "Bar length (mm)", p["length_mm"],
                           _min=1, _max=2000, step=1, on_change=self._bind("length_mm"))
            labeled_double(self._dynamic_form, "Bar width (mm)", p["width_mm"],
                           _min=1, _max=500, step=1, on_change=self._bind("width_mm"))
            labeled_double(self._dynamic_form, "Bar thickness (mm)", p["thickness_mm"],
                           _min=0.1, _max=100, step=0.5, on_change=self._bind("thickness_mm"))
            labeled_double(self._dynamic_form, "Spacing (mm)", p["spacing_mm"],
                           _min=0, _max=200, step=1, on_change=self._bind("spacing_mm"))
        elif k == "potcore":
            labeled_double(self._dynamic_form, "OD (mm)", p["OD_mm"], _min=1, _max=500, step=1,
                           on_change=self._bind("OD_mm"))
            labeled_double(self._dynamic_form, "ID (mm)", p["ID_mm"], _min=0.5, _max=500, step=0.5,
                           on_change=self._bind("ID_mm"))
            labeled_double(self._dynamic_form, "Height (mm)", p["height_mm"], _min=0.5, _max=500, step=0.5,
                           on_change=self._bind("height_mm"))
            labeled_double(self._dynamic_form, "Air gap (mm)", p["air_gap_mm"], _min=0, _max=50, step=0.05,
                           on_change=self._bind("air_gap_mm"))
        elif k == "ring":
            labeled_double(self._dynamic_form, "OD (mm)", p["OD_mm"], _min=1, _max=500, step=1,
                           on_change=self._bind("OD_mm"))
            labeled_double(self._dynamic_form, "ID (mm)", p["ID_mm"], _min=0.5, _max=500, step=0.5,
                           on_change=self._bind("ID_mm"))
            labeled_double(self._dynamic_form, "Height (mm)", p["height_mm"], _min=0.5, _max=500, step=0.5,
                           on_change=self._bind("height_mm"))
            labeled_double(self._dynamic_form, "Air gap (mm)", p["air_gap_mm"], _min=0, _max=50, step=0.05,
                           on_change=self._bind("air_gap_mm"))
        elif k == "custom":
            labeled_double(self._dynamic_form, "L gain × at DC", p["l_mult_at_dc"],
                           _min=1, _max=1000, step=0.1, on_change=self._bind("l_mult_at_dc"))
            labeled_double(self._dynamic_form, "μ_r rolloff f (Hz)", p["rolloff_f"],
                           _min=1, _max=1e9, step=1000, on_change=self._bind("rolloff_f"))
            labeled_double(self._dynamic_form, "Core volume (m³)", p["core_volume"],
                           _min=0, _max=1, step=1e-7, on_change=self._bind("core_volume"))
            labeled_double(self._dynamic_form, "Effective path (m)", p["eff_path"],
                           _min=1e-4, _max=10, step=0.005, on_change=self._bind("eff_path"))
        # Custom-material number fields shown only when material == Custom
        if self._material_name == "Custom" and self._kind != "none":
            cm = self.custom_mat
            labeled_double(self._dynamic_form, "μ_r at DC", cm["mu_r0"],
                           _min=1, _max=1e6, step=10, on_change=self._bind("mu_r0", True))
            labeled_double(self._dynamic_form, "μ_r cutoff f (Hz)", cm["f_cutoff"],
                           _min=1, _max=1e10, step=1000, on_change=self._bind("f_cutoff", True))
            labeled_double(self._dynamic_form, "B_sat (T)", cm["Bsat_T"],
                           _min=0.01, _max=2, step=0.01, on_change=self._bind("Bsat_T", True))
            labeled_double(self._dynamic_form, "ρ (Ω·m)", cm["rho"],
                           _min=1e-5, _max=1e10, step=1, on_change=self._bind("rho", True))
            labeled_double(self._dynamic_form, "Steinmetz k", cm["k_sm"],
                           _min=1e-6, _max=10, step=1e-5, on_change=self._bind("k_sm", True))
            labeled_double(self._dynamic_form, "Steinmetz α", cm["alpha_sm"],
                           _min=0.1, _max=4, step=0.05, on_change=self._bind("alpha_sm", True))
            labeled_double(self._dynamic_form, "Steinmetz β", cm["beta_sm"],
                           _min=0.1, _max=4, step=0.05, on_change=self._bind("beta_sm", True))

    def _build_material(self):
        if self._material_name in FERRITE_PRESETS:
            return FERRITE_PRESETS[self._material_name]
        cm = self.custom_mat
        return FerriteMaterial(name="Custom", family="MnZn",
            mu_r0=cm["mu_r0"], f_cutoff=cm["f_cutoff"],
            rho=cm["rho"], Bsat_T=cm["Bsat_T"],
            k_sm=cm["k_sm"], alpha_sm=cm["alpha_sm"], beta_sm=cm["beta_sm"])

    def build_ferrite(self):
        k = self._kind
        if k == "none":
            return None
        m = self._build_material()
        p = self.params
        if k == "sheet":
            return FerriteSheet(material=m, thickness_mm=p["thickness_mm"],
                                area_mm2=p["area_mm2"], gap_mm=p["gap_mm"])
        if k == "rod":
            return FerriteRod(material=m, length_mm=p["length_mm"],
                              diameter_mm=p["diameter_mm"])
        if k == "bars":
            return FerriteBars(material=m, n_bars=int(p["n_bars"]),
                               length_mm=p["length_mm"], width_mm=p["width_mm"],
                               thickness_mm=p["thickness_mm"],
                               spacing_mm=p["spacing_mm"])
        if k == "potcore":
            return FerritePotCore(material=m, OD_mm=p["OD_mm"], ID_mm=p["ID_mm"],
                                  height_mm=p["height_mm"], air_gap_mm=p["air_gap_mm"])
        if k == "ring":
            return FerriteRing(material=m, OD_mm=p["OD_mm"], ID_mm=p["ID_mm"],
                               height_mm=p["height_mm"], air_gap_mm=p["air_gap_mm"])
        if k == "custom":
            return FerriteCustom(material=m,
                l_mult_at_dc=p["l_mult_at_dc"], rolloff_f=p["rolloff_f"],
                core_volume=p["core_volume"], eff_path=p["eff_path"])
        raise ValueError(k)
