"""Ferrite materials and shapes for MR-WPT coils.

Two model layers are provided:

1. **Analytical (always available)**
   - Materials with Steinmetz core-loss parameters, μ_r(f) rolloff,
     saturation flux density, eddy resistivity.
   - Shape classes implement either:
       (a) the **image method** — returns a list of (mirrored_path, scaling)
           tuples used by :class:`coilcalc.api.Coil` to add reflected-coil
           contributions to L and M via the universal Neumann integrator.
           Works for half-space-like shapes: planar backplates / sheets,
           bars (partial coverage).
       (b) a direct **μ_eff multiplier** — for shapes that close the
           magnetic circuit (rod, pot core, ring/toroid). Uses
           Osborn/Bozorth demagnetisation factors.
   - Core loss via Steinmetz:  P_v = k · f^α · B^β  [W/m³]
     plus a coil-level effective B_pk estimate.

2. **FEMM bridge (optional, see** :mod:`coilcalc.femm_bridge` **)**
   - When ``pyfemm`` is available and ``use_femm=True``, runs a 2-D
     axisymmetric or planar simulation of the coil + ferrite and returns
     measured L and core-loss directly. Falls back to analytical if FEMM
     is missing.

Reference materials (mid-permeability MnZn, low-permeability NiZn) are
parameterised from Ferroxcube / TDK datasheets. All numbers are
approximate; the user can override with the ``Custom`` material.

References
----------
* Osborn 1945 — Demagnetising factors of the general ellipsoid.
* Bozorth — Ferromagnetism (rod demag formula).
* Steinmetz 1892 — empirical core-loss law.
* Lammeraner & Štafl — Eddy currents.
* Ferroxcube SDM 2013 datasheets (3F36, 3C95, 4F1, …).
* TDK SDM datasheets (N87, N95).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np


# ----------------------------------------------------------- demag factors
def osborn_prolate_Nd(length_over_diameter: float) -> float:
    """Demagnetising factor of a prolate / oblate spheroid along its long axis."""
    m = float(length_over_diameter)
    if m <= 0.0:
        raise ValueError("length/diameter must be > 0")
    if abs(m - 1.0) < 1e-9:
        return 1.0 / 3.0
    if m > 1.0:
        e = math.sqrt(1.0 - 1.0 / (m * m))
        return (1.0 - e * e) / (e ** 3) * (0.5 * math.log((1.0 + e) / (1.0 - e)) - e)
    e = math.sqrt(1.0 - m * m)
    return (1.0 / (e ** 2)) * (1.0 - (math.sqrt(1.0 - e * e) / e) * math.asin(e))


def bozorth_rod_Nd(length_over_diameter: float) -> float:
    """Bozorth fit for the demag factor of a finite-length cylindrical rod
    along its long axis. Accurate to a few % for m = 2..1000."""
    m = float(length_over_diameter)
    if m < 2.0:
        return osborn_prolate_Nd(m)
    return (math.log(2.0 * m) - 1.0) / (m * m)


def mu_effective(mu_r: float, Nd: float) -> float:
    """μ_eff = μ_r / (1 + N_d · (μ_r − 1))."""
    if mu_r <= 0.0:
        raise ValueError("μ_r must be > 0")
    return mu_r / (1.0 + Nd * (mu_r - 1.0))


# =========================================================== Materials
@dataclass(frozen=True)
class FerriteMaterial:
    """Bulk magnetic + loss properties of a ferrite material.

    Frequency dependence of μ_r is modelled as a single-pole rolloff:

        μ_r(f) = μ_r0 / √(1 + (f / f_cutoff)²)

    which captures the order-of-magnitude drop above the material's
    ferri-magnetic resonance / Snoek frequency.

    Steinmetz core-loss law:
        P_v [W/m³] = k · f[Hz]^α · B[T]^β

    The Steinmetz constants are fitted at a representative operating window
    (B_pk ≲ 0.2 T, f within ~ one decade of the material's intended band);
    they are *not* accurate over many decades. Datasheet curves remain
    ground truth.
    """
    name:     str
    family:   str = "MnZn"            # "MnZn" or "NiZn"
    mu_r0:    float = 2000.0
    f_cutoff: float = 1.0e6           # Hz
    rho:      float = 5.0             # Ω·m
    Bsat_T:   float = 0.40
    k_sm:     float = 1.8e-3
    alpha_sm: float = 1.5
    beta_sm:  float = 2.6

    def mu_r_at(self, f: float) -> float:
        if f <= 0.0:
            return self.mu_r0
        return self.mu_r0 / math.sqrt(1.0 + (f / self.f_cutoff) ** 2)

    def core_loss_density_W_m3(self, B_pk_T: float, f: float) -> float:
        if B_pk_T <= 0 or f <= 0:
            return 0.0
        return self.k_sm * (f ** self.alpha_sm) * (B_pk_T ** self.beta_sm)


# ----------------- preset materials (typical datasheet values)
MAT_3F36 = FerriteMaterial(name="3F36 (MnZn, Ferroxcube)",
    family="MnZn", mu_r0=1900, f_cutoff=2.0e6,  rho=5.0,
    Bsat_T=0.40, k_sm=2.0e-3,  alpha_sm=1.50, beta_sm=2.60)
MAT_3C95 = FerriteMaterial(name="3C95 (MnZn, Ferroxcube)",
    family="MnZn", mu_r0=3000, f_cutoff=300e3, rho=5.0,
    Bsat_T=0.42, k_sm=1.2e-3,  alpha_sm=1.50, beta_sm=2.70)
MAT_3F46 = FerriteMaterial(name="3F46 (MnZn high-f, Ferroxcube)",
    family="MnZn", mu_r0=900,  f_cutoff=6.0e6,  rho=10.0,
    Bsat_T=0.42, k_sm=2.5e-3,  alpha_sm=1.65, beta_sm=2.50)
MAT_N87 = FerriteMaterial(name="N87 (MnZn, TDK/EPCOS)",
    family="MnZn", mu_r0=2200, f_cutoff=500e3, rho=10.0,
    Bsat_T=0.39, k_sm=1.5e-3,  alpha_sm=1.70, beta_sm=2.50)
MAT_N95 = FerriteMaterial(name="N95 (MnZn low-loss, TDK/EPCOS)",
    family="MnZn", mu_r0=3000, f_cutoff=200e3, rho=8.0,
    Bsat_T=0.41, k_sm=8.0e-4,  alpha_sm=1.55, beta_sm=2.70)
MAT_4F1 = FerriteMaterial(name="4F1 (NiZn HF, Ferroxcube)",
    family="NiZn", mu_r0=80,   f_cutoff=80e6,  rho=1.0e5,
    Bsat_T=0.32, k_sm=5.0e-2,  alpha_sm=1.70, beta_sm=2.00)
MAT_67 = FerriteMaterial(name="67 NiZn (Fair-Rite, HF)",
    family="NiZn", mu_r0=40,   f_cutoff=200e6, rho=1.0e8,
    Bsat_T=0.25, k_sm=1.0e-1,  alpha_sm=1.80, beta_sm=2.00)
# Samwha Electronics PL-13 — power MnZn, fitted to the manufacturer datasheet:
#   μ_ac = 3200, B_s = 520 mT @ 25 °C, ρ > 7 Ω·m, μ' flat to ~1.5 MHz.
#   P_cv = 400 kW/m³ @ 100 kHz / 200 mT, 250 kW/m³ @ 200 kHz / 100 mT, and
#   50 kW/m³ @ 25 kHz / 200 mT — yields α = 1.5 (exact, log₄ 8) and β ≈ 2.4,
#   giving k_sm ≈ 0.6 in SI units (f [Hz], B [T], P [W/m³]).
# NOTE: This is the first preset with Steinmetz parameters fitted accurately
# from a real datasheet. The other MnZn/NiZn entries above use placeholder
# loss coefficients that underestimate P_v by ~100×. Apples-to-apples loss
# comparison across materials requires fitting all of them from datasheets.
MAT_PL13 = FerriteMaterial(name="PL-13 (Power MnZn, Samwha)",
    family="MnZn", mu_r0=3200, f_cutoff=1.5e6, rho=7.0,
    Bsat_T=0.520, k_sm=0.6,   alpha_sm=1.50, beta_sm=2.40)


PRESETS: dict[str, FerriteMaterial] = {m.name: m for m in [
    MAT_3F36, MAT_3C95, MAT_3F46, MAT_N87, MAT_N95, MAT_4F1, MAT_67,
    MAT_PL13,
]}


# =========================================================== Shape base
@dataclass
class FerriteShape:
    """Abstract base. Subclasses implement *one* of two paths:

    A) Image-method shapes (planar / partial-cover) override
       :meth:`image_paths` to return a list of (mirrored 3-D path, scaling).
       The Coil class adds these contributions via the Neumann integrator.

    B) Closed-circuit shapes (rod, pot core, ring) override
       :meth:`l_multiplier` to return a direct scalar gain on the air-core L.
    """
    material: FerriteMaterial = MAT_3F36

    # ---- image-method API
    def image_paths(self, coil_path: np.ndarray, coil_z0: float,
                    f: float) -> list[tuple[np.ndarray, float]]:
        return []

    # ---- multiplier API
    def l_multiplier(self, geom, f: float) -> float:
        return 1.0

    # ---- loss model
    def core_volume_m3(self) -> float:
        return 0.0

    def effective_path_length_m(self, geom) -> float:
        return 0.05

    def core_loss_W(self, *, N_turns: float, I_pk_A: float, f: float,
                    geom) -> float:
        """Steinmetz P_v · volume with B_pk inferred from N·I and path length."""
        V = self.core_volume_m3()
        if V <= 0.0 or f <= 0.0 or I_pk_A <= 0.0:
            return 0.0
        mu_r = self.material.mu_r_at(f)
        leff = max(self.effective_path_length_m(geom), 1e-6)
        B_pk = 4.0e-7 * math.pi * mu_r * N_turns * I_pk_A / leff
        B_pk = min(B_pk, self.material.Bsat_T)
        return self.material.core_loss_density_W_m3(B_pk, f) * V


# =========================================================== Sheet / backplate
@dataclass
class FerriteSheet(FerriteShape):
    """Planar ferrite sheet behind a planar coil.

    The plate's top surface sits at ``z_plate_top_m`` (default 0; coil
    typically at z = +gap_mm above it). Image method reflects the coil's
    filament path through that plane and scales contributions by:

        α = (μ_r − 1) / (μ_r + 1) · area_coverage · thin_plate_factor
    """
    thickness_mm:  float = 1.5
    area_mm2:      float = 0.0       # 0 → match coil footprint
    gap_mm:        float = 0.5
    z_plate_top_m: float = 0.0

    def _alpha(self, geom, f: float) -> float:
        mu_r = self.material.mu_r_at(f)
        base = (mu_r - 1.0) / (mu_r + 1.0)

        # Area coverage — derate if the plate is smaller than the coil.
        coil_area = _coil_footprint_area_m2(geom)
        my_area = self.area_mm2 * 1e-6 if self.area_mm2 > 0 else coil_area
        coverage = min(my_area / max(coil_area, 1e-12), 1.0)

        # Eddy-current derating — only matters above the material's complex-μ
        # cutoff frequency. Below f_cutoff the ferrite is a "good" magnetic
        # insulator and the image method is geometry-limited only.
        if f > self.material.f_cutoff:
            mu0 = 4.0e-7 * math.pi
            delta_f = math.sqrt(self.material.rho /
                                (math.pi * f * mu0 * mu_r))
            eddy = 1.0 - math.exp(
                -self.thickness_mm * 1e-3 / max(delta_f, 1e-12))
        else:
            eddy = 1.0
        return base * coverage * eddy

    def image_paths(self, coil_path: np.ndarray, coil_z0: float,
                    f: float) -> list[tuple[np.ndarray, float]]:
        alpha = self._alpha(_GeometryProxyFromPath(coil_path), f)
        if abs(alpha) < 1e-6:
            return []
        img = coil_path.copy()
        img[:, 2] = 2.0 * self.z_plate_top_m - img[:, 2]
        return [(img, alpha)]

    def core_volume_m3(self) -> float:
        if self.area_mm2 > 0:
            return self.area_mm2 * 1e-6 * self.thickness_mm * 1e-3
        return 0.0

    def effective_path_length_m(self, geom) -> float:
        d_avg = getattr(geom, "d_avg", None) or 0.05
        return 2.0 * d_avg


# =========================================================== Rod (axial core)
@dataclass
class FerriteRod(FerriteShape):
    """Cylindrical ferrite rod inside a solenoid (axial core).

    L_with_rod = L_air × μ_eff using Bozorth/Osborn demag factor.
    """
    length_mm:   float = 50.0
    diameter_mm: float = 10.0

    def _mu_eff(self, f: float) -> float:
        mu_r = self.material.mu_r_at(f)
        m_ratio = self.length_mm / max(self.diameter_mm, 1e-9)
        Nd = (bozorth_rod_Nd(m_ratio) if m_ratio >= 2.0
              else osborn_prolate_Nd(m_ratio))
        return mu_effective(mu_r, Nd)

    def l_multiplier(self, geom, f: float) -> float:
        return self._mu_eff(f)

    def core_volume_m3(self) -> float:
        return math.pi * (self.diameter_mm * 0.5e-3) ** 2 * self.length_mm * 1e-3

    def effective_path_length_m(self, geom) -> float:
        return self.length_mm * 1e-3


# =========================================================== Bars (EV pad)
@dataclass
class FerriteBars(FerriteShape):
    """Multiple discrete ferrite bars under a planar coil (EV-pad style)."""
    n_bars:        int = 4
    length_mm:     float = 100.0
    width_mm:      float = 25.0
    thickness_mm:  float = 5.0
    spacing_mm:    float = 5.0
    gap_mm:        float = 0.5
    z_plate_top_m: float = 0.0
    effectiveness: float = 0.75

    def _alpha(self, geom, f: float) -> float:
        mu_r = self.material.mu_r_at(f)
        base = (mu_r - 1.0) / (mu_r + 1.0)
        bars_w_mm = (self.n_bars * self.width_mm
                     + max(self.n_bars - 1, 0) * self.spacing_mm)
        bars_area = bars_w_mm * self.length_mm * 1e-6
        coil_area = _coil_footprint_area_m2(geom)
        coverage = min(bars_area / max(coil_area, 1e-12), 1.0)
        if f > self.material.f_cutoff:
            mu0 = 4.0e-7 * math.pi
            delta_f = math.sqrt(self.material.rho /
                                (math.pi * f * mu0 * mu_r))
            eddy = 1.0 - math.exp(
                -self.thickness_mm * 1e-3 / max(delta_f, 1e-12))
        else:
            eddy = 1.0
        return base * coverage * eddy * self.effectiveness

    def image_paths(self, coil_path: np.ndarray, coil_z0: float,
                    f: float) -> list[tuple[np.ndarray, float]]:
        alpha = self._alpha(_GeometryProxyFromPath(coil_path), f)
        if abs(alpha) < 1e-6:
            return []
        img = coil_path.copy()
        img[:, 2] = 2.0 * self.z_plate_top_m - img[:, 2]
        return [(img, alpha)]

    def core_volume_m3(self) -> float:
        return (self.n_bars * self.length_mm * self.width_mm
                * self.thickness_mm) * 1e-9

    def effective_path_length_m(self, geom) -> float:
        return self.length_mm * 1e-3 * 1.5


# =========================================================== Pot / cup core
@dataclass
class FerritePotCore(FerriteShape):
    """Pot / cup core surrounding a planar/short coil.

    Treated as a high-μ_eff closed circuit with an air-gap reluctance:

        μ_eff ≈ ℓ_iron / (ℓ_iron/μ_r + g_air)
    """
    OD_mm:      float = 40.0
    ID_mm:      float = 15.0
    height_mm:  float = 12.0
    air_gap_mm: float = 0.5

    def _path_lengths(self) -> tuple[float, float]:
        l_iron_mm = math.pi * (self.OD_mm + self.ID_mm) / 2.0 + 2 * self.height_mm
        return l_iron_mm * 1e-3, self.air_gap_mm * 1e-3

    def l_multiplier(self, geom, f: float) -> float:
        mu_r = self.material.mu_r_at(f)
        l_iron, g_air = self._path_lengths()
        return l_iron / (l_iron / mu_r + g_air)

    def core_volume_m3(self) -> float:
        OD = self.OD_mm * 1e-3; ID = self.ID_mm * 1e-3; H = self.height_mm * 1e-3
        V_side = math.pi * ((OD / 2) ** 2 - (ID / 2) ** 2) * H
        V_caps = 2.0 * math.pi * (OD / 2) ** 2 * (H * 0.15)
        return V_side + V_caps

    def effective_path_length_m(self, geom) -> float:
        return self._path_lengths()[0]


# =========================================================== Ring / toroid
@dataclass
class FerriteRing(FerriteShape):
    """Closed ring / toroid wound with the coil.

    Demag → 0 (closed flux path), so μ_eff = μ_r unless gapped.
    """
    OD_mm:      float = 30.0
    ID_mm:      float = 20.0
    height_mm:  float = 10.0
    air_gap_mm: float = 0.0

    def _path_length(self) -> float:
        return math.pi * (self.OD_mm + self.ID_mm) / 2.0 * 1e-3

    def l_multiplier(self, geom, f: float) -> float:
        mu_r = self.material.mu_r_at(f)
        l_iron = self._path_length()
        g_air = self.air_gap_mm * 1e-3
        if g_air <= 0.0:
            return mu_r
        return l_iron / (l_iron / mu_r + g_air)

    def core_volume_m3(self) -> float:
        OD = self.OD_mm * 1e-3; ID = self.ID_mm * 1e-3; H = self.height_mm * 1e-3
        return math.pi * ((OD / 2) ** 2 - (ID / 2) ** 2) * H

    def effective_path_length_m(self, geom) -> float:
        return self._path_length()


# =========================================================== Custom shape
@dataclass
class FerriteCustom(FerriteShape):
    """User-defined shape — caller supplies an L_multiplier directly.

    Handy for sharing FEMM-extracted multipliers or experimental fits.
    """
    l_mult_at_dc: float = 1.5
    rolloff_f:    float = 1.0e6
    core_volume:  float = 0.0
    eff_path:     float = 0.05

    def l_multiplier(self, geom, f: float) -> float:
        return 1.0 + (self.l_mult_at_dc - 1.0) / math.sqrt(
            1.0 + (f / max(self.rolloff_f, 1e-3)) ** 2)

    def core_volume_m3(self) -> float:
        return self.core_volume

    def effective_path_length_m(self, geom) -> float:
        return self.eff_path


# =========================================================== helpers
def _coil_footprint_area_m2(geom) -> float:
    """Approximate planar footprint area of a coil geometry (m²)."""
    if geom is None:
        return 0.01
    if hasattr(geom, "Do") and hasattr(geom, "Di"):
        Do = float(geom.Do)
        return math.pi * (Do / 2.0) ** 2
    if hasattr(geom, "a") and hasattr(geom, "b"):
        return float(geom.a * geom.b)
    if hasattr(geom, "D") and hasattr(geom, "length"):
        return float(geom.D * geom.length)
    return 0.01


class _GeometryProxyFromPath:
    """Stand-in geometry: extract footprint diameters from a filament path."""
    def __init__(self, path: np.ndarray):
        xy = path[:, :2]
        self.Do = float(2.0 * np.max(np.linalg.norm(xy, axis=1)))
        self.Di = self.Do * 0.4
    @property
    def d_avg(self) -> float:
        return 0.5 * (self.Do + self.Di)


# =========================================================== builder
def build_ferrite(spec: Optional[dict]) -> Optional[FerriteShape]:
    """Build a FerriteShape from a serialisable dict (used by web_api)."""
    if spec is None:
        return None
    kind = spec.get("kind", "none")
    if kind in ("none", "", None):
        return None

    mat = spec.get("material")
    if isinstance(mat, dict):
        material = FerriteMaterial(
            name=mat.get("name", "Custom"),
            family=mat.get("family", "MnZn"),
            mu_r0=float(mat.get("mu_r0", 2000)),
            f_cutoff=float(mat.get("f_cutoff", 1e6)),
            rho=float(mat.get("rho", 10.0)),
            Bsat_T=float(mat.get("Bsat_T", 0.4)),
            k_sm=float(mat.get("k_sm", 1.8e-3)),
            alpha_sm=float(mat.get("alpha_sm", 1.5)),
            beta_sm=float(mat.get("beta_sm", 2.6)),
        )
    elif mat == "custom":
        cm = spec.get("custom_material", {}) or {}
        material = FerriteMaterial(
            name=cm.get("name", "Custom"),
            family=cm.get("family", "MnZn"),
            mu_r0=float(cm.get("mu_r0", 2000)),
            f_cutoff=float(cm.get("f_cutoff", 1e6)),
            rho=float(cm.get("rho", 10.0)),
            Bsat_T=float(cm.get("Bsat_T", 0.4)),
            k_sm=float(cm.get("k_sm", 1.8e-3)),
            alpha_sm=float(cm.get("alpha_sm", 1.5)),
            beta_sm=float(cm.get("beta_sm", 2.6)),
        )
    else:
        material = PRESETS.get(str(mat), MAT_3F36)

    if kind == "sheet":
        return FerriteSheet(material=material,
            thickness_mm=float(spec.get("thickness_mm", 1.5)),
            area_mm2=float(spec.get("area_mm2", 0.0)),
            gap_mm=float(spec.get("gap_mm", 0.5)),
            z_plate_top_m=float(spec.get("z_plate_top_m", 0.0)))
    if kind == "rod":
        return FerriteRod(material=material,
            length_mm=float(spec.get("length_mm", 50.0)),
            diameter_mm=float(spec.get("diameter_mm", 10.0)))
    if kind == "bars":
        return FerriteBars(material=material,
            n_bars=int(spec.get("n_bars", 4)),
            length_mm=float(spec.get("length_mm", 100.0)),
            width_mm=float(spec.get("width_mm", 25.0)),
            thickness_mm=float(spec.get("thickness_mm", 5.0)),
            spacing_mm=float(spec.get("spacing_mm", 5.0)),
            gap_mm=float(spec.get("gap_mm", 0.5)),
            z_plate_top_m=float(spec.get("z_plate_top_m", 0.0)),
            effectiveness=float(spec.get("effectiveness", 0.75)))
    if kind == "potcore":
        return FerritePotCore(material=material,
            OD_mm=float(spec.get("OD_mm", 40.0)),
            ID_mm=float(spec.get("ID_mm", 15.0)),
            height_mm=float(spec.get("height_mm", 12.0)),
            air_gap_mm=float(spec.get("air_gap_mm", 0.5)))
    if kind == "ring":
        return FerriteRing(material=material,
            OD_mm=float(spec.get("OD_mm", 30.0)),
            ID_mm=float(spec.get("ID_mm", 20.0)),
            height_mm=float(spec.get("height_mm", 10.0)),
            air_gap_mm=float(spec.get("air_gap_mm", 0.0)))
    if kind == "custom":
        return FerriteCustom(material=material,
            l_mult_at_dc=float(spec.get("l_mult_at_dc", 1.5)),
            rolloff_f=float(spec.get("rolloff_f", 1e6)),
            core_volume=float(spec.get("core_volume", 0.0)),
            eff_path=float(spec.get("eff_path", 0.05)))
    raise ValueError(f"Unknown ferrite kind: {kind!r}")


# Backwards-compat alias — older code (and external scripts) imported
# FerriteCore for rod-only usage.
FerriteCore = FerriteRod
