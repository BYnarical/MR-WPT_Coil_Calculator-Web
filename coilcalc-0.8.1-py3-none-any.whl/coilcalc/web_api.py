"""Pure-function API shared by the Electron sidecar and the Pyodide web build.

Each handler takes a plain dict of params and returns a plain dict of results
(JSON-serialisable). No I/O, no global state. Used by:

- coilcalc_sidecar.py — wraps these as line-JSON-RPC over stdio (Electron)
- web/pyodide-bridge.js — calls these via pyodide.runPythonAsync (browser)
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np

from . import (
    BipolarPad, CircularSpiral, Coil, ConicalHelix, DDPad, FoilStrip,
    LitzWire, MultiLayerSpiral, MutualPair, PCBTrace, PolygonalSpiral,
    RectangularSpiral, RoundWire, Solenoid, WPTSystem, __version__,
    build_ferrite, FERRITE_PRESETS,
)


# ----------------------------------------------------------- builders
def build_geometry(spec: dict):
    k = spec["kind"]
    p = spec
    if k == "circular":
        return CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                              w=p.get("w", 0.5)*1e-3, s=p.get("s", 0.3)*1e-3)
    if k in ("square", "hexagonal", "octagonal"):
        return PolygonalSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                               w=p.get("w", 0.5)*1e-3, s=p.get("s", 0.3)*1e-3,
                               shape=k)
    if k == "rectangular":
        return RectangularSpiral(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                                 Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                                 w=p.get("w", 1.0)*1e-3, s=p.get("s", 0.5)*1e-3)
    if k == "solenoid":
        return Solenoid(N=p["N"], D=p["D"]*1e-3, length=p["length"]*1e-3,
                        wire_d=p.get("w", 1.0)*1e-3)
    if k == "conical":
        return ConicalHelix(N=p["N"], r_top=p["r_top"]*1e-3,
                            r_bot=p["r_bot"]*1e-3, length=p["length"]*1e-3,
                            wire_d=p.get("w", 1.0)*1e-3)
    if k == "multilayer":
        base = CircularSpiral(N=p["N"], Do=p["Do"]*1e-3, Di=p["Di"]*1e-3,
                              w=p.get("w", 0.5)*1e-3, s=p.get("s", 0.3)*1e-3)
        return MultiLayerSpiral(layer_geom=base, n_layers=int(p["n_layers"]),
                                layer_spacing=p["layer_spacing"]*1e-3)
    if k == "DD":
        return DDPad(N=p["N"], a=p["a"]*1e-3, b=p["b"]*1e-3,
                     Di_a=p["Di_a"]*1e-3, Di_b=p["Di_b"]*1e-3,
                     w=p.get("w", 1.0)*1e-3, s=p.get("s", 0.5)*1e-3,
                     gap_between=p.get("gap_between", 5)*1e-3)
    raise ValueError(f"Unknown geometry kind: {k}")


def build_conductor(spec: dict):
    k = spec["kind"]
    p = spec
    if k == "round":
        return RoundWire(d=p["d"]*1e-3)
    if k == "litz":
        return LitzWire(strand_d=p["strand_d"]*1e-6,
                        n_strands=int(p["n_strands"]))
    if k == "foil":
        return FoilStrip(thickness=p["thickness"]*1e-6,
                         width=p["width"]*1e-3)
    if k == "pcb":
        return PCBTrace(width=p["width"]*1e-3,
                        thickness=p["thickness"]*1e-6,
                        pitch=p["pitch"]*1e-3)
    raise ValueError(f"Unknown conductor kind: {k}")


def conductor_width_mm(spec: dict) -> float:
    """Effective spiral-track / wire-Ø in mm, derived from a conductor spec.

    Used to auto-fill the geometry's ``w`` (and solenoid/conical ``wire_d``)
    so the UI doesn't have to ask for a redundant 'conductor width' field.
        Round  → d (mm)
        Litz   → bundle diameter ≈ 1.155·√n_strands·d_s
        Foil   → width
        PCB    → trace width
    """
    k = spec["kind"]
    if k == "round":
        return float(spec["d"])
    if k == "litz":
        return 1.155 * math.sqrt(int(spec["n_strands"])) * \
               float(spec["strand_d"]) * 1e-3      # µm → mm via the √ formula
    if k == "foil":
        return float(spec["width"])
    if k == "pcb":
        return float(spec["width"])
    return 0.5


def _autofill_geom_w(geom_spec: dict, cond_spec: dict) -> dict:
    """Return a copy of geom_spec with 'w' filled in from the conductor
    if the caller didn't provide one."""
    if "w" in geom_spec and geom_spec["w"] not in (None, "", 0):
        return geom_spec
    out = dict(geom_spec)
    out["w"] = conductor_width_mm(cond_spec)
    return out


def _path_mm(coil: Coil, max_pts: int = 2400) -> list[list[float]]:
    p = coil.geometry.filament_curve()
    if p.shape[0] > max_pts:
        idx = np.linspace(0, p.shape[0] - 1, max_pts).astype(int)
        p = p[idx]
    return (p * 1e3).tolist()


# ----------------------------------------------------------- public methods
def version() -> dict:
    return {"version": __version__}


def single_coil(params: dict) -> dict:
    cond_spec = params["conductor"]
    geom_spec = _autofill_geom_w(params["geom"], cond_spec)
    geom = build_geometry(geom_spec)
    cond = build_conductor(cond_spec)
    ferrite = build_ferrite(params.get("ferrite"))
    f = float(params.get("f", 6.78e6))
    coil = Coil(geom, cond, ferrite=ferrite)
    srf = coil.SRF()
    out = {
        "L_uH":          coil.L(f) * 1e6,
        "Rdc_mOhm":      coil.Rdc() * 1e3,
        "Rac_mOhm":      coil.Rac(f) * 1e3,
        "Q":             coil.Q(f),
        "SRF_MHz":       srf * 1e-6 if math.isfinite(srf) else None,
        "wire_length_m": coil.wire_length(),
        "path":          _path_mm(coil),
    }
    if ferrite is not None:
        L_air = coil._L_air()                  # noqa: SLF001 — internal helper
        out["ferrite"] = {
            "L_mult_total":    coil.L(f) / L_air if L_air > 0 else 1.0,
            "core_loss_R_mOhm": coil.core_loss_resistance(f) * 1e3,
            "material":         ferrite.material.name,
            "mu_r_at_f":        ferrite.material.mu_r_at(f),
        }
    return out


def pair(params: dict) -> dict:
    cond_spec_a = params["conductor"]
    cond_spec_b = params.get("rx_conductor", cond_spec_a)
    cond_a = build_conductor(cond_spec_a)
    cond_b = build_conductor(cond_spec_b)
    fer_tx = build_ferrite(params.get("ferrite_tx") or params.get("ferrite"))
    fer_rx = build_ferrite(params.get("ferrite_rx") or params.get("ferrite"))
    tx_geom = build_geometry(_autofill_geom_w(params["tx"], cond_spec_a))
    rx_geom = build_geometry(_autofill_geom_w(params["rx"], cond_spec_b))
    tx = Coil(tx_geom, cond_a, ferrite=fer_tx)
    rx = Coil(rx_geom, cond_b, ferrite=fer_rx)
    al = params.get("alignment", {})
    gap = float(al.get("gap", 20.0)) * 1e-3
    lat = float(al.get("lateral", 0.0)) * 1e-3
    tilt = float(al.get("tilt", 0.0))
    sys_p = params.get("system", {})
    R_load = float(sys_p.get("R_load", 20.0))
    V_src  = float(sys_p.get("V_source", 10.0))
    f      = float(sys_p.get("f", 6.78e6))

    pair_obj = MutualPair(tx, rx, gap=gap, lateral=lat, tilt_deg=tilt, f=f)
    M_val = pair_obj.M()
    k_val = pair_obj.k()
    wpt = WPTSystem(coils=[tx, rx],
                    positions=[(0, 0, 0), (lat, 0, gap)],
                    load_index=1, R_load=R_load, V_source=V_src, f=f)
    res = wpt.solve()

    gaps = np.linspace(2e-3, 200e-3, 25)
    ks_gap = [MutualPair(tx, rx, gap=float(g), lateral=lat).k() for g in gaps]

    do_for_lat = max(float(params["tx"].get("Do", 100)),
                     float(params["rx"].get("Do", 100)), 30.0) * 1e-3
    lats = np.linspace(0.0, do_for_lat, 25)
    ks_lat = [MutualPair(tx, rx, gap=gap, lateral=float(x)).k() for x in lats]

    gaps_e = np.linspace(2e-3, 200e-3, 18)
    etas = []
    for g in gaps_e:
        s2 = WPTSystem(coils=[tx, rx],
                       positions=[(0, 0, 0), (lat, 0, float(g))],
                       load_index=1, R_load=R_load, V_source=V_src, f=f)
        try:
            etas.append(float(s2.solve()["eta"]))
        except Exception:
            etas.append(0.0)

    return {
        "M_uH":   M_val * 1e6,
        "k":      k_val,
        "eta":    float(res["eta"]),
        "V_out":  abs(complex(res["V_out"])),
        "P_in_mW":   res["P_in"] * 1e3,
        "P_load_mW": res["P_load"] * 1e3,
        "tx": {"L_uH": tx.L() * 1e6, "Q": tx.Q(f), "Rac_mOhm": tx.Rac(f) * 1e3},
        "rx": {"L_uH": rx.L() * 1e6, "Q": rx.Q(f), "Rac_mOhm": rx.Rac(f) * 1e3},
        "sweeps": {
            "k_vs_gap":     {"x": (gaps * 1e3).tolist(),  "y": ks_gap},
            "k_vs_lateral": {"x": (lats * 1e3).tolist(),  "y": ks_lat},
            "eta_vs_gap":   {"x": (gaps_e * 1e3).tolist(),"y": etas},
        },
        "tx_path": _path_mm(tx),
        "rx_path": _path_mm(rx),
        "rx_offset_mm": [lat * 1e3, 0.0, gap * 1e3],
    }


def system(params: dict) -> dict:
    cond = build_conductor(params.get("conductor",
                                      {"kind": "litz", "strand_d": 71,
                                       "n_strands": 420}))
    ferrite_default = build_ferrite(params.get("ferrite"))
    coils = []
    positions = []
    for row in params["coils"]:
        g = CircularSpiral(N=float(row["N"]),
                           Do=float(row["Do"])*1e-3,
                           Di=float(row["Di"])*1e-3)
        row_ferrite = build_ferrite(row.get("ferrite")) if row.get("ferrite") else ferrite_default
        coils.append(Coil(g, cond, ferrite=row_ferrite))
        positions.append((float(row["x"])*1e-3, float(row["y"])*1e-3,
                          float(row["z"])*1e-3))
    R_load   = float(params.get("R_load", 20.0))
    V_source = float(params.get("V_source", 10.0))
    f        = float(params.get("f", 6.78e6))
    sys_obj = WPTSystem(coils=coils, positions=positions,
                        load_index=len(coils)-1,
                        R_load=R_load, V_source=V_source, f=f)
    res = sys_obj.solve()
    K = sys_obj.coupling_matrix().tolist()
    paths = []
    for coil, (x, y, z) in zip(coils, positions):
        p = coil.geometry.filament_curve().copy()
        p[:, 0] += x; p[:, 1] += y; p[:, 2] += z
        if p.shape[0] > 1500:
            idx = np.linspace(0, p.shape[0]-1, 1500).astype(int)
            p = p[idx]
        paths.append((p * 1e3).tolist())
    return {
        "eta":       float(res["eta"]),
        "V_out":     abs(complex(res["V_out"])),
        "gain":      float(res["gain"]),
        "P_in_mW":   res["P_in"] * 1e3,
        "P_load_mW": res["P_load"] * 1e3,
        "K":         K,
        "paths":     paths,
    }


def ferrite_presets(_params: dict | None = None) -> dict:
    """Return the list of ferrite material presets for the UI dropdown."""
    return {
        "materials": [
            {"name": m.name, "family": m.family,
             "mu_r0": m.mu_r0, "f_cutoff": m.f_cutoff,
             "Bsat_T": m.Bsat_T, "rho": m.rho,
             "k_sm": m.k_sm, "alpha_sm": m.alpha_sm, "beta_sm": m.beta_sm}
            for m in FERRITE_PRESETS.values()
        ],
        "shapes": ["none", "sheet", "rod", "bars", "potcore", "ring", "custom"],
    }


def dispatch(method: str, params: dict) -> Any:
    """Single entry point — used by both the sidecar and the Pyodide bridge."""
    if method == "ping":            return {"pong": True}
    if method == "version":         return version()
    if method == "single_coil":     return single_coil(params)
    if method == "pair":            return pair(params)
    if method == "system":          return system(params)
    if method == "ferrite_presets": return ferrite_presets(params)
    raise ValueError(f"unknown method '{method}'")
