"""Ferrite-core support — effective permeability via Osborn / Bozorth.

For an air-cored solenoid wound on a finite-length ferrite rod or slab,
the effective permeability is reduced from the bulk μ_r by the demagnetising
factor N_d of the core's shape:

    μ_eff = μ_r / (1 + N_d · (μ_r − 1))

Self-inductance with a ferrite core then becomes  L_ferrite = μ_eff · L_air.

Osborn (1945) gives N_d analytically for general ellipsoids; for finite-
length cylinders Bozorth's curve-fit is widely used:

    N_d_prolate(m) ≈ (ln(2m) − 1) / m²,   m = length/diameter
"""
from __future__ import annotations

import math
from dataclasses import dataclass


def osborn_prolate_Nd(length_over_diameter: float) -> float:
    """Demagnetising factor for a prolate spheroid (length ≥ diameter)."""
    m = float(length_over_diameter)
    if m <= 0.0:
        raise ValueError("length/diameter must be > 0")
    if m == 1.0:
        return 1.0 / 3.0
    if m > 1.0:
        e = math.sqrt(1.0 - 1.0 / (m * m))
        return (1.0 - e * e) / (e ** 3) * (0.5 * math.log((1.0 + e) / (1.0 - e)) - e)
    # Oblate: m < 1
    e = math.sqrt(1.0 - m * m)
    return (1.0 / (e ** 2)) * (1.0 - (math.sqrt(1.0 - e * e) / e) * math.asin(e))


def bozorth_rod_Nd(length_over_diameter: float) -> float:
    """Bozorth fit for the demag factor of a finite-length cylindrical rod
    along its long axis. Accurate to a few % for m = 2..1000."""
    m = float(length_over_diameter)
    if m < 2.0:
        # Fall back to prolate spheroid for short rods.
        return osborn_prolate_Nd(m)
    return (math.log(2.0 * m) - 1.0) / (m * m)


def mu_effective(mu_r: float, Nd: float) -> float:
    """μ_eff = μ_r / (1 + N_d·(μ_r − 1))."""
    if mu_r <= 0.0:
        raise ValueError("μ_r must be > 0")
    return mu_r / (1.0 + Nd * (mu_r - 1.0))


@dataclass
class FerriteCore:
    """A simple ferrite core: bulk μ_r plus a shape demag-factor."""
    mu_r:   float                  # bulk relative permeability (e.g. 100, 800, 2000)
    length: float                  # core length, m
    diameter: float                # core diameter, m
    shape:  str = "rod"            # "rod" | "ellipsoid"

    def Nd(self) -> float:
        m = self.length / self.diameter
        return (bozorth_rod_Nd(m) if self.shape == "rod"
                else osborn_prolate_Nd(m))

    def mu_eff(self) -> float:
        return mu_effective(self.mu_r, self.Nd())

    def __repr__(self) -> str:
        return (f"FerriteCore(μ_r={self.mu_r:.0f}, "
                f"L={self.length*1e3:.1f} mm, D={self.diameter*1e3:.1f} mm, "
                f"μ_eff={self.mu_eff():.1f})")
