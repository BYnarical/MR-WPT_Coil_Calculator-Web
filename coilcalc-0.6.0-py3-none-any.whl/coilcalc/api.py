"""High-level user-facing API: Coil and MutualPair.

Examples
--------
>>> from coilcalc import CircularSpiral, LitzWire, Coil
>>> tx = Coil(CircularSpiral(N=10, Do=100e-3, Di=60e-3),
...           LitzWire(strand_d=71e-6, n_strands=420))
>>> tx.L() > 0
True
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from .conductors import FoilStrip, LitzWire, RoundWire
from .geometry.solenoid import Solenoid
from .geometry.spiral import _SpiralBase
from .inductance import self_inductance
from .mutual import mutual_inductance
from .proximity import mean_h_squared_per_amp
from .srf import self_resonant_frequency


_Conductor = "RoundWire | LitzWire | FoilStrip"


@dataclass
class Coil:
    """A single physical coil: geometry + conductor.

    Set ``include_proximity=False`` to skip the (slow-ish, O(M²)) Biot-Savart
    proximity calculation and fall back to the conductor's intrinsic R_ac only.
    """
    geometry: object
    conductor: object
    include_proximity: bool = True

    _L_cache:    Optional[float] = field(default=None, init=False, repr=False)
    _len_cache:  Optional[float] = field(default=None, init=False, repr=False)
    _hsq_cache:  Optional[float] = field(default=None, init=False, repr=False)

    # ------------------------------------------------------------------ L
    def L(self) -> float:
        """Self-inductance, H."""
        if self._L_cache is None:
            self._L_cache = self_inductance(self.geometry)
        return self._L_cache

    # ------------------------------------------------------------------ length
    def wire_length(self) -> float:
        if self._len_cache is None:
            self._len_cache = float(self.geometry.wire_length())
        return self._len_cache

    # ------------------------------------------------------------------ R
    def Rdc(self) -> float:
        return self.conductor.rdc_per_length() * self.wire_length()

    # ------------------------------------------------------------------ proximity
    def _wire_diameter(self) -> float:
        """Effective wire / bundle diameter for the proximity self-exclusion radius."""
        c = self.conductor
        if hasattr(c, "d"):
            return float(c.d)
        if hasattr(c, "bundle_d") and c.bundle_d is not None:
            return float(c.bundle_d)
        if hasattr(c, "thickness"):
            return float(c.thickness) * 2.0
        return 1.0e-3  # safe fallback

    def mean_H_squared_per_amp(self) -> float:
        """⟨|H_ext/I|²⟩ averaged along the conductor (1/m²)."""
        if self._hsq_cache is None:
            path = self.geometry.filament_curve()
            self._hsq_cache = mean_h_squared_per_amp(path, wire_d=self._wire_diameter())
        return self._hsq_cache

    def Rac(self, f: float) -> float:
        """AC resistance, Ω, at frequency f (Hz).

        R_ac = ℓ · (R_intrinsic_per_m  +  G_proximity · ⟨|H/I|²⟩)
        """
        ell = self.wire_length()
        R = self.conductor.rac_per_length(f) * ell
        if self.include_proximity and hasattr(self.conductor, "proximity_loss_coefficient"):
            G = self.conductor.proximity_loss_coefficient(f)
            R += G * self.mean_H_squared_per_amp() * ell
        return R

    # ------------------------------------------------------------------ Q
    def Q(self, f: float) -> float:
        omega = 2.0 * math.pi * f
        return omega * self.L() / self.Rac(f)

    # ------------------------------------------------------------------ SRF
    def SRF(self) -> float:
        return self_resonant_frequency(self.geometry, self.L())

    # ------------------------------------------------------------------ summary
    def summary(self, f: float) -> dict:
        return {
            "L_uH":    self.L() * 1e6,
            "Rdc_mOhm": self.Rdc() * 1e3,
            "Rac_mOhm": self.Rac(f) * 1e3,
            "Q":       self.Q(f),
            "SRF_MHz": self.SRF() * 1e-6,
            "wire_length_m": self.wire_length(),
        }


@dataclass
class MutualPair:
    """Two coils with relative position; computes M, k, and misalignment sweeps."""
    tx: Coil
    rx: Coil
    gap: float = 0.0
    lateral: float = 0.0
    tilt_deg: float = 0.0

    def M(self) -> float:
        return mutual_inductance(
            self.tx.geometry, self.rx.geometry,
            gap=self.gap, lateral=self.lateral, tilt_deg=self.tilt_deg,
        )

    def k(self) -> float:
        return self.M() / math.sqrt(self.tx.L() * self.rx.L())

    # ------------------------------------------------------------------ sweep
    def sweep_lateral(self, x_min: float, x_max: float, n: int = 21):
        import numpy as np
        xs = np.linspace(x_min, x_max, n)
        out = np.zeros_like(xs)
        for i, x in enumerate(xs):
            self.lateral = float(x)
            out[i] = self.k()
        self.lateral = 0.0
        return xs, out

    def sweep_gap(self, g_min: float, g_max: float, n: int = 21):
        import numpy as np
        gs = np.linspace(g_min, g_max, n)
        out = np.zeros_like(gs)
        gap0 = self.gap
        for i, g in enumerate(gs):
            self.gap = float(g)
            out[i] = self.k()
        self.gap = gap0
        return gs, out

    def summary(self, f: float) -> dict:
        M = self.M()
        return {
            "M_uH": M * 1e6,
            "k":    M / math.sqrt(self.tx.L() * self.rx.L()),
            "tx":   self.tx.summary(f),
            "rx":   self.rx.summary(f),
        }
