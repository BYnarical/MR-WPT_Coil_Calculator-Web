"""coilcalc — MR-WPT coil calculator (geometry → L, M, R_ac, Q, SRF)."""
from .conductors import FoilStrip, LitzWire, PCBTrace, RoundWire
from .geometry.solenoid import Solenoid
from .geometry.spiral import CircularSpiral, PolygonalSpiral
from .geometry.rectangular import RectangularSpiral
from .geometry.conical import ConicalHelix, MultiLayerSpiral
from .geometry.ev_pads import BipolarPad, DDPad, DDQPad
from .api import Coil, MutualPair
from .ferrite import FerriteCore
from .system import WPTSystem, domino_chain, four_coil_system, multi_tx

__version__ = "0.6.0"
__all__ = [
    "CircularSpiral",
    "PolygonalSpiral",
    "RectangularSpiral",
    "Solenoid",
    "ConicalHelix",
    "MultiLayerSpiral",
    "DDPad",
    "DDQPad",
    "BipolarPad",
    "RoundWire",
    "LitzWire",
    "FoilStrip",
    "PCBTrace",
    "Coil",
    "MutualPair",
    "FerriteCore",
    "WPTSystem",
    "domino_chain",
    "four_coil_system",
    "multi_tx",
]
